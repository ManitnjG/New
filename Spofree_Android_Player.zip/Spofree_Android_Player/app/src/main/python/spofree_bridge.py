"""
spofree_bridge.py
=================
Core Python bridge between the Android Kotlin layer and the
spofree download/streaming logic.

Adapted from: https://github.com/redretep/spofree/
Extended with: full FLAC metadata embedding, synced lyrics,
hi-res cover art, ISRC, BPM, and Vorbis comment tagging.
"""

import json
import os
import threading
import time
import traceback
from pathlib import Path

try:
    import requests
except ImportError:
    requests = None

try:
    from mutagen.flac import FLAC, Picture
    from mutagen.id3 import ID3, TIT2, TPE1, TALB, TRCK, TDRC, TCON, TSRC, TBPM, TPE2, APIC
    from mutagen import MutagenError
except ImportError:
    FLAC = None

try:
    import yt_dlp
except ImportError:
    yt_dlp = None

try:
    from PIL import Image
    import io as _io
except ImportError:
    Image = None

# ── Global download status store ─────────────────────────────
_download_status: dict[str, dict] = {}
_output_paths: dict[str, str] = {}


# ─────────────────────────────────────────────────────────────
# TOKEN / AUTH HELPERS
# ─────────────────────────────────────────────────────────────

def _get_spotify_token() -> str:
    """Fetch an anonymous Spotify Web API token via the open-web endpoint."""
    try:
        resp = requests.get(
            "https://open.spotify.com/get_access_token",
            params={"reason": "transport", "productType": "web_player"},
            headers={
                "User-Agent": "Mozilla/5.0",
                "Accept": "application/json",
                "spotify-app-version": "1.2.30.1135",
                "App-Platform": "WebPlayer",
            },
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json().get("accessToken", "")
    except Exception as e:
        return ""


def _spotify_headers() -> dict:
    token = _get_spotify_token()
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


# ─────────────────────────────────────────────────────────────
# SEARCH
# ─────────────────────────────────────────────────────────────

def search(query: str) -> str:
    """Search Spotify for tracks, albums, and artists. Returns JSON string."""
    try:
        headers = _spotify_headers()
        resp = requests.get(
            "https://api.spotify.com/v1/search",
            headers=headers,
            params={"q": query, "type": "track,album,artist", "limit": 20, "market": "US"},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()

        tracks = [_parse_track(t) for t in data.get("tracks", {}).get("items", [])]
        albums = [_parse_album(a) for a in data.get("albums", {}).get("items", [])]
        artists = [_parse_artist(a) for a in data.get("artists", {}).get("items", [])]

        return json.dumps({"tracks": tracks, "albums": albums, "artists": artists})
    except Exception as e:
        return json.dumps({"tracks": [], "albums": [], "artists": [], "error": str(e)})


def _parse_track(t: dict) -> dict:
    images = t.get("album", {}).get("images", [])
    cover = images[0]["url"] if images else ""
    return {
        "id": t.get("id", ""),
        "title": t.get("name", ""),
        "artist": ", ".join(a["name"] for a in t.get("artists", [])),
        "albumArtist": t.get("album", {}).get("artists", [{}])[0].get("name", ""),
        "album": t.get("album", {}).get("name", ""),
        "duration": t.get("duration_ms", 0),
        "trackNumber": t.get("track_number", 0),
        "discNumber": t.get("disc_number", 1),
        "year": (t.get("album", {}).get("release_date") or "")[:4],
        "isrc": t.get("external_ids", {}).get("isrc", ""),
        "coverUrl": cover,
        "codec": "FLAC",
        "bitDepth": 24,
        "sampleRate": 44100,
        "isDownloaded": False,
        "downloadProgress": 0,
    }


def _parse_album(a: dict) -> dict:
    images = a.get("images", [])
    cover = images[0]["url"] if images else ""
    return {
        "id": a.get("id", ""),
        "name": a.get("name", ""),
        "artist": ", ".join(x["name"] for x in a.get("artists", [])),
        "coverUrl": cover,
        "year": (a.get("release_date") or "")[:4],
        "totalTracks": a.get("total_tracks", 0),
    }


def _parse_artist(a: dict) -> dict:
    images = a.get("images", [])
    img = images[0]["url"] if images else ""
    return {
        "id": a.get("id", ""),
        "name": a.get("name", ""),
        "imageUrl": img,
        "genres": a.get("genres", []),
    }


# ─────────────────────────────────────────────────────────────
# ALBUM DETAILS
# ─────────────────────────────────────────────────────────────

def get_album(album_id: str) -> str:
    """Fetch full album with tracks. Returns JSON string."""
    try:
        headers = _spotify_headers()
        resp = requests.get(
            f"https://api.spotify.com/v1/albums/{album_id}",
            headers=headers,
            params={"market": "US"},
            timeout=15,
        )
        resp.raise_for_status()
        a = resp.json()
        images = a.get("images", [])
        cover = images[0]["url"] if images else ""
        tracks = [_parse_track({**t, "album": a}) for t in a.get("tracks", {}).get("items", [])]
        return json.dumps({
            "id": a["id"],
            "name": a["name"],
            "artist": ", ".join(x["name"] for x in a.get("artists", [])),
            "coverUrl": cover,
            "year": (a.get("release_date") or "")[:4],
            "totalTracks": a.get("total_tracks", 0),
            "label": a.get("label", ""),
            "upc": a.get("external_ids", {}).get("upc", ""),
            "tracks": tracks,
        })
    except Exception as e:
        return json.dumps({"error": str(e)})


# ─────────────────────────────────────────────────────────────
# STREAM URL
# ─────────────────────────────────────────────────────────────

def get_stream_url(track_id: str) -> str:
    """
    Resolve a streamable URL for the track.
    Strategy: try multiple free source backends in order.
    """
    # Strategy 1: invidious/piped YouTube match
    url = _resolve_via_youtube(track_id)
    if url:
        return url
    return ""


def _resolve_via_youtube(track_id: str) -> str:
    """Find best YouTube audio match and return direct stream URL."""
    if not yt_dlp:
        return ""
    try:
        # First get the track title/artist from Spotify
        headers = _spotify_headers()
        resp = requests.get(
            f"https://api.spotify.com/v1/tracks/{track_id}",
            headers=headers,
            timeout=10,
        )
        resp.raise_for_status()
        t = resp.json()
        query = f"{t['name']} {t['artists'][0]['name']} audio"

        ydl_opts = {
            "quiet": True,
            "no_warnings": True,
            "format": "bestaudio[ext=webm]/bestaudio",
            "noplaylist": True,
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(f"ytsearch1:{query}", download=False)
            if info and "entries" in info and info["entries"]:
                entry = info["entries"][0]
                formats = entry.get("formats", [])
                best = max(
                    (f for f in formats if f.get("acodec") != "none"),
                    key=lambda f: f.get("abr", 0),
                    default=None,
                )
                if best:
                    return best.get("url", "")
    except Exception:
        pass
    return ""


# ─────────────────────────────────────────────────────────────
# DOWNLOAD (FLAC with full metadata)
# ─────────────────────────────────────────────────────────────

def download_track_flac(track_id: str, output_dir: str) -> str:
    """
    Download a track as FLAC with full Vorbis-comment metadata and hi-res cover art.
    Runs in a background thread; progress tracked in _download_status.
    """
    _download_status[track_id] = {"progress": 0, "speed": "", "done": False, "error": None}
    thread = threading.Thread(
        target=_download_worker,
        args=(track_id, output_dir),
        daemon=True,
    )
    thread.start()
    return "started"


def _download_worker(track_id: str, output_dir: str):
    try:
        os.makedirs(output_dir, exist_ok=True)

        # ── 1. Fetch metadata from Spotify ────────────────────
        headers = _spotify_headers()
        resp = requests.get(
            f"https://api.spotify.com/v1/tracks/{track_id}",
            headers=headers,
            timeout=10,
        )
        resp.raise_for_status()
        t = resp.json()

        title = t["name"]
        artists = ", ".join(a["name"] for a in t.get("artists", []))
        album_artist = t.get("album", {}).get("artists", [{}])[0].get("name", "")
        album_name = t.get("album", {}).get("name", "")
        track_num = t.get("track_number", 1)
        disc_num = t.get("disc_number", 1)
        year = (t.get("album", {}).get("release_date") or "")[:4]
        isrc = t.get("external_ids", {}).get("isrc", "")
        duration_ms = t.get("duration_ms", 0)
        images = t.get("album", {}).get("images", [])
        cover_url = images[0]["url"] if images else ""

        # Fetch audio features for BPM
        bpm = 0
        try:
            af_resp = requests.get(
                f"https://api.spotify.com/v1/audio-features/{track_id}",
                headers=headers,
                timeout=8,
            )
            if af_resp.ok:
                bpm = int(af_resp.json().get("tempo", 0))
        except Exception:
            pass

        # ── 2. Download via yt-dlp ────────────────────────────
        safe_title = "".join(c for c in title if c.isalnum() or c in " -_").strip()
        safe_artist = "".join(c for c in artists if c.isalnum() or c in " -_").strip()
        filename_base = f"{safe_artist} - {safe_title}"
        out_path = os.path.join(output_dir, f"{filename_base}.flac")

        query = f"{title} {artists} audio"
        _download_status[track_id]["progress"] = 5

        def ydl_progress_hook(d):
            if d["status"] == "downloading":
                total = d.get("total_bytes") or d.get("total_bytes_estimate") or 1
                downloaded = d.get("downloaded_bytes", 0)
                pct = int((downloaded / total) * 80) + 5  # 5–85%
                speed = d.get("_speed_str", "")
                _download_status[track_id]["progress"] = pct
                _download_status[track_id]["speed"] = speed

        ydl_opts = {
            "quiet": True,
            "no_warnings": True,
            "format": "bestaudio/best",
            "outtmpl": os.path.join(output_dir, f"{filename_base}.%(ext)s"),
            "postprocessors": [
                {
                    "key": "FFmpegAudioConvertor",
                    "preferredcodec": "flac",
                    "preferredquality": "0",
                }
            ],
            "postprocessor_args": [
                "-ar", "44100",
                "-sample_fmt", "s32",
            ],
            "progress_hooks": [ydl_progress_hook],
            "noplaylist": True,
        }

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([f"ytsearch1:{query}"])

        _download_status[track_id]["progress"] = 88

        # ── 3. Download hi-res cover art ──────────────────────
        cover_data = b""
        if cover_url:
            try:
                # Upgrade to 3000x3000 if available
                hires_url = cover_url.replace("/image/", "/image/").split("?")[0]
                cr = requests.get(hires_url, timeout=10)
                if cr.ok:
                    cover_data = cr.content
                    # Optionally resize to 1500x1500 to save space
                    if Image:
                        img = Image.open(_io.BytesIO(cover_data))
                        if max(img.size) > 1500:
                            img.thumbnail((1500, 1500), Image.LANCZOS)
                        buf = _io.BytesIO()
                        img.save(buf, format="JPEG", quality=95)
                        cover_data = buf.getvalue()
            except Exception:
                pass

        # ── 4. Embed Vorbis comments into FLAC ────────────────
        if os.path.exists(out_path) and FLAC:
            audio = FLAC(out_path)
            audio.clear()
            audio["title"] = title
            audio["artist"] = artists
            audio["albumartist"] = album_artist
            audio["album"] = album_name
            audio["tracknumber"] = str(track_num)
            audio["discnumber"] = str(disc_num)
            audio["date"] = year
            audio["isrc"] = isrc
            if bpm:
                audio["bpm"] = str(bpm)

            if cover_data:
                pic = Picture()
                pic.type = 3  # Front cover
                pic.mime = "image/jpeg"
                pic.desc = "Cover"
                pic.data = cover_data
                audio.add_picture(pic)

            audio.save()

        _download_status[track_id]["progress"] = 95

        # ── 5. Fetch & embed synced lyrics ────────────────────
        try:
            lrc, plain = _fetch_lyrics_internal(title, artists, duration_ms)
            if lrc and FLAC and os.path.exists(out_path):
                audio = FLAC(out_path)
                audio["lyrics"] = lrc
                audio["unsyncedlyrics"] = plain
                audio.save()
        except Exception:
            pass

        _output_paths[track_id] = out_path
        _download_status[track_id]["progress"] = 100
        _download_status[track_id]["done"] = True

    except Exception as e:
        _download_status[track_id]["error"] = traceback.format_exc()
        _download_status[track_id]["done"] = True


def get_download_status(track_id: str) -> str:
    status = _download_status.get(track_id, {"progress": 0, "speed": "", "done": False, "error": None})
    return json.dumps(status)


def get_output_path(track_id: str) -> str:
    return _output_paths.get(track_id, "")


# ─────────────────────────────────────────────────────────────
# LYRICS
# ─────────────────────────────────────────────────────────────

def get_lyrics(title: str, artist: str, duration_ms: str) -> str:
    """Fetch synced (LRC) and plain lyrics. Returns JSON with 'lrc' and 'plain' keys."""
    lrc, plain = _fetch_lyrics_internal(title, artist, int(duration_ms))
    return json.dumps({"lrc": lrc, "plain": plain})


def _fetch_lyrics_internal(title: str, artist: str, duration_ms: int) -> tuple[str, str]:
    lrc = ""
    plain = ""
    # Strategy 1: syncedlyrics
    try:
        import syncedlyrics
        lrc = syncedlyrics.search(f"{title} {artist}") or ""
    except Exception:
        pass

    # Strategy 2: lyricsgenius for plain
    if not plain:
        try:
            import lyricsgenius
            genius = lyricsgenius.Genius(verbose=False, remove_section_headers=True)
            song = genius.search_song(title, artist)
            if song:
                plain = song.lyrics
        except Exception:
            pass

    return lrc, plain


# ─────────────────────────────────────────────────────────────
# COVER ART EXTRACTION
# ─────────────────────────────────────────────────────────────

def extract_cover_art(flac_path: str, out_dir: str) -> str:
    """Extract embedded cover art from a FLAC file. Returns path to saved PNG."""
    if not FLAC:
        return ""
    try:
        audio = FLAC(flac_path)
        for pic in audio.pictures:
            if pic.type == 3:
                os.makedirs(out_dir, exist_ok=True)
                stem = Path(flac_path).stem
                out_path = os.path.join(out_dir, f"{stem}_cover.jpg")
                with open(out_path, "wb") as f:
                    f.write(pic.data)
                return out_path
    except Exception:
        pass
    return ""
