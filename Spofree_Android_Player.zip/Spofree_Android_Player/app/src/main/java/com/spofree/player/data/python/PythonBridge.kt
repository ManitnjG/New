package com.spofree.player.data.python

import android.content.Context
import com.chaquo.python.PyException
import com.chaquo.python.Python
import com.spofree.player.data.model.Track
import com.spofree.player.data.model.Album
import com.spofree.player.data.model.Artist
import com.spofree.player.data.model.SearchResult
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PythonBridge @Inject constructor(
    private val context: Context,
    private val gson: Gson
) {
    private val py by lazy { Python.getInstance() }
    private val spoModule by lazy { py.getModule("spofree_bridge") }

    /**
     * Search for tracks, albums, and artists.
     */
    suspend fun search(query: String): Result<SearchResult> = withContext(Dispatchers.IO) {
        runCatching {
            val json = spoModule.callAttr("search", query).toString()
            gson.fromJson(json, SearchResult::class.java)
        }
    }

    /**
     * Get full album details including track list.
     */
    suspend fun getAlbum(albumId: String): Result<Album> = withContext(Dispatchers.IO) {
        runCatching {
            val json = spoModule.callAttr("get_album", albumId).toString()
            gson.fromJson(json, Album::class.java)
        }
    }

    /**
     * Get a direct FLAC stream URL for a track.
     */
    suspend fun getStreamUrl(trackId: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            spoModule.callAttr("get_stream_url", trackId).toString()
        }
    }

    /**
     * Download a track as FLAC with full metadata embedding.
     * Calls back progressCallback(trackId, progressInt, speedStr)
     */
    suspend fun downloadTrack(
        trackId: String,
        outputDir: String,
        progressCallback: (Int, String) -> Unit
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            // Register a Python-callable progress hook
            val hook = py.getBuiltins().callAttr(
                "eval",
                "lambda p, s: None"  // placeholder; real one wired below
            )
            val result = spoModule.callAttr(
                "download_track_flac",
                trackId,
                outputDir
            )
            // poll status file until complete
            var lastProgress = 0
            while (true) {
                val status = spoModule.callAttr("get_download_status", trackId)
                val statusMap = gson.fromJson<Map<String, Any>>(
                    status.toString(),
                    object : TypeToken<Map<String, Any>>() {}.type
                )
                val progress = (statusMap["progress"] as? Double)?.toInt() ?: 0
                val speed = statusMap["speed"] as? String ?: ""
                val done = statusMap["done"] as? Boolean ?: false
                val error = statusMap["error"] as? String

                if (progress != lastProgress) {
                    progressCallback(progress, speed)
                    lastProgress = progress
                }
                if (done) break
                if (error != null) throw Exception(error)
                kotlinx.coroutines.delay(500)
            }
            spoModule.callAttr("get_output_path", trackId).toString()
        }
    }

    /**
     * Fetch synced LRC lyrics for a track.
     */
    suspend fun getLyrics(
        title: String,
        artist: String,
        duration: Long
    ): Result<Pair<String, String>> = withContext(Dispatchers.IO) {
        runCatching {
            val json = spoModule.callAttr("get_lyrics", title, artist, duration.toString()).toString()
            val map = gson.fromJson<Map<String, String>>(
                json,
                object : TypeToken<Map<String, String>>() {}.type
            )
            Pair(map["lrc"] ?: "", map["plain"] ?: "")
        }
    }

    /**
     * Extract cover art from a local FLAC file and return path to extracted PNG.
     */
    suspend fun extractCoverArt(flacPath: String, outDir: String): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                spoModule.callAttr("extract_cover_art", flacPath, outDir).toString()
            }
        }
}
