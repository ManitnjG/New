package com.spofree.player.data.repository

import com.spofree.player.data.db.TrackDao
import com.spofree.player.data.model.*
import com.spofree.player.data.python.PythonBridge
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MusicRepository @Inject constructor(
    private val trackDao: TrackDao,
    private val pythonBridge: PythonBridge
) {

    fun getAllTracks(): Flow<List<Track>> = trackDao.getAllTracks()
    fun getDownloadedTracks(): Flow<List<Track>> = trackDao.getDownloadedTracks()

    suspend fun getTrackById(id: String): Track? = trackDao.getTrackById(id)

    suspend fun search(query: String): Result<SearchResult> = pythonBridge.search(query)

    suspend fun getAlbum(albumId: String): Result<Album> = pythonBridge.getAlbum(albumId)

    suspend fun getStreamUrl(trackId: String): Result<String> =
        pythonBridge.getStreamUrl(trackId)

    suspend fun downloadTrack(
        trackId: String,
        outputDir: String,
        progressCallback: (Int, String) -> Unit
    ): Result<String> = pythonBridge.downloadTrack(trackId, outputDir, progressCallback)

    suspend fun getLyrics(
        title: String,
        artist: String,
        duration: Long
    ): Result<Pair<String, String>> = pythonBridge.getLyrics(title, artist, duration)

    suspend fun saveTrack(track: Track) = trackDao.insertTrack(track)
    suspend fun updateTrack(track: Track) = trackDao.updateTrack(track)
    suspend fun deleteTrack(track: Track) = trackDao.deleteTrack(track)
    suspend fun updateProgress(id: String, progress: Int) = trackDao.updateProgress(id, progress)
    suspend fun updateDownloadStatus(id: String, downloaded: Boolean, path: String) =
        trackDao.updateDownloadStatus(id, downloaded, path)

    suspend fun searchLocal(query: String): List<Track> = trackDao.searchTracks(query)
}
