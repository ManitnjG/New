package com.spofree.player.ui.library

import android.view.*
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.spofree.player.data.model.Track
import com.spofree.player.databinding.ItemTrackBinding

class LibraryAdapter(
    private val onPlay: (Track) -> Unit,
    private val onDelete: (Track) -> Unit
) : ListAdapter<Track, LibraryAdapter.VH>(object : DiffUtil.ItemCallback<Track>() {
    override fun areItemsTheSame(a: Track, b: Track) = a.id == b.id
    override fun areContentsTheSame(a: Track, b: Track) = a == b
}) {
    inner class VH(val b: ItemTrackBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(track: Track) {
            b.tvTitle.text = track.title
            b.tvArtist.text = track.artist
            b.tvCodec.text = "${track.codec} • ${track.sampleRate / 1000}kHz"
            Glide.with(b.ivCover).load(track.localCoverPath.ifEmpty { track.coverUrl })
                .into(b.ivCover)
            b.root.setOnClickListener { onPlay(track) }
            b.btnDownload.setImageResource(com.spofree.player.R.drawable.ic_delete)
            b.btnDownload.setOnClickListener { onDelete(track) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, vt: Int) =
        VH(ItemTrackBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(h: VH, pos: Int) = h.bind(getItem(pos))
}
