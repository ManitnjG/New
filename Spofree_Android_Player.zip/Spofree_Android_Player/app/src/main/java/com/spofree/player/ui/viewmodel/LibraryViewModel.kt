package com.spofree.player.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spofree.player.data.model.Track
import com.spofree.player.data.repository.MusicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val repository: MusicRepository
) : ViewModel() {

    val downloadedTracks: StateFlow<List<Track>> =
        repository.getDownloadedTracks()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTracks: StateFlow<List<Track>> =
        repository.getAllTracks()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun deleteTrack(track: Track) {
        viewModelScope.launch {
            track.localFilePath.let { path ->
                if (path.isNotEmpty()) java.io.File(path).delete()
            }
            repository.deleteTrack(track)
        }
    }
}
