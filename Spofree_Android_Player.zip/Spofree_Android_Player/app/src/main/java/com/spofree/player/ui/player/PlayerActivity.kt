package com.spofree.player.ui.player

import android.content.*
import android.os.Bundle
import android.os.IBinder
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.palette.graphics.Palette
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import com.spofree.player.data.model.RepeatMode
import com.spofree.player.data.model.Track
import com.spofree.player.databinding.ActivityPlayerBinding
import com.spofree.player.service.MusicPlayerService
import com.spofree.player.ui.viewmodel.PlayerViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TRACK = "extra_track"
    }

    private lateinit var binding: ActivityPlayerBinding
    private val viewModel: PlayerViewModel by viewModels()
    private var playerService: MusicPlayerService? = null
    private var isBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val lb = binder as MusicPlayerService.LocalBinder
            playerService = lb.getService()
            isBound = true
            viewModel.bindService(playerService!!)
            observePlaybackState()

            @Suppress("DEPRECATION")
            val track = intent.getParcelableExtra<Track>(EXTRA_TRACK)
            track?.let { viewModel.playTrack(it) }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupControls()
        bindPlayerService()
    }

    private fun bindPlayerService() {
        Intent(this, MusicPlayerService::class.java).also { intent ->
            bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        }
    }

    private fun setupControls() {
        binding.btnPlayPause.setOnClickListener { viewModel.togglePlayPause() }
        binding.btnNext.setOnClickListener { viewModel.playNext() }
        binding.btnPrevious.setOnClickListener { viewModel.playPrevious() }
        binding.btnShuffle.setOnClickListener { viewModel.toggleShuffle() }
        binding.btnRepeat.setOnClickListener {
            val current = viewModel.playbackState.value.repeatMode
            viewModel.setRepeatMode(
                when (current) {
                    RepeatMode.OFF -> RepeatMode.ALL
                    RepeatMode.ALL -> RepeatMode.ONE
                    RepeatMode.ONE -> RepeatMode.OFF
                }
            )
        }
        binding.seekBar.setOnSeekBarChangeListener(object :
            android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val pos = (p.toLong() * viewModel.playbackState.value.duration) / 100
                    viewModel.seekTo(pos)
                }
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar) {}
        })

        binding.btnBack.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
    }

    private fun observePlaybackState() {
        lifecycleScope.launch {
            viewModel.currentTrack.collect { track ->
                track?.let { updateTrackUI(it) }
            }
        }
        lifecycleScope.launch {
            viewModel.playbackState.collect { state ->
                binding.btnPlayPause.isSelected = state.isPlaying
                val duration = state.duration.coerceAtLeast(1L)
                binding.seekBar.progress = ((state.position * 100) / duration).toInt()
                binding.tvPosition.text = formatMs(state.position)
                binding.tvDuration.text = formatMs(duration)
            }
        }
    }

    private fun updateTrackUI(track: Track) {
        binding.tvTitle.text = track.title
        binding.tvArtist.text = track.artist
        binding.tvAlbum.text = track.album
        binding.tvQuality.text = "${track.codec} • ${track.sampleRate / 1000}kHz / ${track.bitDepth}bit"

        Glide.with(this)
            .asBitmap()
            .load(if (track.localCoverPath.isNotEmpty()) track.localCoverPath else track.coverUrl)
            .transform(RoundedCorners(24))
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(bm: Bitmap, t: Transition<in Bitmap>?) {
                    binding.ivAlbumArt.setImageBitmap(bm)
                    Palette.from(bm).generate { palette ->
                        palette?.dominantSwatch?.rgb?.let { color ->
                            val bg = GradientDrawable(
                                GradientDrawable.Orientation.TOP_BOTTOM,
                                intArrayOf(color, 0xFF0A0A0A.toInt())
                            )
                            binding.root.background = bg
                        }
                    }
                }
                override fun onLoadCleared(p: android.graphics.drawable.Drawable?) {}
            })
    }

    private fun formatMs(ms: Long): String {
        val min = ms / 60000
        val sec = (ms % 60000) / 1000
        return "%d:%02d".format(min, sec)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) unbindService(serviceConnection)
    }
}
