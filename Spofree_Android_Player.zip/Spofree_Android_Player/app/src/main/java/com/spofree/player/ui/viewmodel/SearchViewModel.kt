package com.spofree.player.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spofree.player.data.model.SearchResult
import com.spofree.player.data.repository.MusicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class SearchUiState {
    object Idle : SearchUiState()
    object Loading : SearchUiState()
    data class Success(val result: SearchResult) : SearchUiState()
    data class Error(val message: String) : SearchUiState()
}

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val repository: MusicRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private val _query = MutableStateFlow("")

    init {
        _query
            .debounce(400)
            .filter { it.length >= 2 }
            .distinctUntilChanged()
            .onEach { search(it) }
            .launchIn(viewModelScope)
    }

    fun onQueryChanged(q: String) { _query.value = q }

    fun search(query: String) {
        viewModelScope.launch {
            _uiState.value = SearchUiState.Loading
            repository.search(query)
                .onSuccess { _uiState.value = SearchUiState.Success(it) }
                .onFailure { _uiState.value = SearchUiState.Error(it.message ?: "Search failed") }
        }
    }
}
