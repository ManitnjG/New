package com.spofree.player.data.model

sealed class DownloadState {
    object Idle : DownloadState()
    data class Queued(val trackId: String) : DownloadState()
    data class Downloading(val trackId: String, val progress: Int, val speed: String = "") : DownloadState()
    data class Processing(val trackId: String, val step: String) : DownloadState()
    data class Completed(val trackId: String, val filePath: String) : DownloadState()
    data class Failed(val trackId: String, val error: String) : DownloadState()
}
