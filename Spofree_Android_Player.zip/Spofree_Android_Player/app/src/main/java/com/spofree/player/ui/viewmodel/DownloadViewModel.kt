package com.spofree.player.ui.viewmodel

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spofree.player.data.model.DownloadState
import com.spofree.player.data.model.Track
import com.spofree.player.data.repository.MusicRepository
import com.spofree.player.service.DownloadService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DownloadViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: MusicRepository
) : ViewModel() {

    val downloadEvents: SharedFlow<DownloadState> = DownloadService.downloadEvents

    private val _activeDownloads = MutableStateFlow<Map<String, DownloadState>>(emptyMap())
    val activeDownloads: StateFlow<Map<String, DownloadState>> = _activeDownloads.asStateFlow()

    init {
        viewModelScope.launch {
            DownloadService.downloadEvents.collect { state ->
                _activeDownloads.update { current ->
                    when (state) {
                        is DownloadState.Completed, is DownloadState.Failed ->
                            current - getTrackId(state)
                        else -> current + (getTrackId(state) to state)
                    }
                }
            }
        }
    }

    fun downloadTrack(track: Track) {
        viewModelScope.launch {
            repository.saveTrack(track)
        }
        val outDir = context.getExternalFilesDir("Music")?.absolutePath
            ?: context.filesDir.absolutePath

        val intent = Intent(context, DownloadService::class.java).apply {
            putExtra(DownloadService.EXTRA_TRACK_ID, track.id)
            putExtra(DownloadService.EXTRA_OUTPUT_DIR, outDir)
        }
        context.startForegroundService(intent)
    }

    private fun getTrackId(state: DownloadState): String = when (state) {
        is DownloadState.Queued -> state.trackId
        is DownloadState.Downloading -> state.trackId
        is DownloadState.Processing -> state.trackId
        is DownloadState.Completed -> state.trackId
        is DownloadState.Failed -> state.trackId
        else -> ""
    }
}
