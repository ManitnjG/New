package com.spofree.player.ui.search

import android.view.*
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.spofree.player.data.model.Track
import com.spofree.player.databinding.ItemTrackBinding
import java.util.concurrent.TimeUnit

class TrackResultAdapter(
    private val onPlay: (Track) -> Unit,
    private val onDownload: (Track) -> Unit
) : ListAdapter<Track, TrackResultAdapter.ViewHolder>(DIFF) {

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Track>() {
            override fun areItemsTheSame(a: Track, b: Track) = a.id == b.id
            override fun areContentsTheSame(a: Track, b: Track) = a == b
        }
    }

    inner class ViewHolder(val binding: ItemTrackBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(track: Track) {
            binding.tvTitle.text = track.title
            binding.tvArtist.text = "${track.artist} • ${formatDuration(track.duration)}"
            binding.tvCodec.text = track.codec

            Glide.with(binding.ivCover)
                .load(track.coverUrl)
                .placeholder(com.spofree.player.R.drawable.ic_album_placeholder)
                .into(binding.ivCover)

            binding.btnPlay.setOnClickListener { onPlay(track) }
            binding.btnDownload.setOnClickListener { onDownload(track) }
            binding.root.setOnClickListener { onPlay(track) }
        }
    }

    private fun formatDuration(ms: Long): String {
        val min = TimeUnit.MILLISECONDS.toMinutes(ms)
        val sec = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
        return "%d:%02d".format(min, sec)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemTrackBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(getItem(position))
}
