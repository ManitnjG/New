package com.spofree.player.data.model

data class Album(
    val id: String,
    val name: String,
    val artist: String,
    val artistId: String = "",
    val coverUrl: String = "",
    val year: String = "",
    val totalTracks: Int = 0,
    val tracks: List<Track> = emptyList(),
    val upc: String = "",
    val label: String = ""
)
