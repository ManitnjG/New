package com.spofree.player.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.spofree.player.data.model.Track

@Database(entities = [Track::class], version = 1, exportSchema = false)
abstract class SpoFreeDatabase : RoomDatabase() {
    abstract fun trackDao(): TrackDao
}
