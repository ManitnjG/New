package com.spofree.player.data.model

data class Artist(
    val id: String,
    val name: String,
    val imageUrl: String = "",
    val genres: List<String> = emptyList(),
    val albums: List<Album> = emptyList()
)
