package com.spofree.player.service

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.spofree.player.R
import com.spofree.player.data.model.DownloadState
import com.spofree.player.data.repository.MusicRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import javax.inject.Inject

@AndroidEntryPoint
class DownloadService : Service() {

    companion object {
        const val CHANNEL_ID = "spofree_download"
        const val NOTIFICATION_ID = 2001
        const val EXTRA_TRACK_ID = "track_id"
        const val EXTRA_OUTPUT_DIR = "output_dir"

        val downloadEvents = MutableSharedFlow<DownloadState>(extraBufferCapacity = 32)
    }

    @Inject lateinit var repository: MusicRepository

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val downloadQueue = ArrayDeque<Pair<String, String>>()
    private var isProcessing = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val trackId = intent?.getStringExtra(EXTRA_TRACK_ID) ?: return START_NOT_STICKY
        val outDir = intent.getStringExtra(EXTRA_OUTPUT_DIR) ?: filesDir.absolutePath

        downloadQueue.addLast(Pair(trackId, outDir))
        if (!isProcessing) processQueue()
        return START_STICKY
    }

    private fun processQueue() {
        if (downloadQueue.isEmpty()) {
            isProcessing = false
            stopSelf()
            return
        }
        isProcessing = true
        val (trackId, outDir) = downloadQueue.removeFirst()

        scope.launch {
            downloadEvents.emit(DownloadState.Queued(trackId))
            showNotification("Preparing download…", 0)

            val result = repository.downloadTrack(trackId, outDir) { progress, speed ->
                runBlocking {
                    downloadEvents.emit(DownloadState.Downloading(trackId, progress, speed))
                    showNotification("Downloading… $speed", progress)
                    repository.updateProgress(trackId, progress)
                }
            }

            result.onSuccess { filePath ->
                downloadEvents.emit(DownloadState.Completed(trackId, filePath))
                repository.updateDownloadStatus(trackId, true, filePath)
                showNotification("Download complete", 100)
            }.onFailure { err ->
                downloadEvents.emit(DownloadState.Failed(trackId, err.message ?: "Unknown error"))
                showNotification("Download failed: ${err.message}", 0)
            }

            processQueue()
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Downloads",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun showNotification(text: String, progress: Int) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SpoFree Download")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_download)
            .setProgress(100, progress, progress == 0)
            .setOngoing(true)
            .setSilent(true)
            .build()
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
