package com.spofree.player.data.model

enum class RepeatMode { OFF, ONE, ALL }

data class PlaybackState(
    val track: Track? = null,
    val isPlaying: Boolean = false,
    val position: Long = 0L,
    val duration: Long = 0L,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val isShuffled: Boolean = false,
    val buffering: Boolean = false,
    val error: String? = null
)
