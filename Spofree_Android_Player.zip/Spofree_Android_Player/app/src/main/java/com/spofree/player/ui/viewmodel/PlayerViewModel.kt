package com.spofree.player.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spofree.player.data.model.*
import com.spofree.player.data.repository.MusicRepository
import com.spofree.player.service.MusicPlayerService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val repository: MusicRepository
) : ViewModel() {

    private val _currentTrack = MutableStateFlow<Track?>(null)
    val currentTrack: StateFlow<Track?> = _currentTrack.asStateFlow()

    private val _lyrics = MutableStateFlow<Pair<String, String>>("" to "")
    val lyrics: StateFlow<Pair<String, String>> = _lyrics.asStateFlow()

    private var playerService: MusicPlayerService? = null

    val playbackState: StateFlow<PlaybackState>
        get() = playerService?.playbackState ?: MutableStateFlow(PlaybackState())

    fun bindService(service: MusicPlayerService) {
        playerService = service
    }

    fun playTrack(track: Track, queue: List<Track> = listOf(track)) {
        _currentTrack.value = track
        playerService?.playTrack(track, queue)
        loadLyrics(track)
    }

    private fun loadLyrics(track: Track) {
        viewModelScope.launch {
            repository.getLyrics(track.title, track.artist, track.duration)
                .onSuccess { _lyrics.value = it }
                .onFailure { _lyrics.value = "" to "" }
        }
    }

    fun togglePlayPause() = playerService?.togglePlayPause()
    fun seekTo(pos: Long) = playerService?.seekTo(pos)
    fun playNext() = playerService?.playNext()
    fun playPrevious() = playerService?.playPrevious()
    fun setRepeatMode(mode: RepeatMode) = playerService?.setRepeatMode(mode)
    fun toggleShuffle() = playerService?.toggleShuffle()
}
