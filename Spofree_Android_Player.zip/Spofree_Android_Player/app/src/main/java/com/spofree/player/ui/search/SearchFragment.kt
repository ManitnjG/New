package com.spofree.player.ui.search

import android.os.Bundle
import android.view.*
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.spofree.player.databinding.FragmentSearchBinding
import com.spofree.player.ui.viewmodel.SearchUiState
import com.spofree.player.ui.viewmodel.SearchViewModel
import com.spofree.player.ui.viewmodel.DownloadViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class SearchFragment : Fragment() {

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SearchViewModel by viewModels()
    private val downloadViewModel: DownloadViewModel by viewModels()
    private lateinit var trackAdapter: TrackResultAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ) = FragmentSearchBinding.inflate(inflater, container, false).also { _binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        trackAdapter = TrackResultAdapter(
            onPlay = { track ->
                // launch player
            },
            onDownload = { track ->
                downloadViewModel.downloadTrack(track)
            }
        )

        binding.rvResults.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = trackAdapter
        }

        binding.etSearch.doOnTextChanged { text, _, _, _ ->
            viewModel.onQueryChanged(text.toString())
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                when (state) {
                    is SearchUiState.Idle -> binding.progressBar.visibility = View.GONE
                    is SearchUiState.Loading -> binding.progressBar.visibility = View.VISIBLE
                    is SearchUiState.Success -> {
                        binding.progressBar.visibility = View.GONE
                        trackAdapter.submitList(state.result.tracks)
                    }
                    is SearchUiState.Error -> {
                        binding.progressBar.visibility = View.GONE
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
