package com.spofree.player.di

import android.content.Context
import androidx.room.Room
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.spofree.player.data.db.SpoFreeDatabase
import com.spofree.player.data.db.TrackDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): SpoFreeDatabase =
        Room.databaseBuilder(ctx, SpoFreeDatabase::class.java, "spofree.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    @Singleton
    fun provideTrackDao(db: SpoFreeDatabase): TrackDao = db.trackDao()

    @Provides
    @Singleton
    fun provideGson(): Gson = GsonBuilder().setLenient().create()

    @Provides
    @Singleton
    fun provideContext(@ApplicationContext ctx: Context): Context = ctx
}
