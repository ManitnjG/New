package com.spofree.player.ui.player

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import com.spofree.player.R
import kotlinx.coroutines.*

/**
 * Parses and displays synchronized LRC lyrics,
 * highlighting the current line based on playback position.
 */
class LyricsView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    private data class LrcLine(val timeMs: Long, val text: String)

    private val lines = mutableListOf<LrcLine>()
    private var currentHighlight = -1

    private val lrcRegex = Regex("""\[(\d{2}):(\d{2})\.(\d{2,3})\](.*)"""

    )

    fun setLrc(lrc: String) {
        removeAllViews()
        lines.clear()
        currentHighlight = -1

        lrc.lines().forEach { line ->
            val match = lrcRegex.find(line) ?: return@forEach
            val min = match.groupValues[1].toLong()
            val sec = match.groupValues[2].toLong()
            val ms = match.groupValues[3].padEnd(3, '0').take(3).toLong()
            val text = match.groupValues[4].trim()
            if (text.isNotEmpty()) {
                lines.add(LrcLine((min * 60 + sec) * 1000 + ms, text))
                val tv = TextView(context).apply {
                    this.text = text
                    textSize = 16f
                    setPadding(0, 12, 0, 12)
                    alpha = 0.5f
                    setTextColor(resources.getColor(R.color.lyrics_default, null))
                }
                addView(tv)
            }
        }
    }

    fun updatePosition(posMs: Long) {
        val idx = lines.indexOfLast { it.timeMs <= posMs }
        if (idx == currentHighlight) return
        currentHighlight = idx
        for (i in 0 until childCount) {
            val tv = getChildAt(i) as? TextView ?: continue
            if (i == idx) {
                tv.alpha = 1f
                tv.textSize = 18f
                tv.setTextColor(resources.getColor(R.color.lyrics_highlight, null))
            } else {
                tv.alpha = 0.5f
                tv.textSize = 16f
                tv.setTextColor(resources.getColor(R.color.lyrics_default, null))
            }
        }
    }
}
