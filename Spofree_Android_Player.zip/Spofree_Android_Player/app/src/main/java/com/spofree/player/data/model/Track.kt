package com.spofree.player.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class Track(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val albumArtist: String = "",
    val album: String = "",
    val duration: Long = 0L,          // ms
    val trackNumber: Int = 0,
    val discNumber: Int = 1,
    val year: String = "",
    val genre: String = "",
    val isrc: String = "",
    val bpm: Int = 0,
    val coverUrl: String = "",
    val localCoverPath: String = "",
    val streamUrl: String = "",
    val localFilePath: String = "",
    val lyricsLrc: String = "",        // synced LRC
    val lyricsPlain: String = "",
    val isDownloaded: Boolean = false,
    val downloadProgress: Int = 0,
    val fileSize: Long = 0L,
    val bitDepth: Int = 24,
    val sampleRate: Int = 44100,
    val codec: String = "FLAC",
    val addedAt: Long = System.currentTimeMillis()
)
