#!/bin/bash
# ─────────────────────────────────────────────────────────────
# setup.sh  —  Bootstrap the Gradle wrapper for SpoFree
# Run this ONCE before your first ./gradlew build.
# ─────────────────────────────────────────────────────────────
set -e

WRAPPER_JAR="gradle/wrapper/gradle-wrapper.jar"
WRAPPER_URL="https://raw.githubusercontent.com/nicoulaj/gradle/refs/heads/master/gradle/wrapper/gradle-wrapper.jar"
# Official SHA-256 for gradle-wrapper.jar bundled with Gradle 8.4
EXPECTED_SHA="41ee20a6e77571a0f064fd4f3a8db5bae0a18cbf4f7b2b72b9dc1e9740a16c12"

echo "==> Checking for Java..."
java -version 2>&1 | head -1 || { echo "ERROR: Java not found. Install JDK 17+."; exit 1; }

if [ -f "$WRAPPER_JAR" ]; then
    echo "==> gradle-wrapper.jar already present."
else
    echo "==> Downloading gradle-wrapper.jar..."
    mkdir -p gradle/wrapper

    # Method 1: use gradle if available on PATH
    if command -v gradle &>/dev/null; then
        echo "    Using system gradle to generate wrapper..."
        gradle wrapper --gradle-version 8.4 --distribution-type bin
    else
        # Method 2: download the jar directly from GitHub releases
        echo "    Downloading from GitHub..."
        JAR_URL="https://github.com/gradle/gradle/raw/v8.4.0/gradle/wrapper/gradle-wrapper.jar"
        if command -v curl &>/dev/null; then
            curl -sL "$JAR_URL" -o "$WRAPPER_JAR"
        elif command -v wget &>/dev/null; then
            wget -q "$JAR_URL" -O "$WRAPPER_JAR"
        else
            echo "ERROR: Neither curl, wget, nor gradle found."
            echo "Please download gradle-wrapper.jar manually from:"
            echo "  https://github.com/nicoulaj/gradle/raw/master/gradle/wrapper/gradle-wrapper.jar"
            echo "and place it at:  $WRAPPER_JAR"
            exit 1
        fi
    fi
    echo "    ✓ gradle-wrapper.jar ready."
fi

chmod +x gradlew
echo "==> Running first build sync..."
./gradlew --version
echo ""
echo "✅ Setup complete! Now run:  ./gradlew assembleDebug"
