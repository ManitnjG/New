# SpoFree — Native Android FLAC Audio Player & Downloader

> A premium lossless music app built with Kotlin + ExoPlayer + Chaquopy (Python).

## Features
- 🎵 **Lossless FLAC** playback via ExoPlayer Media3
- 📥 **Background downloads** with foreground service + progress notifications
- 🏷️ **Full metadata** — Vorbis comments: title, artist, album artist, track #, disc #, year, ISRC, BPM, genre
- 🖼️ **Hi-res cover art** (up to 1500×1500) embedded in FLAC + displayed with palette-driven UI
- 📝 **Synced LRC lyrics** embedded in FLAC and displayed in-app with line highlighting
- 🔍 **Search** via Spotify Web API (no key needed — anonymous token)
- 📚 **Local library** with Room database
- 🏗️ **MVVM + Hilt** architecture with Kotlin Coroutines

## Stack
| Layer | Technology |
|---|---|
| UI | Kotlin + ViewBinding + Material3 |
| Player | ExoPlayer / Media3 |
| DI | Hilt |
| DB | Room |
| Downloads | WorkManager + ForegroundService |
| Python | Chaquopy 15 (Python 3.11) |
| Metadata | mutagen (FLAC / Vorbis) |
| Audio DL | yt-dlp + FFmpeg post-processor |
| Lyrics | syncedlyrics + lyricsgenius |

## Setup
1. Open in Android Studio Hedgehog or later.
2. Android SDK 34 + NDK required.
3. Run `./gradlew assembleDebug`.
4. Chaquopy will pip-install all Python dependencies on first build.

## Legal Notice
This project is for **educational purposes only**.
Downloading copyrighted music without authorization may violate laws in your jurisdiction.
Always respect artists and support them through official channels.

## Architecture
```
SpoFreeApplication (Hilt)
├── ui/
│   ├── MainActivity          (bottom nav host)
│   ├── search/SearchFragment  (search + results)
│   ├── library/LibraryFragment(downloaded tracks)
│   └── player/PlayerActivity  (full-screen player)
├── service/
│   ├── MusicPlayerService    (ExoPlayer foreground)
│   └── DownloadService       (FLAC download foreground)
├── data/
│   ├── model/                (Track, Album, Artist, …)
│   ├── db/                   (Room DAO)
│   ├── python/PythonBridge   (Chaquopy interface)
│   └── repository/           (single source of truth)
└── di/AppModule              (Hilt providers)
```
