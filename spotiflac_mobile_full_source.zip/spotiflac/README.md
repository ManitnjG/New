# SpotiFLAC Mobile — Full Android Source

Flutter + Go Android app for downloading Spotify tracks in true FLAC quality from Tidal, Qobuz & Amazon Music. Based on [zarzet/SpotiFLAC-Mobile](https://github.com/zarzet/SpotiFLAC-Mobile).

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                      Flutter UI (Dart)                        │
│  Riverpod providers ← screens ← widgets ← mini/full player   │
└──────────────────────┬───────────────────────────────────────┘
                       │ MethodChannel / EventChannel
┌──────────────────────▼───────────────────────────────────────┐
│              Kotlin Plugin (SpotiFlacPlugin.kt)               │
│       SAF folder picker · JNI bridge · progress events        │
└──────────────────────┬───────────────────────────────────────┘
                       │ JNI  (System.loadLibrary)
┌──────────────────────▼───────────────────────────────────────┐
│            Go Backend  (libspotiflac.so)                      │
│  Spotify search · Tidal/Qobuz/Amazon FLAC download · FFmpeg   │
│  library scan (SAF) · metadata · extension system             │
└──────────────────────────────────────────────────────────────┘
```

## Project Structure

```
lib/
├── main.dart                        Entry point — Material 3 + AudioService init
├── models/track.dart                Track model with FLAC metadata fields
├── providers/
│   ├── player_provider.dart         Riverpod player state (queue, position, repeat)
│   ├── track_provider.dart          Search state — calls Go backend
│   ├── download_provider.dart       Concurrent download queue (max 3)
│   ├── library_provider.dart        SAF-based local library scan
│   └── theme_provider.dart          ThemeMode persistence
├── services/
│   ├── audio_handler.dart           just_audio + audio_service background handler
│   └── platform_bridge.dart        Dart ↔ Go MethodChannel wrapper
├── screens/
│   ├── root_screen.dart             Bottom NavigationBar + mini player anchor
│   ├── home_tab.dart                Search / download tab
│   ├── library_tab.dart             Local FLAC library with SAF scan
│   ├── history_tab.dart             Download history with swipeable tabs
│   ├── full_player_screen.dart      Full-screen player
│   └── settings/settings_tab.dart  Settings + about
└── widgets/
    └── mini_player.dart             Persistent bottom mini player

android/
├── app/src/main/
│   ├── kotlin/com/spotiflac/app/
│   │   ├── MainActivity.kt          FlutterActivity + SAF launcher
│   │   └── SpotiFlacPlugin.kt       MethodChannel handler + JNI bridge
│   ├── jniLibs/                     ← Place compiled libspotiflac.so here
│   │   ├── arm64-v8a/
│   │   ├── armeabi-v7a/
│   │   └── x86_64/
│   ├── AndroidManifest.xml
│   └── res/

go_backend/
└── exports.go                       JNI-exported Go functions (stubs + real impl)

scripts/
└── build_android.sh                 Cross-compile Go → .so for all ABIs
```

## Build Instructions

### Prerequisites

| Tool | Version |
|---|---|
| Flutter SDK | ≥ 3.3.0 |
| Android SDK | API 21+ |
| Go | ≥ 1.22 |
| Android NDK | r25+ |
| Java | 17 |

### Step 1 — Build the Go backend (.so)

```bash
# Set NDK path
export ANDROID_NDK_ROOT=$HOME/Android/Sdk/ndk/27.0.12077973

# Build libspotiflac.so for all ABIs
bash scripts/build_android.sh

# Or single arch (faster for testing)
bash scripts/build_android.sh --arch arm64
```

The compiled `.so` files land in:
```
android/app/src/main/jniLibs/
  arm64-v8a/libspotiflac.so      ← recommended for modern devices
  armeabi-v7a/libspotiflac.so
  x86_64/libspotiflac.so
```

### Step 2 — Flutter dependencies

```bash
flutter pub get
```

### Step 3 — Run / build

```bash
# Debug on connected device
flutter run

# Release APK (arm64 recommended)
flutter build apk --release --target-platform android-arm64

# Universal APK
flutter build apk --release

# AAB for Play Store
flutter build appbundle --release
```

Output APK: `build/app/outputs/flutter-apk/app-release.apk`

## Features

- **FLAC Playback** — `just_audio` with background service via `audio_service`
- **Mini Player** — Persistent bottom bar with progress, prev/play/pause/next
- **Full Player** — Rotating album art, seek bar, shuffle/repeat, queue view, volume, FLAC quality card
- **Search** — Spotify URL or query → Go backend → results with per-track download buttons
- **Download** — Up to 3 concurrent downloads; real-time progress via EventChannel
- **Local Library** — SAF folder picker (no `MANAGE_EXTERNAL_STORAGE` on Android 10+); incremental scan with file cache
- **History** — Swipeable All / Albums / Singles tabs; swipe-to-delete
- **Material 3 + Dynamic Color** — Follows system color scheme (Android 12+)
- **Extension System** — Install `.spotiflac-ext` bundles from Store or manually
- **Track Metadata** — Bit depth, sample rate, FLAC Hi-Res detection

## Key Packages

| Package | Purpose |
|---|---|
| `just_audio` | FLAC/audio playback engine |
| `audio_service` | Background playback + notification controls |
| `flutter_riverpod` | State management |
| `dynamic_color` | Material 3 dynamic colors (Android 12+) |
| `cached_network_image` | Album art caching |
| `permission_handler` | Runtime storage permissions |
| `shared_preferences` | Settings + history persistence |

## Disclaimer

For **educational and private use only**. Not affiliated with Spotify, Tidal, Qobuz, or Amazon Music. You are responsible for compliance with applicable laws and Terms of Service.

## License

MIT
