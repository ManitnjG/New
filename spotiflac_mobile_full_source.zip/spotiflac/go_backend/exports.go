// go_backend/exports.go
//
// This file defines all JNI-exported functions that the Kotlin SpotiFlacPlugin
// calls via System.loadLibrary("spotiflac").
//
// Build command (from repo root):
//   GOOS=android GOARCH=arm64 CGO_ENABLED=1 \
//     CC=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android21-clang \
//     go build -buildmode=c-shared -o android/app/src/main/jniLibs/arm64-v8a/libspotiflac.so ./go_backend
//
// The build script at scripts/build_android.sh automates this for all ABIs.

package main

import "C"

import (
	"encoding/json"
	"fmt"
	"unsafe"
)

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

//export Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeInitialize
func Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeInitialize(
	env *C.JNIEnv, class C.jclass,
) C.jint {
	if err := initialize(); err != nil {
		return C.jint(-1)
	}
	return C.jint(0)
}

// ---------------------------------------------------------------------------
// Search
// ---------------------------------------------------------------------------

//export Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeSearchSpotify
func Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeSearchSpotify(
	env *C.JNIEnv, class C.jclass,
	jQuery C.jstring,
) C.jstring {
	query := jStringToGo(env, jQuery)
	result, err := searchSpotify(query)
	if err != nil {
		return goStringToJ(env, `{"error":"`+err.Error()+`"}`)
	}
	b, _ := json.Marshal(result)
	return goStringToJ(env, string(b))
}

// ---------------------------------------------------------------------------
// Download
// ---------------------------------------------------------------------------

//export Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeDownloadTrack
func Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeDownloadTrack(
	env *C.JNIEnv, class C.jclass,
	jTrackID, jISRC, jTitle, jArtist, jAlbum, jOutputDir, jQuality, jProvider C.jstring,
) C.jstring {
	trackID := jStringToGo(env, jTrackID)
	isrc := jStringToGo(env, jISRC)
	title := jStringToGo(env, jTitle)
	artist := jStringToGo(env, jArtist)
	album := jStringToGo(env, jAlbum)
	outputDir := jStringToGo(env, jOutputDir)
	quality := jStringToGo(env, jQuality)
	provider := jStringToGo(env, jProvider)

	path, err := downloadTrack(trackID, isrc, title, artist, album, outputDir, quality, provider)
	if err != nil {
		throwException(env, err.Error())
		return goStringToJ(env, "")
	}
	return goStringToJ(env, path)
}

// ---------------------------------------------------------------------------
// Library scan
// ---------------------------------------------------------------------------

//export Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeScanLibrary
func Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeScanLibrary(
	env *C.JNIEnv, class C.jclass,
	jFolderPath C.jstring, jIncremental C.jboolean,
) C.jstring {
	folderPath := jStringToGo(env, jFolderPath)
	incremental := jIncremental != 0
	tracks, err := scanLibrary(folderPath, incremental)
	if err != nil {
		throwException(env, err.Error())
		return goStringToJ(env, "[]")
	}
	b, _ := json.Marshal(tracks)
	return goStringToJ(env, string(b))
}

// ---------------------------------------------------------------------------
// Metadata
// ---------------------------------------------------------------------------

//export Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeReadMetadata
func Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeReadMetadata(
	env *C.JNIEnv, class C.jclass,
	jPath C.jstring,
) C.jstring {
	path := jStringToGo(env, jPath)
	meta, err := readMetadata(path)
	if err != nil {
		return goStringToJ(env, "{}")
	}
	b, _ := json.Marshal(meta)
	return goStringToJ(env, string(b))
}

// ---------------------------------------------------------------------------
// Audio conversion (FFmpeg)
// ---------------------------------------------------------------------------

//export Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeConvertAudio
func Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeConvertAudio(
	env *C.JNIEnv, class C.jclass,
	jInput, jFormat C.jstring, jBitrate C.jint,
) C.jstring {
	inputPath := jStringToGo(env, jInput)
	outputFormat := jStringToGo(env, jFormat)
	bitrateKbps := int(jBitrate)
	outPath, err := convertAudio(inputPath, outputFormat, bitrateKbps)
	if err != nil {
		throwException(env, err.Error())
		return goStringToJ(env, "")
	}
	return goStringToJ(env, outPath)
}

// ---------------------------------------------------------------------------
// Extensions
// ---------------------------------------------------------------------------

//export Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeListExtensions
func Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeListExtensions(
	env *C.JNIEnv, class C.jclass,
) C.jstring {
	list := listExtensions()
	b, _ := json.Marshal(list)
	return goStringToJ(env, string(b))
}

//export Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeInstallExtension
func Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeInstallExtension(
	env *C.JNIEnv, class C.jclass, jPath C.jstring,
) C.jint {
	path := jStringToGo(env, jPath)
	if err := installExtension(path); err != nil {
		return C.jint(-1)
	}
	return C.jint(0)
}

//export Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeRemoveExtensionByID
func Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeRemoveExtensionByID(
	env *C.JNIEnv, class C.jclass, jID C.jstring,
) C.jint {
	id := jStringToGo(env, jID)
	if err := removeExtensionByID(id); err != nil {
		return C.jint(-1)
	}
	return C.jint(0)
}

//export Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeUpgradeExtension
func Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeUpgradeExtension(
	env *C.JNIEnv, class C.jclass, jID C.jstring,
) C.jint {
	id := jStringToGo(env, jID)
	if err := upgradeExtension(id); err != nil {
		return C.jint(-1)
	}
	return C.jint(0)
}

//export Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeGetVersion
func Java_com_spotiflac_app_SpotiFlacPlugin_00024Companion_nativeGetVersion(
	env *C.JNIEnv, class C.jclass,
) C.jstring {
	return goStringToJ(env, AppVersion)
}

// ---------------------------------------------------------------------------
// JNI helpers (minimal, no external deps)
// ---------------------------------------------------------------------------

func jStringToGo(env *C.JNIEnv, js C.jstring) string {
	if js == nil {
		return ""
	}
	cStr := C.GetStringUTFChars(env, js, nil)
	defer C.ReleaseStringUTFChars(env, js, cStr)
	return C.GoString(cStr)
}

func goStringToJ(env *C.JNIEnv, s string) C.jstring {
	cs := C.CString(s)
	defer C.free(unsafe.Pointer(cs))
	return C.NewStringUTF(env, cs)
}

func throwException(env *C.JNIEnv, msg string) {
	className := C.CString("java/lang/RuntimeException")
	defer C.free(unsafe.Pointer(className))
	clazz := C.FindClass(env, className)
	cmsg := C.CString(msg)
	defer C.free(unsafe.Pointer(cmsg))
	C.ThrowNew(env, clazz, cmsg)
}

func main() {}

// AppVersion is set at build time via -ldflags
var AppVersion = "3.7.1"

// Stubs — replace with real implementations in the other .go files
func initialize() error                { return nil }
func searchSpotify(q string) (interface{}, error) { return map[string]interface{}{"tracks": []interface{}{}}, nil }
func downloadTrack(id, isrc, title, artist, album, outDir, quality, provider string) (string, error) {
	return fmt.Sprintf("%s/%s - %s.flac", outDir, artist, title), nil
}
func scanLibrary(folder string, incremental bool) ([]interface{}, error) { return []interface{}{}, nil }
func readMetadata(path string) (interface{}, error)                       { return map[string]interface{}{}, nil }
func convertAudio(input, format string, bitrate int) (string, error)      { return input, nil }
func listExtensions() []interface{}                                        { return []interface{}{} }
func installExtension(path string) error                                   { return nil }
func removeExtensionByID(id string) error                                  { return nil }
func upgradeExtension(id string) error                                     { return nil }
