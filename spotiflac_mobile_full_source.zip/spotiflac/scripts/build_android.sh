#!/usr/bin/env bash
# scripts/build_android.sh
#
# Compiles the Go backend to Android shared libraries for arm64, armv7, and x86_64.
# Run this from the repo root before `flutter build apk`.
#
# Prerequisites:
#   - Go 1.22+
#   - Android NDK r25+ (set ANDROID_NDK_ROOT or it defaults to $ANDROID_HOME/ndk/latest)
#   - JAVA_HOME set
#
# Usage:
#   bash scripts/build_android.sh
#   bash scripts/build_android.sh --arch arm64   # single arch only

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GO_SRC="$REPO_ROOT/go_backend"
JNI_DIR="$REPO_ROOT/android/app/src/main/jniLibs"
NDK="${ANDROID_NDK_ROOT:-${ANDROID_HOME:-$HOME/Android/Sdk}/ndk/$(ls ${ANDROID_HOME:-$HOME/Android/Sdk}/ndk/ | sort -V | tail -1)}"
MIN_SDK=21

echo "==> NDK: $NDK"
echo "==> Go source: $GO_SRC"
echo "==> Output: $JNI_DIR"
echo ""

build_abi() {
    local ABI="$1"
    local GOARCH="$2"
    local CC_TRIPLE="$3"
    local GOARM="${4:-}"

    local OUT="$JNI_DIR/$ABI"
    mkdir -p "$OUT"

    local CC="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/${CC_TRIPLE}${MIN_SDK}-clang"
    local AR="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-ar"

    echo "--- Building $ABI ($GOARCH) ---"
    env GOOS=android \
        GOARCH="$GOARCH" \
        ${GOARM:+GOARM=$GOARM} \
        CGO_ENABLED=1 \
        CC="$CC" \
        AR="$AR" \
        CGO_CFLAGS="-D__ANDROID_API__=$MIN_SDK" \
        CGO_LDFLAGS="-Wl,--build-id=none" \
        go build \
            -buildmode=c-shared \
            -trimpath \
            -ldflags="-s -w -X main.AppVersion=$(git describe --tags --abbrev=0 2>/dev/null || echo '3.7.1')" \
            -o "$OUT/libspotiflac.so" \
            "$GO_SRC"

    echo "    => $OUT/libspotiflac.so ($(du -sh "$OUT/libspotiflac.so" | cut -f1))"
}

# Parse --arch flag
TARGET_ARCH="${1:-all}"
case "$TARGET_ARCH" in
    --arch)
        TARGET_ARCH="$2"
        ;;
    all)
        TARGET_ARCH="all"
        ;;
esac

if [[ "$TARGET_ARCH" == "all" || "$TARGET_ARCH" == "arm64" ]]; then
    build_abi "arm64-v8a"  "arm64"   "aarch64-linux-android"
fi
if [[ "$TARGET_ARCH" == "all" || "$TARGET_ARCH" == "armv7" ]]; then
    build_abi "armeabi-v7a" "arm"    "armv7a-linux-androideabi" "7"
fi
if [[ "$TARGET_ARCH" == "all" || "$TARGET_ARCH" == "x86_64" ]]; then
    build_abi "x86_64"     "amd64"   "x86_64-linux-android"
fi

echo ""
echo "==> Done. Now run: flutter build apk --release"
