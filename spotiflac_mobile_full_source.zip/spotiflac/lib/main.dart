import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:audio_service/audio_service.dart';
import 'package:dynamic_color/dynamic_color.dart';

import 'services/audio_handler.dart';
import 'services/platform_bridge.dart';
import 'screens/root_screen.dart';
import 'providers/theme_provider.dart';

late AudioHandler audioHandler;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Colors.transparent,
    systemNavigationBarDividerColor: Colors.transparent,
  ));

  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  // Initialize Go backend
  await PlatformBridge.initialize();

  // Background audio
  audioHandler = await AudioService.init(
    builder: () => SpotiFlacAudioHandler(),
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'com.spotiflac.app.audio',
      androidNotificationChannelName: 'SpotiFLAC',
      androidNotificationOngoing: true,
      androidStopForegroundOnPause: true,
      androidNotificationIcon: 'drawable/ic_notification',
      notificationColor: Color(0xFF1DB954),
    ),
  );

  runApp(const ProviderScope(child: SpotiFLACApp()));
}

class SpotiFLACApp extends ConsumerWidget {
  const SpotiFLACApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);

    return DynamicColorBuilder(
      builder: (ColorScheme? lightScheme, ColorScheme? darkScheme) {
        final ColorScheme lightColorScheme = lightScheme ??
            ColorScheme.fromSeed(seedColor: const Color(0xFF1DB954));
        final ColorScheme darkColorScheme = darkScheme ??
            ColorScheme.fromSeed(
              seedColor: const Color(0xFF1DB954),
              brightness: Brightness.dark,
            );

        return MaterialApp(
          title: 'SpotiFLAC',
          debugShowCheckedModeBanner: false,
          themeMode: themeMode,
          theme: ThemeData(
            useMaterial3: true,
            colorScheme: lightColorScheme,
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            colorScheme: darkColorScheme,
          ),
          home: const RootScreen(),
        );
      },
    );
  }
}
