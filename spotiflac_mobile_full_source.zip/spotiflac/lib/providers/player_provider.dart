import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:audio_service/audio_service.dart';
import '../main.dart';
import '../models/track.dart';
import '../services/audio_handler.dart';

// ─────────────────────────────────────────────────────────────────────────────
// State
// ─────────────────────────────────────────────────────────────────────────────

enum RepeatMode { none, one, all }

class PlayerState {
  final Track? currentTrack;
  final List<Track> queue;
  final int currentIndex;
  final bool isPlaying;
  final Duration position;
  final Duration duration;
  final bool shuffle;
  final RepeatMode repeatMode;
  final double volume;
  final double speed;

  const PlayerState({
    this.currentTrack,
    this.queue = const [],
    this.currentIndex = 0,
    this.isPlaying = false,
    this.position = Duration.zero,
    this.duration = Duration.zero,
    this.shuffle = false,
    this.repeatMode = RepeatMode.none,
    this.volume = 1.0,
    this.speed = 1.0,
  });

  double get progress {
    if (duration.inMilliseconds == 0) return 0;
    return (position.inMilliseconds / duration.inMilliseconds).clamp(0.0, 1.0);
  }

  PlayerState copyWith({
    Track? currentTrack,
    List<Track>? queue,
    int? currentIndex,
    bool? isPlaying,
    Duration? position,
    Duration? duration,
    bool? shuffle,
    RepeatMode? repeatMode,
    double? volume,
    double? speed,
  }) =>
      PlayerState(
        currentTrack: currentTrack ?? this.currentTrack,
        queue: queue ?? this.queue,
        currentIndex: currentIndex ?? this.currentIndex,
        isPlaying: isPlaying ?? this.isPlaying,
        position: position ?? this.position,
        duration: duration ?? this.duration,
        shuffle: shuffle ?? this.shuffle,
        repeatMode: repeatMode ?? this.repeatMode,
        volume: volume ?? this.volume,
        speed: speed ?? this.speed,
      );
}

// ─────────────────────────────────────────────────────────────────────────────
// Provider
// ─────────────────────────────────────────────────────────────────────────────

final playerProvider =
    StateNotifierProvider<PlayerNotifier, PlayerState>((ref) {
  return PlayerNotifier(audioHandler as SpotiFlacAudioHandler);
});

class PlayerNotifier extends StateNotifier<PlayerState> {
  final SpotiFlacAudioHandler _handler;

  PlayerNotifier(this._handler) : super(const PlayerState()) {
    _listenStreams();
  }

  void _listenStreams() {
    _handler.positionStream.listen((pos) {
      state = state.copyWith(position: pos);
    });
    _handler.durationStream.listen((dur) {
      if (dur != null) state = state.copyWith(duration: dur);
    });
    _handler.playingStream.listen((playing) {
      state = state.copyWith(isPlaying: playing);
    });
    _handler.currentIndexStream.listen((idx) {
      if (idx != null && idx < state.queue.length) {
        state = state.copyWith(
          currentIndex: idx,
          currentTrack: state.queue[idx],
        );
      }
    });
  }

  // ── Playback ─────────────────────────────────────────────────────────────

  Future<void> playTrack(Track track, {List<Track>? queue}) async {
    final trackList = queue ?? (state.queue.isNotEmpty ? state.queue : [track]);
    final idx = trackList.indexWhere((t) => t.id == track.id);
    final startIndex = idx < 0 ? 0 : idx;
    final finalQueue = idx < 0 ? [track, ...trackList] : trackList;

    state = state.copyWith(
      queue: finalQueue,
      currentIndex: startIndex,
      currentTrack: track,
      duration: Duration.zero,
      position: Duration.zero,
    );

    await _handler.loadQueue(
      finalQueue.map((t) => t.toMediaItem()).toList(),
      startIndex: startIndex,
    );
  }

  Future<void> playAll(List<Track> tracks, {int startIndex = 0}) async {
    if (tracks.isEmpty) return;
    await playTrack(tracks[startIndex], queue: tracks);
  }

  Future<void> togglePlay() async =>
      state.isPlaying ? await _handler.pause() : await _handler.play();

  Future<void> next() => _handler.skipToNext();
  Future<void> previous() => _handler.skipToPrevious();
  Future<void> seek(Duration pos) => _handler.seek(pos);

  Future<void> seekToProgress(double progress) {
    final ms = (state.duration.inMilliseconds * progress).round();
    return seek(Duration(milliseconds: ms));
  }

  // ── Queue ─────────────────────────────────────────────────────────────────

  Future<void> addToQueue(Track track) async {
    final newQueue = [...state.queue, track];
    state = state.copyWith(queue: newQueue);
    await _handler.addQueueItem(track.toMediaItem());
  }

  Future<void> removeFromQueue(int index) async {
    if (index == state.currentIndex) return; // can't remove playing
    final newQueue = [...state.queue]..removeAt(index);
    state = state.copyWith(queue: newQueue);
  }

  // ── Shuffle / Repeat ──────────────────────────────────────────────────────

  Future<void> toggleShuffle() async {
    final on = !state.shuffle;
    state = state.copyWith(shuffle: on);
    await _handler.setShuffleMode(
        on ? AudioServiceShuffleMode.all : AudioServiceShuffleMode.none);
  }

  Future<void> cycleRepeat() async {
    final next = switch (state.repeatMode) {
      RepeatMode.none => RepeatMode.all,
      RepeatMode.all => RepeatMode.one,
      RepeatMode.one => RepeatMode.none,
    };
    state = state.copyWith(repeatMode: next);
    await _handler.setRepeatMode(switch (next) {
      RepeatMode.none => AudioServiceRepeatMode.none,
      RepeatMode.all => AudioServiceRepeatMode.all,
      RepeatMode.one => AudioServiceRepeatMode.one,
    });
  }

  // ── Volume / Speed ────────────────────────────────────────────────────────

  Future<void> setVolume(double v) async {
    state = state.copyWith(volume: v);
    await _handler.setVolume(v);
  }

  Future<void> setSpeed(double s) async {
    state = state.copyWith(speed: s);
    await _handler.setSpeed(s);
  }
}
