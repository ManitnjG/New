import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/track.dart';
import '../services/platform_bridge.dart';

class LibraryScanState {
  final List<Track> tracks;
  final bool isScanning;
  final int scannedFiles;
  final int totalFiles;
  final int skippedCount;
  final String? folderUri;
  final String? error;

  const LibraryScanState({
    this.tracks = const [],
    this.isScanning = false,
    this.scannedFiles = 0,
    this.totalFiles = 0,
    this.skippedCount = 0,
    this.folderUri,
    this.error,
  });

  double get scanProgress =>
      totalFiles == 0 ? 0 : scannedFiles / totalFiles;

  LibraryScanState copyWith({
    List<Track>? tracks,
    bool? isScanning,
    int? scannedFiles,
    int? totalFiles,
    int? skippedCount,
    String? folderUri,
    String? error,
  }) =>
      LibraryScanState(
        tracks: tracks ?? this.tracks,
        isScanning: isScanning ?? this.isScanning,
        scannedFiles: scannedFiles ?? this.scannedFiles,
        totalFiles: totalFiles ?? this.totalFiles,
        skippedCount: skippedCount ?? this.skippedCount,
        folderUri: folderUri ?? this.folderUri,
        error: error,
      );
}

final libraryProvider =
    StateNotifierProvider<LibraryNotifier, LibraryScanState>(
        (ref) => LibraryNotifier());

class LibraryNotifier extends StateNotifier<LibraryScanState> {
  LibraryNotifier() : super(const LibraryScanState()) {
    _loadSavedFolderUri();
  }

  StreamSubscription? _scanSub;
  static const _folderUriKey = 'library_folder_uri';

  Future<void> _loadSavedFolderUri() async {
    final prefs = await SharedPreferences.getInstance();
    final uri = prefs.getString(_folderUriKey);
    if (uri != null) state = state.copyWith(folderUri: uri);
  }

  /// Opens SAF folder picker (Android 10+, no MANAGE_EXTERNAL_STORAGE needed).
  Future<void> pickFolder() async {
    final uri = await PlatformBridge.pickLibraryFolder();
    if (uri == null) return;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_folderUriKey, uri);
    state = state.copyWith(folderUri: uri);
    await scan(incremental: false);
  }

  /// Run a (possibly incremental) library scan.
  Future<void> scan({bool incremental = true}) async {
    final uri = state.folderUri;
    if (uri == null) {
      await pickFolder();
      return;
    }

    state = state.copyWith(
      isScanning: true,
      scannedFiles: 0,
      totalFiles: 0,
      error: null,
    );

    // Listen to per-file scan progress
    _scanSub?.cancel();
    _scanSub = PlatformBridge.scanProgressStream.listen((event) {
      state = state.copyWith(
        scannedFiles: (event['scanned_files'] as int?) ?? state.scannedFiles,
        totalFiles: (event['total_files'] as int?) ?? state.totalFiles,
        skippedCount: (event['skipped_count'] as int?) ?? state.skippedCount,
      );
    });

    try {
      final rawTracks =
          await PlatformBridge.scanLibrary(folderUri: uri, incremental: incremental);

      final tracks = rawTracks.map((json) => Track.fromJson(json)).toList()
        ..sort((a, b) {
          final artistCmp = a.artist.compareTo(b.artist);
          if (artistCmp != 0) return artistCmp;
          return a.title.compareTo(b.title);
        });

      state = state.copyWith(
        tracks: tracks,
        isScanning: false,
        scannedFiles: tracks.length,
        totalFiles: tracks.length,
      );
    } catch (e) {
      state = state.copyWith(isScanning: false, error: e.toString());
    } finally {
      _scanSub?.cancel();
    }
  }

  @override
  void dispose() {
    _scanSub?.cancel();
    super.dispose();
  }
}
