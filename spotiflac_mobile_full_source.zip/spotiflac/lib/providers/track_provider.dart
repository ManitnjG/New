import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/track.dart';
import '../services/platform_bridge.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Search state
// ─────────────────────────────────────────────────────────────────────────────

enum SearchStatus { idle, loading, success, error }

class SearchState {
  final SearchStatus status;
  final String query;
  final List<Track> tracks;
  final String? error;
  final String? searchExtensionId;

  const SearchState({
    this.status = SearchStatus.idle,
    this.query = '',
    this.tracks = const [],
    this.error,
    this.searchExtensionId,
  });

  SearchState copyWith({
    SearchStatus? status,
    String? query,
    List<Track>? tracks,
    String? error,
    String? searchExtensionId,
  }) =>
      SearchState(
        status: status ?? this.status,
        query: query ?? this.query,
        tracks: tracks ?? this.tracks,
        error: error,
        searchExtensionId: searchExtensionId ?? this.searchExtensionId,
      );
}

// ─────────────────────────────────────────────────────────────────────────────
// Provider
// ─────────────────────────────────────────────────────────────────────────────

final trackProvider =
    StateNotifierProvider<TrackNotifier, SearchState>((ref) => TrackNotifier());

class TrackNotifier extends StateNotifier<SearchState> {
  TrackNotifier() : super(const SearchState());

  String? _lastQuery;

  Future<void> search(String query, {String? extensionId}) async {
    if (query.trim().isEmpty) {
      state = const SearchState();
      return;
    }

    // Debounce: cancel if query changed while we awaited
    _lastQuery = query;
    state = state.copyWith(
      status: SearchStatus.loading,
      query: query,
      searchExtensionId: extensionId,
    );

    try {
      final result = await PlatformBridge.searchSpotify(query);

      // Ignore stale responses
      if (query != _lastQuery) return;

      final tracks = _parseSearchResult(result);
      state = state.copyWith(
        status: SearchStatus.success,
        tracks: tracks,
      );
    } catch (e) {
      if (query != _lastQuery) return;
      state = state.copyWith(
        status: SearchStatus.error,
        error: e.toString(),
      );
    }
  }

  List<Track> _parseSearchResult(Map<String, dynamic> result) {
    final type = result['type'] as String?;
    final items = result['tracks'] as List? ??
        result['items'] as List? ??
        [];

    return items.map((item) => _parseSearchTrack(item as Map<String, dynamic>)).toList();
  }

  Track _parseSearchTrack(Map<String, dynamic> json) => Track(
        id: json['id'] as String? ?? '',
        title: json['title'] as String? ?? json['name'] as String? ?? '',
        artist: _joinArtists(json['artists'] as List? ?? []) ,
        album: (json['album'] as Map<String, dynamic>?)?['name'] as String? ??
            json['album'] as String? ?? '',
        albumArtUrl: _extractArtUrl(json),
        duration: Duration(
            milliseconds: (json['duration_ms'] as int?) ?? 0),
        spotifyId: json['spotify_id'] as String? ?? json['id'] as String?,
        isrc: (json['external_ids'] as Map?)?['isrc'] as String?,
        trackNumber: json['track_number'] as int?,
        year: _extractYear(json),
      );

  String _joinArtists(List artists) => artists
      .map((a) => a is Map ? a['name'] as String? ?? '' : a.toString())
      .join(', ');

  String? _extractArtUrl(Map<String, dynamic> json) {
    final album = json['album'] as Map<String, dynamic>?;
    final images = album?['images'] as List? ?? json['images'] as List? ?? [];
    if (images.isEmpty) return null;
    return (images.first as Map)['url'] as String?;
  }

  int? _extractYear(Map<String, dynamic> json) {
    final album = json['album'] as Map<String, dynamic>?;
    final releaseDate = album?['release_date'] as String? ?? '';
    if (releaseDate.length >= 4) return int.tryParse(releaseDate.substring(0, 4));
    return null;
  }

  void clear() => state = const SearchState();
}
