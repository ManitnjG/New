import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import '../models/track.dart';
import '../services/platform_bridge.dart';

// Max concurrent downloads (matching real app behaviour)
const _maxConcurrent = 3;

final downloadProvider =
    StateNotifierProvider<DownloadNotifier, Map<String, DownloadState>>(
        (ref) => DownloadNotifier());

class DownloadNotifier extends StateNotifier<Map<String, DownloadState>> {
  DownloadNotifier() : super({}) {
    _listenProgress();
  }

  final _queue = <String>[];
  int _activeCount = 0;
  StreamSubscription? _progressSub;

  void _listenProgress() {
    _progressSub = PlatformBridge.downloadProgressStream.listen((event) {
      final trackId = event['trackId'] as String?;
      if (trackId == null) return;
      final statusStr = event['status'] as String?;
      final progress = (event['progress'] as num?)?.toDouble() ?? 0;
      final outputPath = event['outputPath'] as String?;
      final error = event['error'] as String?;

      final status = switch (statusStr) {
        'downloading' => DownloadStatus.downloading,
        'completed' => DownloadStatus.completed,
        'failed' => DownloadStatus.failed,
        _ => DownloadStatus.downloading,
      };

      final current = state[trackId];
      if (current == null) return;

      state = {
        ...state,
        trackId: current.copyWith(
          status: status,
          progress: progress,
          outputPath: outputPath,
          error: error,
        ),
      };

      if (status == DownloadStatus.completed ||
          status == DownloadStatus.failed) {
        _activeCount--;
        _processQueue();
      }
    });
  }

  Future<void> enqueue(Track track) async {
    if (state[track.id]?.status == DownloadStatus.downloading ||
        state[track.id]?.status == DownloadStatus.queued ||
        state[track.id]?.status == DownloadStatus.completed) {
      return;
    }

    state = {
      ...state,
      track.id: DownloadState(
        trackId: track.id,
        status: DownloadStatus.queued,
      ),
    };

    _queue.add(track.id);
    _processQueue();
  }

  void _processQueue() {
    while (_activeCount < _maxConcurrent && _queue.isNotEmpty) {
      final id = _queue.removeAt(0);
      _startDownload(id);
      _activeCount++;
    }
  }

  Future<void> _startDownload(String trackId) async {
    final current = state[trackId];
    if (current == null) return;

    state = {
      ...state,
      trackId: current.copyWith(status: DownloadStatus.downloading),
    };

    try {
      final dir = await getExternalStorageDirectory();
      final outputDir = p.join(dir?.path ?? '/storage/emulated/0', 'SpotiFLAC');

      // The actual download is driven by the Go backend via PlatformBridge;
      // progress is emitted through the progress event channel.
      // We just kick it off here.
      await PlatformBridge.downloadTrack(
        trackId: trackId,
        isrc: '', // populated by Go from cached search result
        title: '',
        artist: '',
        album: '',
        outputDir: outputDir,
      );
    } catch (e) {
      state = {
        ...state,
        trackId: (state[trackId] ?? DownloadState(trackId: trackId))
            .copyWith(status: DownloadStatus.failed, error: e.toString()),
      };
      _activeCount--;
      _processQueue();
    }
  }

  void cancel(String trackId) {
    _queue.remove(trackId);
    state = {
      ...state,
      trackId: DownloadState(trackId: trackId),
    };
  }

  @override
  void dispose() {
    _progressSub?.cancel();
    super.dispose();
  }
}
