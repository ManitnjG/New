import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'dart:io';
import '../providers/library_provider.dart';
import '../providers/player_provider.dart';
import '../models/track.dart';

class LibraryTab extends ConsumerWidget {
  const LibraryTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final library = ref.watch(libraryProvider);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // ── Header ─────────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 12, 12),
              child: Row(
                children: [
                  Text('Library',
                      style: Theme.of(context)
                          .textTheme
                          .headlineMedium
                          ?.copyWith(fontWeight: FontWeight.w900)),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.folder_open_rounded),
                    tooltip: 'Pick folder',
                    onPressed: () => ref.read(libraryProvider.notifier).pickFolder(),
                  ),
                  IconButton(
                    icon: const Icon(Icons.refresh_rounded),
                    tooltip: 'Rescan',
                    onPressed: () =>
                        ref.read(libraryProvider.notifier).scan(incremental: true),
                  ),
                ],
              ),
            ),

            // ── Scan progress ───────────────────────────────────────────────
            if (library.isScanning)
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    LinearProgressIndicator(
                      value: library.scanProgress > 0 ? library.scanProgress : null,
                      backgroundColor: cs.surfaceContainerHighest,
                      color: cs.primary,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Scanning… ${library.scannedFiles} / ${library.totalFiles} files'
                          '${library.skippedCount > 0 ? ' (${library.skippedCount} skipped)' : ''}',
                      style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
                    ),
                  ],
                ),
              ),

            // ── Error ───────────────────────────────────────────────────────
            if (library.error != null && !library.isScanning)
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                child: Text(library.error!,
                    style: TextStyle(color: cs.error, fontSize: 13)),
              ),

            // ── Stats chips ─────────────────────────────────────────────────
            if (library.tracks.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Row(
                  children: [
                    _Chip(
                        label:
                            '${library.tracks.where((t) => t.isFlac).length} FLAC'),
                    const SizedBox(width: 8),
                    _Chip(label: '${library.tracks.length} total'),
                  ],
                ),
              ),

            // ── Track list ──────────────────────────────────────────────────
            Expanded(
              child: library.folderUri == null && !library.isScanning
                  ? _EmptyLibrary(
                      onPick: () =>
                          ref.read(libraryProvider.notifier).pickFolder(),
                    )
                  : library.tracks.isEmpty && !library.isScanning
                      ? Center(
                          child: Text('No audio files found',
                              style: TextStyle(color: cs.onSurfaceVariant)),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.only(bottom: 160),
                          itemCount: library.tracks.length,
                          itemBuilder: (ctx, i) => _LocalTrackTile(
                            track: library.tracks[i],
                            queue: library.tracks,
                          ),
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _LocalTrackTile extends ConsumerWidget {
  final Track track;
  final List<Track> queue;
  const _LocalTrackTile({required this.track, required this.queue});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final isCurrent = ref.watch(
        playerProvider.select((s) => s.currentTrack?.id == track.id));
    final isPlaying = ref.watch(
        playerProvider.select((s) => s.isPlaying && s.currentTrack?.id == track.id));

    return InkWell(
      onTap: () => ref.read(playerProvider.notifier).playTrack(track, queue: queue),
      onLongPress: () => _showTrackInfo(context),
      child: Container(
        color: isCurrent ? cs.primaryContainer.withOpacity(0.15) : null,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: [
            // Artwork
            SizedBox(
              width: 52, height: 52,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: track.albumArtUrl != null
                        ? (track.albumArtUrl!.startsWith('/')
                            ? Image.file(File(track.albumArtUrl!), fit: BoxFit.cover)
                            : CachedNetworkImage(imageUrl: track.albumArtUrl!, fit: BoxFit.cover))
                        : Container(
                            color: cs.surfaceContainerHighest,
                            child: Icon(Icons.music_note_rounded, color: cs.onSurfaceVariant)),
                  ),
                  if (isCurrent)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Container(
                        color: Colors.black45,
                        child: Icon(
                          isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                          color: cs.primary, size: 26,
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 12),

            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(track.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w600,
                        color: isCurrent ? cs.primary : null,
                      )),
                  const SizedBox(height: 2),
                  Text(track.artist,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                  const SizedBox(height: 4),
                  if (track.isFlac)
                    Row(
                      children: [
                        _QualityTag(label: 'FLAC', color: cs.primary, bg: cs.primaryContainer),
                        if (track.sampleRate != null) ...[
                          const SizedBox(width: 6),
                          Text(track.qualityLabel,
                              style: TextStyle(fontSize: 10, color: cs.primary, fontWeight: FontWeight.w600)),
                        ],
                        if (track.qualityTier == 'Hi-Res') ...[
                          const SizedBox(width: 6),
                          _QualityTag(label: 'HI-RES', color: Colors.orange.shade700, bg: Colors.orange.shade100),
                        ],
                      ],
                    ),
                ],
              ),
            ),

            // Duration
            Text(track.durationLabel,
                style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }

  void _showTrackInfo(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) => _TrackInfoSheet(track: track),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _TrackInfoSheet extends StatelessWidget {
  final Track track;
  const _TrackInfoSheet({required this.track});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Track Info',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 16),
          _Row('Title', track.title),
          _Row('Artist', track.artist),
          _Row('Album', track.album),
          if (track.year != null) _Row('Year', '${track.year}'),
          _Row('Format', track.isFlac ? 'FLAC' : 'Audio'),
          if (track.sampleRate != null)
            _Row('Sample Rate', '${track.sampleRate} Hz'),
          if (track.bitDepth != null)
            _Row('Bit Depth', '${track.bitDepth}-bit'),
          if (track.bitrate != null)
            _Row('Bitrate', '${track.bitrate} kbps'),
          if (track.fileSizeLabel.isNotEmpty)
            _Row('File Size', track.fileSizeLabel),
          if (track.localPath != null)
            _Row('Path', track.localPath!),
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  final String label;
  final String value;
  const _Row(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 96,
            child: Text(label,
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13)),
          ),
          Expanded(
            child: Text(value,
                style:
                    const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _QualityTag extends StatelessWidget {
  final String label;
  final Color color;
  final Color bg;
  const _QualityTag({required this.label, required this.color, required this.bg});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
        decoration: BoxDecoration(
          color: bg, borderRadius: BorderRadius.circular(4)),
        child: Text(label,
            style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 0.6)),
      );
}

class _Chip extends StatelessWidget {
  final String label;
  const _Chip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(label, style: const TextStyle(fontSize: 12)),
      padding: EdgeInsets.zero,
      visualDensity: VisualDensity.compact,
    );
  }
}

class _EmptyLibrary extends StatelessWidget {
  final VoidCallback onPick;
  const _EmptyLibrary({required this.onPick});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.folder_open_rounded, size: 72, color: cs.outlineVariant),
          const SizedBox(height: 20),
          Text('No library folder selected',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Text('Pick a folder to scan for FLAC and audio files',
              style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13),
              textAlign: TextAlign.center),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: onPick,
            icon: const Icon(Icons.folder_open_rounded),
            label: const Text('Pick Folder'),
          ),
        ],
      ),
    );
  }
}
