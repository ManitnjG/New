import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../providers/player_provider.dart';
import '../models/track.dart';

class FullPlayerScreen extends ConsumerStatefulWidget {
  const FullPlayerScreen({super.key});

  @override
  ConsumerState<FullPlayerScreen> createState() => _FullPlayerScreenState();
}

class _FullPlayerScreenState extends ConsumerState<FullPlayerScreen>
    with TickerProviderStateMixin {
  bool _showQueue = false;
  late AnimationController _artController;

  @override
  void initState() {
    super.initState();
    _artController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 30),
    )..repeat();
  }

  @override
  void dispose() {
    _artController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final state = ref.watch(playerProvider);
    final track = state.currentTrack;
    if (track == null) return const SizedBox.shrink();

    if (state.isPlaying) {
      _artController.forward();
    } else {
      _artController.stop();
    }

    return Scaffold(
      backgroundColor: cs.surface,
      body: SafeArea(
        child: Column(
          children: [
            _Header(showQueue: _showQueue, onQueueToggle: () => setState(() => _showQueue = !_showQueue)),
            Expanded(
              child: _showQueue
                  ? _QueueView(state: state)
                  : _PlayerContent(
                      track: track,
                      state: state,
                      artController: _artController,
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _Header extends StatelessWidget {
  final bool showQueue;
  final VoidCallback onQueueToggle;
  const _Header({required this.showQueue, required this.onQueueToggle});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32),
            onPressed: () => Navigator.of(context).pop(),
          ),
          const Expanded(
            child: Column(
              children: [
                Text('NOW PLAYING',
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1.5)),
              ],
            ),
          ),
          IconButton(
            icon: Icon(showQueue ? Icons.queue_music_rounded : Icons.queue_music_outlined),
            onPressed: onQueueToggle,
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _PlayerContent extends ConsumerWidget {
  final Track track;
  final PlayerState state;
  final AnimationController artController;

  const _PlayerContent({
    required this.track,
    required this.state,
    required this.artController,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final notifier = ref.read(playerProvider.notifier);

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(
        children: [
          const SizedBox(height: 16),

          // ── Artwork ─────────────────────────────────────────────────────
          Hero(
            tag: 'artwork_${track.id}',
            child: AnimatedScale(
              scale: state.isPlaying ? 1.0 : 0.92,
              duration: const Duration(milliseconds: 400),
              child: Container(
                width: 280, height: 280,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: cs.primary.withOpacity(0.3),
                      blurRadius: 40,
                      offset: const Offset(0, 16),
                    ),
                  ],
                ),
                child: RotationTransition(
                  turns: artController,
                  child: ClipOval(
                    child: track.albumArtUrl != null
                        ? CachedNetworkImage(
                            imageUrl: track.albumArtUrl!,
                            width: 280, height: 280,
                            fit: BoxFit.cover,
                            errorWidget: (_, __, ___) => _artPlaceholder(cs),
                          )
                        : _artPlaceholder(cs),
                  ),
                ),
              ),
            ),
          ),

          const SizedBox(height: 32),

          // ── Title + quality ─────────────────────────────────────────────
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      track.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w800,
                            fontSize: 22,
                          ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      track.artist,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: cs.onSurfaceVariant,
                          ),
                    ),
                  ],
                ),
              ),
              if (track.isFlac)
                _QualityBadge(track: track),
            ],
          ),

          const SizedBox(height: 24),

          // ── Seek bar ────────────────────────────────────────────────────
          _SeekBar(state: state, notifier: notifier),

          const SizedBox(height: 12),

          // ── Controls ────────────────────────────────────────────────────
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(
                icon: Icon(Icons.shuffle_rounded,
                    color: state.shuffle ? cs.primary : cs.onSurfaceVariant),
                onPressed: notifier.toggleShuffle,
                iconSize: 26,
              ),
              IconButton(
                icon: const Icon(Icons.skip_previous_rounded),
                onPressed: notifier.previous,
                iconSize: 38,
              ),
              _BigPlayButton(isPlaying: state.isPlaying, onTap: notifier.togglePlay),
              IconButton(
                icon: const Icon(Icons.skip_next_rounded),
                onPressed: notifier.next,
                iconSize: 38,
              ),
              IconButton(
                icon: Icon(
                  state.repeatMode == RepeatMode.one
                      ? Icons.repeat_one_rounded
                      : Icons.repeat_rounded,
                  color: state.repeatMode != RepeatMode.none
                      ? cs.primary
                      : cs.onSurfaceVariant,
                ),
                onPressed: notifier.cycleRepeat,
                iconSize: 26,
              ),
            ],
          ),

          const SizedBox(height: 16),

          // ── Volume ──────────────────────────────────────────────────────
          Row(
            children: [
              Icon(Icons.volume_down_rounded, color: cs.onSurfaceVariant, size: 20),
              Expanded(
                child: Slider(
                  value: state.volume,
                  onChanged: notifier.setVolume,
                ),
              ),
              Icon(Icons.volume_up_rounded, color: cs.onSurfaceVariant, size: 20),
            ],
          ),

          const SizedBox(height: 16),

          // ── FLAC info card ───────────────────────────────────────────────
          if (track.isFlac) _FlacInfoCard(track: track),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _artPlaceholder(ColorScheme cs) => Container(
        color: cs.surfaceContainerHighest,
        child: Icon(Icons.music_note_rounded, color: cs.onSurfaceVariant, size: 80),
      );
}

// ─────────────────────────────────────────────────────────────────────────────

class _SeekBar extends StatefulWidget {
  final PlayerState state;
  final PlayerNotifier notifier;
  const _SeekBar({required this.state, required this.notifier});

  @override
  State<_SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<_SeekBar> {
  bool _dragging = false;
  double _dragValue = 0;

  String _fmt(Duration d) {
    final m = d.inMinutes;
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final progress = _dragging ? _dragValue : widget.state.progress;
    final pos = _dragging
        ? Duration(
            milliseconds: (_dragValue * widget.state.duration.inMilliseconds).round())
        : widget.state.position;

    return Column(
      children: [
        Slider(
          value: progress.clamp(0.0, 1.0),
          onChangeStart: (v) => setState(() { _dragging = true; _dragValue = v; }),
          onChanged: (v) => setState(() => _dragValue = v),
          onChangeEnd: (v) {
            setState(() => _dragging = false);
            widget.notifier.seekToProgress(v);
          },
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(_fmt(pos),
                  style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
              Text(_fmt(widget.state.duration),
                  style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
            ],
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _BigPlayButton extends StatelessWidget {
  final bool isPlaying;
  final VoidCallback onTap;
  const _BigPlayButton({required this.isPlaying, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 68, height: 68,
        decoration: BoxDecoration(
          color: cs.primary,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: cs.primary.withOpacity(0.35),
              blurRadius: 20,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Icon(
          isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
          color: cs.onPrimary,
          size: 38,
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _FlacInfoCard extends StatelessWidget {
  final Track track;
  const _FlacInfoCard({required this.track});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cs.primaryContainer.withOpacity(0.3),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: cs.primaryContainer),
      ),
      child: Row(
        children: [
          Icon(Icons.high_quality_rounded, color: cs.primary, size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Audio Quality',
                  style: TextStyle(
                    color: cs.primary, fontSize: 11,
                    fontWeight: FontWeight.w700, letterSpacing: 1,
                  ),
                ),
                Text(
                  track.qualityLabel.isNotEmpty
                      ? track.qualityLabel
                      : 'Lossless FLAC',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                ),
                Text(
                  '${track.qualityTier} · ${track.fileSizeLabel}',
                  style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _QualityBadge extends StatelessWidget {
  final Track track;
  const _QualityBadge({required this.track});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: cs.primary,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Text('FLAC',
              style: TextStyle(
                  color: cs.onPrimary,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.8)),
        ),
        if (track.qualityLabel.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text(
              track.qualityLabel,
              style: TextStyle(fontSize: 10, color: cs.primary, fontWeight: FontWeight.w600),
            ),
          ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _QueueView extends ConsumerWidget {
  final PlayerState state;
  const _QueueView({required this.state});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 8, 20, 12),
          child: Text('Queue',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            itemCount: state.queue.length,
            itemBuilder: (ctx, i) {
              final t = state.queue[i];
              final current = i == state.currentIndex;
              final cs = Theme.of(ctx).colorScheme;
              return ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: t.albumArtUrl != null
                      ? CachedNetworkImage(
                          imageUrl: t.albumArtUrl!,
                          width: 46, height: 46, fit: BoxFit.cover,
                        )
                      : Container(
                          width: 46, height: 46,
                          color: cs.surfaceContainerHighest,
                          child: Icon(Icons.music_note_rounded, color: cs.onSurfaceVariant),
                        ),
                ),
                title: Text(t.title,
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: current ? cs.primary : null,
                        fontWeight: FontWeight.w600, fontSize: 14)),
                subtitle: Text(t.artist,
                    style: const TextStyle(fontSize: 12)),
                trailing: current
                    ? Icon(Icons.equalizer_rounded, color: cs.primary)
                    : null,
                onTap: () => ref
                    .read(playerProvider.notifier)
                    .playTrack(t, queue: state.queue),
              );
            },
          ),
        ),
      ],
    );
  }
}
