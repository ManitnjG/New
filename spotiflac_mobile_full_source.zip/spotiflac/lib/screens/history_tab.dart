import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/track.dart';
import '../providers/player_provider.dart';

// Simple history provider
final historyProvider =
    StateNotifierProvider<HistoryNotifier, List<Track>>((ref) => HistoryNotifier());

class HistoryNotifier extends StateNotifier<List<Track>> {
  HistoryNotifier() : super([]) {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final json = prefs.getString('download_history') ?? '[]';
    final list = (jsonDecode(json) as List)
        .map((e) => Track.fromJson(e as Map<String, dynamic>))
        .toList();
    state = list;
  }

  Future<void> add(Track track) async {
    final updated = [track, ...state.where((t) => t.id != track.id).take(199)];
    state = updated;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        'download_history', jsonEncode(updated.map((t) => t.toJson()).toList()));
  }

  Future<void> clear() async {
    state = [];
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('download_history');
  }

  Future<void> remove(String trackId) async {
    final updated = state.where((t) => t.id != trackId).toList();
    state = updated;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        'download_history', jsonEncode(updated.map((t) => t.toJson()).toList()));
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class HistoryTab extends ConsumerStatefulWidget {
  const HistoryTab({super.key});

  @override
  ConsumerState<HistoryTab> createState() => _HistoryTabState();
}

class _HistoryTabState extends ConsumerState<HistoryTab>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final history = ref.watch(historyProvider);

    List<Track> forTab(int i) {
      if (i == 0) return history;
      if (i == 1) return history.where((t) => t.album.isNotEmpty).toList();
      return history.where((t) => t.trackNumber == 1).toList();
    }

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 12, 8),
              child: Row(
                children: [
                  Text('History',
                      style: Theme.of(context)
                          .textTheme
                          .headlineMedium
                          ?.copyWith(fontWeight: FontWeight.w900)),
                  const Spacer(),
                  if (history.isNotEmpty)
                    IconButton(
                      icon: const Icon(Icons.delete_sweep_outlined),
                      onPressed: () => ref.read(historyProvider.notifier).clear(),
                    ),
                ],
              ),
            ),
            TabBar(
              controller: _tabController,
              tabs: const [
                Tab(text: 'All'),
                Tab(text: 'Albums'),
                Tab(text: 'Singles'),
              ],
              labelColor: cs.primary,
              indicatorColor: cs.primary,
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: List.generate(3, (i) {
                  final tracks = forTab(i);
                  if (tracks.isEmpty) {
                    return Center(
                      child: Text('Nothing here yet',
                          style: TextStyle(color: cs.onSurfaceVariant)),
                    );
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.only(bottom: 160),
                    itemCount: tracks.length,
                    itemBuilder: (ctx, j) => _HistoryTile(
                      track: tracks[j],
                      onRemove: () => ref
                          .read(historyProvider.notifier)
                          .remove(tracks[j].id),
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HistoryTile extends ConsumerWidget {
  final Track track;
  final VoidCallback onRemove;
  const _HistoryTile({required this.track, required this.onRemove});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    return Dismissible(
      key: ValueKey(track.id),
      direction: DismissDirection.endToStart,
      background: Container(
        color: cs.errorContainer,
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        child: Icon(Icons.delete_outline_rounded, color: cs.onErrorContainer),
      ),
      onDismissed: (_) => onRemove(),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 48, height: 48,
            color: cs.surfaceContainerHighest,
            child: Icon(Icons.music_note_rounded, color: cs.onSurfaceVariant),
          ),
        ),
        title: Text(track.title,
            maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        subtitle: Text('${track.artist} · ${track.album}',
            maxLines: 1, overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
        trailing: track.isFlac
            ? Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: cs.primaryContainer,
                  borderRadius: BorderRadius.circular(4)),
                child: Text('FLAC',
                    style: TextStyle(
                        color: cs.onPrimaryContainer,
                        fontSize: 9,
                        fontWeight: FontWeight.w900)),
              )
            : null,
        onTap: () {
          if (track.isDownloaded) {
            ref.read(playerProvider.notifier).playTrack(track);
          }
        },
      ),
    );
  }
}
