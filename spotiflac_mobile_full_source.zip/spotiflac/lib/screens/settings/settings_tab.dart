import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../providers/theme_provider.dart';
import '../../providers/library_provider.dart';

class SettingsTab extends ConsumerStatefulWidget {
  const SettingsTab({super.key});

  @override
  ConsumerState<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends ConsumerState<SettingsTab> {
  String _version = '';
  String _buildNumber = '';

  @override
  void initState() {
    super.initState();
    PackageInfo.fromPlatform().then((info) {
      if (mounted) {
        setState(() {
          _version = info.version;
          _buildNumber = info.buildNumber;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final themeMode = ref.watch(themeModeProvider);
    final library = ref.watch(libraryProvider);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.only(bottom: 160),
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
              child: Text('Settings',
                  style: Theme.of(context)
                      .textTheme
                      .headlineMedium
                      ?.copyWith(fontWeight: FontWeight.w900)),
            ),

            // ── Appearance ─────────────────────────────────────────────────
            _SectionTitle('Appearance'),
            _SettingCard(
              children: [
                ListTile(
                  leading: const Icon(Icons.brightness_6_outlined),
                  title: const Text('Theme'),
                  subtitle: Text(themeMode.name[0].toUpperCase() +
                      themeMode.name.substring(1)),
                  trailing: DropdownButton<ThemeMode>(
                    value: themeMode,
                    underline: const SizedBox(),
                    onChanged: (m) {
                      if (m != null)
                        ref.read(themeModeProvider.notifier).setMode(m);
                    },
                    items: ThemeMode.values
                        .map((m) => DropdownMenuItem(
                              value: m,
                              child: Text(
                                  m.name[0].toUpperCase() + m.name.substring(1)),
                            ))
                        .toList(),
                  ),
                ),
              ],
            ),

            // ── Library ────────────────────────────────────────────────────
            _SectionTitle('Library'),
            _SettingCard(
              children: [
                ListTile(
                  leading: const Icon(Icons.folder_outlined),
                  title: const Text('Music Folder'),
                  subtitle: Text(
                    library.folderUri ?? 'Not set',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => ref.read(libraryProvider.notifier).pickFolder(),
                ),
                _StatTile('FLAC tracks',
                    '${library.tracks.where((t) => t.isFlac).length}'),
                _StatTile('Total tracks', '${library.tracks.length}'),
                ListTile(
                  leading: const Icon(Icons.refresh_rounded),
                  title: const Text('Rescan Library'),
                  onTap: () =>
                      ref.read(libraryProvider.notifier).scan(incremental: false),
                ),
              ],
            ),

            // ── Download ───────────────────────────────────────────────────
            _SectionTitle('Download'),
            _SettingCard(
              children: [
                const ListTile(
                  leading: Icon(Icons.high_quality_outlined),
                  title: Text('Preferred Quality'),
                  subtitle: Text('FLAC (Lossless)'),
                ),
                const ListTile(
                  leading: Icon(Icons.download_outlined),
                  title: Text('Concurrent Downloads'),
                  subtitle: Text('Up to 3 simultaneous'),
                ),
              ],
            ),

            // ── About ──────────────────────────────────────────────────────
            _SectionTitle('About'),
            _SettingCard(
              children: [
                ListTile(
                  leading: const Icon(Icons.info_outline_rounded),
                  title: const Text('SpotiFLAC Mobile'),
                  subtitle: Text('v$_version ($_buildNumber)'),
                ),
                ListTile(
                  leading: const Icon(Icons.code_rounded),
                  title: const Text('Source Code'),
                  subtitle: const Text('github.com/zarzet/SpotiFLAC-Mobile'),
                  trailing: const Icon(Icons.open_in_new_rounded, size: 18),
                  onTap: () => launchUrl(
                    Uri.parse('https://github.com/zarzet/SpotiFLAC-Mobile'),
                    mode: LaunchMode.externalApplication,
                  ),
                ),
                const ListTile(
                  leading: Icon(Icons.gavel_outlined),
                  title: Text('License'),
                  subtitle: Text('MIT — For educational / private use only'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 6),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          color: cs.primary,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}

class _SettingCard extends StatelessWidget {
  final List<Widget> children;
  const _SettingCard({required this.children});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Card(
        elevation: 0,
        color: cs.surfaceContainerLow,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        child: Column(children: children),
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  final String label;
  final String value;
  const _StatTile(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(label),
      trailing: Text(value,
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
    );
  }
}
