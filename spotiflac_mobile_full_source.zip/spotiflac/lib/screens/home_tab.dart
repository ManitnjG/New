import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../providers/track_provider.dart';
import '../providers/player_provider.dart';
import '../providers/download_provider.dart';
import '../models/track.dart';
import '../widgets/mini_player.dart';

class HomeTab extends ConsumerStatefulWidget {
  const HomeTab({super.key});

  @override
  ConsumerState<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends ConsumerState<HomeTab> {
  final _searchController = TextEditingController();
  Timer? _debounce;

  @override
  void dispose() {
    _searchController.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  void _onQueryChanged(String query) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () {
      ref.read(trackProvider.notifier).search(query);
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final searchState = ref.watch(trackProvider);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // ── App bar ───────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
              child: Row(
                children: [
                  Text(
                    'SpotiFLAC',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                  ),
                  const Spacer(),
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: cs.primaryContainer,
                    child: Icon(Icons.person_rounded,
                        color: cs.onPrimaryContainer, size: 20),
                  ),
                ],
              ),
            ),

            // ── Search bar ────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: SearchBar(
                controller: _searchController,
                onChanged: _onQueryChanged,
                hintText: 'Spotify URL or search...',
                leading: const Icon(Icons.search_rounded),
                trailing: [
                  if (_searchController.text.isNotEmpty)
                    IconButton(
                      icon: const Icon(Icons.clear_rounded),
                      onPressed: () {
                        _searchController.clear();
                        ref.read(trackProvider.notifier).clear();
                      },
                    ),
                ],
                padding: const WidgetStatePropertyAll(
                    EdgeInsets.symmetric(horizontal: 16)),
              ),
            ),

            // ── Results ───────────────────────────────────────────────────
            Expanded(
              child: switch (searchState.status) {
                SearchStatus.idle => _IdleContent(),
                SearchStatus.loading => const Center(
                    child: CircularProgressIndicator(),
                  ),
                SearchStatus.error => Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.error_outline_rounded,
                              size: 56, color: cs.error),
                          const SizedBox(height: 12),
                          Text(searchState.error ?? 'Unknown error',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: cs.onSurfaceVariant)),
                        ],
                      ),
                    ),
                  ),
                SearchStatus.success => searchState.tracks.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.search_off_rounded,
                                size: 56, color: cs.onSurfaceVariant),
                            const SizedBox(height: 12),
                            Text('No results for "${searchState.query}"',
                                style:
                                    TextStyle(color: cs.onSurfaceVariant)),
                          ],
                        ),
                      )
                    : _TrackList(tracks: searchState.tracks),
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _IdleContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.music_note_rounded, size: 80, color: cs.outlineVariant),
          const SizedBox(height: 16),
          Text(
            'Search for a Spotify URL\nor track / artist name',
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .bodyLarge
                ?.copyWith(color: cs.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _TrackList extends ConsumerWidget {
  final List<Track> tracks;
  const _TrackList({required this.tracks});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 160),
      itemCount: tracks.length,
      itemBuilder: (ctx, i) => _TrackTile(track: tracks[i], queue: tracks),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _TrackTile extends ConsumerWidget {
  final Track track;
  final List<Track> queue;
  const _TrackTile({required this.track, required this.queue});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final playerState = ref.watch(
        playerProvider.select((s) => (id: s.currentTrack?.id, playing: s.isPlaying)));
    final downloadState = ref.watch(downloadProvider)[track.id];
    final isCurrent = playerState.id == track.id;

    return InkWell(
      onTap: () {
        if (track.isDownloaded) {
          ref.read(playerProvider.notifier).playTrack(track, queue: queue);
        } else {
          // Download then play, or just show download option
          _showOptions(context, ref, downloadState);
        }
      },
      child: Container(
        color: isCurrent ? cs.primaryContainer.withOpacity(0.15) : null,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: [
            // Artwork
            _TrackArt(url: track.albumArtUrl, isCurrent: isCurrent, isPlaying: playerState.playing),
            const SizedBox(width: 12),

            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(track.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: isCurrent ? cs.primary : null,
                      )),
                  const SizedBox(height: 2),
                  Text('${track.artist} · ${track.durationLabel}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                ],
              ),
            ),
            const SizedBox(width: 8),

            // Download button
            _DownloadButton(track: track, downloadState: downloadState),
          ],
        ),
      ),
    );
  }

  void _showOptions(BuildContext context, WidgetRef ref, DownloadState? ds) {
    showModalBottomSheet(
      context: context,
      builder: (_) => _TrackOptions(track: track, ref: ref),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _TrackArt extends StatelessWidget {
  final String? url;
  final bool isCurrent;
  final bool isPlaying;
  const _TrackArt({this.url, required this.isCurrent, required this.isPlaying});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return SizedBox(
      width: 52, height: 52,
      child: Stack(
        fit: StackFit.expand,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: url != null
                ? CachedNetworkImage(imageUrl: url!, fit: BoxFit.cover,
                    errorWidget: (_, __, ___) => Container(
                        color: cs.surfaceContainerHighest,
                        child: Icon(Icons.music_note_rounded, color: cs.onSurfaceVariant)))
                : Container(color: cs.surfaceContainerHighest,
                    child: Icon(Icons.music_note_rounded, color: cs.onSurfaceVariant)),
          ),
          if (isCurrent)
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Container(
                color: Colors.black45,
                child: Icon(isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                    color: cs.primary, size: 26),
              ),
            ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _DownloadButton extends ConsumerWidget {
  final Track track;
  final DownloadState? downloadState;
  const _DownloadButton({required this.track, this.downloadState});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final status = downloadState?.status ?? DownloadStatus.idle;

    if (track.isDownloaded || status == DownloadStatus.completed) {
      return Icon(Icons.check_circle_rounded, color: cs.primary, size: 24);
    }

    if (status == DownloadStatus.downloading) {
      return SizedBox(
        width: 28, height: 28,
        child: CircularProgressIndicator(
          value: downloadState?.progress,
          strokeWidth: 2.5,
          color: cs.primary,
        ),
      );
    }

    if (status == DownloadStatus.queued) {
      return Icon(Icons.hourglass_top_rounded, color: cs.outline, size: 24);
    }

    return IconButton(
      icon: const Icon(Icons.download_rounded),
      iconSize: 24,
      onPressed: () => ref.read(downloadProvider.notifier).enqueue(track),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _TrackOptions extends StatelessWidget {
  final Track track;
  final WidgetRef ref;
  const _TrackOptions({required this.track, required this.ref});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 36, height: 4,
            margin: const EdgeInsets.only(bottom: 20),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.outline,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.download_rounded),
            title: const Text('Download FLAC'),
            onTap: () {
              ref.read(downloadProvider.notifier).enqueue(track);
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: const Icon(Icons.queue_music_rounded),
            title: const Text('Add to Queue'),
            onTap: () {
              ref.read(playerProvider.notifier).addToQueue(track);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Added "${track.title}" to queue'),
                    behavior: SnackBarBehavior.floating),
              );
            },
          ),
        ],
      ),
    );
  }
}
