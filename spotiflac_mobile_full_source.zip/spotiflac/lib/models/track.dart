import 'package:audio_service/audio_service.dart';

class Track {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String? albumArtUrl;
  final String? localPath;       // null = not downloaded
  final Duration duration;
  final String? spotifyId;
  final String? isrc;
  final int? trackNumber;
  final int? year;
  final int? discNumber;

  // FLAC quality metadata (populated after download)
  final int? sampleRate;
  final int? bitDepth;
  final int? bitrate;
  final int? fileSize;

  const Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    this.albumArtUrl,
    this.localPath,
    this.duration = Duration.zero,
    this.spotifyId,
    this.isrc,
    this.trackNumber,
    this.year,
    this.discNumber,
    this.sampleRate,
    this.bitDepth,
    this.bitrate,
    this.fileSize,
  });

  bool get isDownloaded => localPath != null;

  bool get isFlac {
    if (localPath == null) return false;
    return localPath!.toLowerCase().endsWith('.flac');
  }

  String get qualityLabel {
    if (!isFlac) return isDownloaded ? 'MP3' : '';
    if (sampleRate != null && bitDepth != null) {
      final khz = (sampleRate! / 1000).toStringAsFixed(
        sampleRate! % 1000 == 0 ? 0 : 1,
      );
      return '${bitDepth}bit / ${khz}kHz';
    }
    return 'FLAC';
  }

  String get qualityTier {
    if (!isFlac) return '';
    if (sampleRate == null) return 'Lossless';
    if (sampleRate! >= 88200 || (bitDepth != null && bitDepth! > 16)) {
      return 'Hi-Res';
    }
    return 'Lossless';
  }

  String get fileSizeLabel {
    if (fileSize == null) return '';
    if (fileSize! > 1024 * 1024) {
      return '${(fileSize! / 1024 / 1024).toStringAsFixed(1)} MB';
    }
    return '${(fileSize! / 1024).toStringAsFixed(0)} KB';
  }

  String get durationLabel {
    final m = duration.inMinutes;
    final s = (duration.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  MediaItem toMediaItem() => MediaItem(
    id: localPath ?? id,
    title: title,
    artist: artist,
    album: album,
    duration: duration,
    artUri: albumArtUrl != null ? Uri.parse(albumArtUrl!) : null,
    extras: {
      'trackId': id,
      'localPath': localPath,
      'sampleRate': sampleRate,
      'bitDepth': bitDepth,
      'isFlac': isFlac,
    },
  );

  factory Track.fromJson(Map<String, dynamic> json) => Track(
    id: json['id'] as String,
    title: json['title'] as String,
    artist: json['artist'] as String,
    album: json['album'] as String? ?? '',
    albumArtUrl: json['album_art_url'] as String?,
    localPath: json['local_path'] as String?,
    duration: Duration(milliseconds: (json['duration_ms'] as int?) ?? 0),
    spotifyId: json['spotify_id'] as String?,
    isrc: json['isrc'] as String?,
    trackNumber: json['track_number'] as int?,
    year: json['year'] as int?,
    sampleRate: json['sample_rate'] as int?,
    bitDepth: json['bit_depth'] as int?,
    bitrate: json['bitrate'] as int?,
    fileSize: json['file_size'] as int?,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'artist': artist,
    'album': album,
    'album_art_url': albumArtUrl,
    'local_path': localPath,
    'duration_ms': duration.inMilliseconds,
    'spotify_id': spotifyId,
    'isrc': isrc,
    'track_number': trackNumber,
    'year': year,
    'sample_rate': sampleRate,
    'bit_depth': bitDepth,
    'bitrate': bitrate,
    'file_size': fileSize,
  };

  Track copyWith({
    String? id,
    String? title,
    String? artist,
    String? album,
    String? albumArtUrl,
    String? localPath,
    Duration? duration,
    String? spotifyId,
    String? isrc,
    int? trackNumber,
    int? year,
    int? sampleRate,
    int? bitDepth,
    int? bitrate,
    int? fileSize,
  }) => Track(
    id: id ?? this.id,
    title: title ?? this.title,
    artist: artist ?? this.artist,
    album: album ?? this.album,
    albumArtUrl: albumArtUrl ?? this.albumArtUrl,
    localPath: localPath ?? this.localPath,
    duration: duration ?? this.duration,
    spotifyId: spotifyId ?? this.spotifyId,
    isrc: isrc ?? this.isrc,
    trackNumber: trackNumber ?? this.trackNumber,
    year: year ?? this.year,
    sampleRate: sampleRate ?? this.sampleRate,
    bitDepth: bitDepth ?? this.bitDepth,
    bitrate: bitrate ?? this.bitrate,
    fileSize: fileSize ?? this.fileSize,
  );
}

// Download states
enum DownloadStatus { idle, queued, downloading, completed, failed }

class DownloadState {
  final String trackId;
  final DownloadStatus status;
  final double progress;   // 0.0 – 1.0
  final String? error;
  final String? outputPath;

  const DownloadState({
    required this.trackId,
    this.status = DownloadStatus.idle,
    this.progress = 0,
    this.error,
    this.outputPath,
  });

  DownloadState copyWith({
    DownloadStatus? status,
    double? progress,
    String? error,
    String? outputPath,
  }) => DownloadState(
    trackId: trackId,
    status: status ?? this.status,
    progress: progress ?? this.progress,
    error: error ?? this.error,
    outputPath: outputPath ?? this.outputPath,
  );
}
