import 'dart:convert';
import 'package:flutter/services.dart';

/// Dart ↔ Go backend bridge via Flutter MethodChannel.
/// The Go binary is compiled to a shared library (.so) loaded by the Android
/// Kotlin plugin. All heavy work (Spotify search, FLAC download, track metadata)
/// happens in Go for performance.
class PlatformBridge {
  static const _channel = MethodChannel('com.spotiflac.app/bridge');
  static const _progressChannel = EventChannel('com.spotiflac.app/progress');

  static bool _initialized = false;

  static Future<void> initialize() async {
    if (_initialized) return;
    try {
      await _channel.invokeMethod('initialize');
      _initialized = true;
    } catch (e) {
      // Go backend not available (simulator / debug without .so)
      _initialized = true;
    }
  }

  // -----------------------------------------------------------------------
  // Search
  // -----------------------------------------------------------------------

  /// Search by Spotify URL or query string.
  /// Returns a JSON string with track/album/playlist data.
  static Future<Map<String, dynamic>> searchSpotify(String query) async {
    try {
      final result = await _channel.invokeMethod<String>('searchSpotify', {
        'query': query,
      });
      return jsonDecode(result ?? '{}') as Map<String, dynamic>;
    } on PlatformException catch (e) {
      throw PlatformBridgeException(e.message ?? 'Search failed');
    }
  }

  // -----------------------------------------------------------------------
  // Download
  // -----------------------------------------------------------------------

  /// Start download for a single track.
  /// Returns the output file path on completion.
  static Future<String> downloadTrack({
    required String trackId,
    required String isrc,
    required String title,
    required String artist,
    required String album,
    required String outputDir,
    String quality = 'flac',
    String provider = 'tidal',
  }) async {
    try {
      final result = await _channel.invokeMethod<String>('downloadTrack', {
        'trackId': trackId,
        'isrc': isrc,
        'title': title,
        'artist': artist,
        'album': album,
        'outputDir': outputDir,
        'quality': quality,
        'provider': provider,
      });
      return result ?? '';
    } on PlatformException catch (e) {
      throw PlatformBridgeException(e.message ?? 'Download failed');
    }
  }

  /// Stream of download progress events.
  /// Each event: {'trackId': String, 'progress': double, 'status': String}
  static Stream<Map<String, dynamic>> get downloadProgressStream {
    return _progressChannel.receiveBroadcastStream().map((event) {
      if (event is String) return jsonDecode(event) as Map<String, dynamic>;
      if (event is Map) return Map<String, dynamic>.from(event);
      return <String, dynamic>{};
    });
  }

  // -----------------------------------------------------------------------
  // Local library scan (SAF-based on Android 10+)
  // -----------------------------------------------------------------------

  /// Trigger SAF folder picker for library root.
  static Future<String?> pickLibraryFolder() async {
    try {
      return await _channel.invokeMethod<String>('pickLibraryFolder');
    } on PlatformException {
      return null;
    }
  }

  /// Incrementally scan the chosen library folder.
  /// Returns JSON list of track objects.
  static Future<List<Map<String, dynamic>>> scanLibrary({
    required String folderUri,
    bool incremental = true,
  }) async {
    try {
      final result = await _channel.invokeMethod<String>('scanLibrary', {
        'folderUri': folderUri,
        'incremental': incremental,
      });
      final list = jsonDecode(result ?? '[]') as List;
      return list.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } on PlatformException catch (e) {
      throw PlatformBridgeException(e.message ?? 'Scan failed');
    }
  }

  /// Stream of scan progress events.
  /// {'scanned_files': int, 'total_files': int, 'skipped_count': int}
  static Stream<Map<String, dynamic>> get scanProgressStream {
    return const EventChannel('com.spotiflac.app/scan_progress')
        .receiveBroadcastStream()
        .map((e) => Map<String, dynamic>.from(e as Map));
  }

  // -----------------------------------------------------------------------
  // Track metadata
  // -----------------------------------------------------------------------

  /// Read FLAC/audio metadata from a local file path.
  static Future<Map<String, dynamic>> readMetadata(String path) async {
    try {
      final result = await _channel.invokeMethod<String>('readMetadata', {
        'path': path,
      });
      return jsonDecode(result ?? '{}') as Map<String, dynamic>;
    } on PlatformException {
      return {};
    }
  }

  /// Convert audio file format (FLAC ↔ MP3 ↔ Opus) using FFmpeg.
  static Future<String> convertAudio({
    required String inputPath,
    required String outputFormat,
    int? bitrateKbps,
  }) async {
    try {
      final result = await _channel.invokeMethod<String>('convertAudio', {
        'inputPath': inputPath,
        'outputFormat': outputFormat,
        if (bitrateKbps != null) 'bitrateKbps': bitrateKbps,
      });
      return result ?? '';
    } on PlatformException catch (e) {
      throw PlatformBridgeException(e.message ?? 'Conversion failed');
    }
  }

  // -----------------------------------------------------------------------
  // Extension system
  // -----------------------------------------------------------------------

  static Future<List<Map<String, dynamic>>> listExtensions() async {
    try {
      final result = await _channel.invokeMethod<String>('listExtensions');
      final list = jsonDecode(result ?? '[]') as List;
      return list.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } on PlatformException {
      return [];
    }
  }

  static Future<void> installExtension(String path) async {
    await _channel.invokeMethod('installExtension', {'path': path});
  }

  static Future<void> removeExtension(String extensionId) async {
    await _channel.invokeMethod('removeExtensionByID', {'id': extensionId});
  }

  static Future<void> upgradeExtension(String extensionId) async {
    await _channel.invokeMethod('upgradeExtension', {'id': extensionId});
  }

  // -----------------------------------------------------------------------
  // Misc
  // -----------------------------------------------------------------------

  static Future<String> getAppVersion() async {
    try {
      return await _channel.invokeMethod<String>('getVersion') ?? '0.0.0';
    } on PlatformException {
      return '0.0.0';
    }
  }
}

class PlatformBridgeException implements Exception {
  final String message;
  const PlatformBridgeException(this.message);
  @override
  String toString() => 'PlatformBridgeException: $message';
}
