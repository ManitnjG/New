package com.spotiflac.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Flutter ↔ Go backend bridge.
 *
 * The Go library (libspotiflac.so) is compiled for arm64-v8a / armeabi-v7a
 * and included in android/app/src/main/jniLibs/.
 *
 * All heavy work (Spotify API, FLAC download from Tidal/Qobuz/Amazon,
 * FFmpeg conversion) runs in Go via JNI exports declared in go_backend/exports.go.
 */
class SpotiFlacPlugin(
    private val context: Context,
    private val flutterEngine: FlutterEngine,
    private val activityResultLauncher: ActivityResultLauncher<Intent>?,
) : MethodChannel.MethodCallHandler {

    companion object {
        const val METHOD_CHANNEL = "com.spotiflac.app/bridge"
        const val PROGRESS_CHANNEL = "com.spotiflac.app/progress"
        const val SCAN_PROGRESS_CHANNEL = "com.spotiflac.app/scan_progress"

        init {
            System.loadLibrary("spotiflac")
        }

        // ── JNI declarations (implemented in Go via gobind / cgo) ──────────

        @JvmStatic external fun nativeInitialize(): Int
        @JvmStatic external fun nativeSearchSpotify(query: String): String
        @JvmStatic external fun nativeDownloadTrack(
            trackId: String, isrc: String, title: String,
            artist: String, album: String, outputDir: String,
            quality: String, provider: String
        ): String
        @JvmStatic external fun nativeScanLibrary(folderPath: String, incremental: Boolean): String
        @JvmStatic external fun nativeReadMetadata(path: String): String
        @JvmStatic external fun nativeConvertAudio(inputPath: String, outputFormat: String, bitrateKbps: Int): String
        @JvmStatic external fun nativeListExtensions(): String
        @JvmStatic external fun nativeInstallExtension(path: String): Int
        @JvmStatic external fun nativeRemoveExtensionByID(id: String): Int
        @JvmStatic external fun nativeUpgradeExtension(id: String): Int
        @JvmStatic external fun nativeGetVersion(): String
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var progressSink: EventChannel.EventSink? = null
    private var scanProgressSink: EventChannel.EventSink? = null
    private var pendingFolderPickResult: ((String?) -> Unit)? = null

    fun register() {
        val methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, METHOD_CHANNEL)
        methodChannel.setMethodCallHandler(this)

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, PROGRESS_CHANNEL)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(args: Any?, sink: EventChannel.EventSink?) {
                    progressSink = sink
                }
                override fun onCancel(args: Any?) {
                    progressSink = null
                }
            })

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, SCAN_PROGRESS_CHANNEL)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(args: Any?, sink: EventChannel.EventSink?) {
                    scanProgressSink = sink
                }
                override fun onCancel(args: Any?) {
                    scanProgressSink = null
                }
            })
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "initialize" -> scope.launch {
                val code = nativeInitialize()
                withContext(Dispatchers.Main) {
                    if (code == 0) result.success(null) else result.error("INIT_FAILED", "Go init failed", null)
                }
            }

            "searchSpotify" -> scope.launch {
                val query = call.argument<String>("query") ?: ""
                val json = nativeSearchSpotify(query)
                withContext(Dispatchers.Main) { result.success(json) }
            }

            "downloadTrack" -> scope.launch {
                try {
                    val outputPath = nativeDownloadTrack(
                        call.argument("trackId") ?: "",
                        call.argument("isrc") ?: "",
                        call.argument("title") ?: "",
                        call.argument("artist") ?: "",
                        call.argument("album") ?: "",
                        call.argument("outputDir") ?: getDefaultMusicDir(),
                        call.argument("quality") ?: "flac",
                        call.argument("provider") ?: "tidal",
                    )
                    withContext(Dispatchers.Main) { result.success(outputPath) }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { result.error("DOWNLOAD_FAILED", e.message, null) }
                }
            }

            "pickLibraryFolder" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    pendingFolderPickResult = { uri -> result.success(uri) }
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    }
                    activityResultLauncher?.launch(intent)
                        ?: result.error("NO_LAUNCHER", "Activity result launcher not set", null)
                } else {
                    // Fallback for Android < 10
                    val path = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_MUSIC
                    ).absolutePath
                    result.success(path)
                }
            }

            "scanLibrary" -> scope.launch {
                val folderUri = call.argument<String>("folderUri") ?: ""
                val incremental = call.argument<Boolean>("incremental") ?: true

                // For SAF URIs (content://), resolve to a real path if possible,
                // otherwise pass the URI directly to the Go backend which handles SAF
                val resolvedPath = resolveSafUri(folderUri) ?: folderUri

                val json = nativeScanLibrary(resolvedPath, incremental)
                withContext(Dispatchers.Main) { result.success(json) }
            }

            "readMetadata" -> scope.launch {
                val path = call.argument<String>("path") ?: ""
                val json = nativeReadMetadata(path)
                withContext(Dispatchers.Main) { result.success(json) }
            }

            "convertAudio" -> scope.launch {
                val inputPath = call.argument<String>("inputPath") ?: ""
                val outputFormat = call.argument<String>("outputFormat") ?: "flac"
                val bitrateKbps = call.argument<Int>("bitrateKbps") ?: 320
                val outputPath = nativeConvertAudio(inputPath, outputFormat, bitrateKbps)
                withContext(Dispatchers.Main) { result.success(outputPath) }
            }

            "listExtensions" -> scope.launch {
                val json = nativeListExtensions()
                withContext(Dispatchers.Main) { result.success(json) }
            }

            "installExtension" -> scope.launch {
                val path = call.argument<String>("path") ?: ""
                val code = nativeInstallExtension(path)
                withContext(Dispatchers.Main) {
                    if (code == 0) result.success(null)
                    else result.error("INSTALL_FAILED", "Extension install failed", null)
                }
            }

            "removeExtensionByID" -> scope.launch {
                val id = call.argument<String>("id") ?: ""
                nativeRemoveExtensionByID(id)
                withContext(Dispatchers.Main) { result.success(null) }
            }

            "upgradeExtension" -> scope.launch {
                val id = call.argument<String>("id") ?: ""
                nativeUpgradeExtension(id)
                withContext(Dispatchers.Main) { result.success(null) }
            }

            "getVersion" -> result.success(nativeGetVersion())

            else -> result.notImplemented()
        }
    }

    /** Called by the activity when a SAF folder is picked */
    fun onFolderPicked(uri: Uri?) {
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
        }
        pendingFolderPickResult?.invoke(uri?.toString())
        pendingFolderPickResult = null
    }

    private fun resolveSafUri(uriString: String): String? {
        if (!uriString.startsWith("content://")) return uriString
        return try {
            val uri = Uri.parse(uriString)
            val docFile = DocumentFile.fromTreeUri(context, uri) ?: return null
            // Return the URI string for Go backend to traverse via SAF
            uriString
        } catch (e: Exception) {
            null
        }
    }

    private fun getDefaultMusicDir(): String {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
            "SpotiFLAC"
        )
        dir.mkdirs()
        return dir.absolutePath
    }

    /** Forward a download progress event to Flutter */
    fun emitProgress(trackId: String, status: String, progress: Double, outputPath: String?, error: String?) {
        val map = JSONObject().apply {
            put("trackId", trackId)
            put("status", status)
            put("progress", progress)
            outputPath?.let { put("outputPath", it) }
            error?.let { put("error", it) }
        }
        CoroutineScope(Dispatchers.Main).launch {
            progressSink?.success(map.toString())
        }
    }

    /** Forward a scan progress event to Flutter */
    fun emitScanProgress(scannedFiles: Int, totalFiles: Int, skippedCount: Int) {
        val map = mapOf(
            "scanned_files" to scannedFiles,
            "total_files" to totalFiles,
            "skipped_count" to skippedCount,
        )
        CoroutineScope(Dispatchers.Main).launch {
            scanProgressSink?.success(map)
        }
    }

    fun dispose() {
        scope.cancel()
    }
}
