package com.spotiflac.app

import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : FlutterActivity() {
    private lateinit var plugin: SpotiFlacPlugin

    private val folderPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri: Uri? = result.data?.data
        plugin.onFolderPicked(uri)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        plugin = SpotiFlacPlugin(
            context = applicationContext,
            flutterEngine = flutterEngine,
            activityResultLauncher = folderPickerLauncher,
        )
        plugin.register()
    }

    override fun onDestroy() {
        if (::plugin.isInitialized) plugin.dispose()
        super.onDestroy()
    }
}
