# 🎵 Wavify

> **A premium Android music app** built with React Native 0.83 + Spotify Web API metadata.
> Inspired by [sunoh-music](https://github.com/afkcodes/sunoh-music).

[![React Native](https://img.shields.io/badge/React_Native-0.83-blue?logo=react)](https://reactnative.dev)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-blue?logo=typescript)](https://typescriptlang.org)
[![Android](https://img.shields.io/badge/Platform-Android-green?logo=android)](https://developer.android.com)
[![Spotify](https://img.shields.io/badge/Metadata-Spotify_API-1DB954?logo=spotify)](https://developer.spotify.com)

---

## ✨ Features

| Feature | Details |
|---------|---------|
| 🔐 **Spotify Login** | OAuth2 PKCE — no password stored |
| 🔍 **Full Search** | Tracks, Albums, Artists, Playlists |
| 📚 **Library** | Saved tracks, albums, recently played |
| 🏠 **Home** | Personalized recommendations, new releases, top tracks |
| 🎛️ **10-Band EQ** | 12 presets + custom + preamp |
| 📋 **Queue** | Drag-and-drop reorder, swipe to remove |
| 🎨 **Dynamic Theming** | UI adapts to album artwork color |
| 📴 **Background Playback** | Lock-screen media controls |
| ♻️ **Repeat / Shuffle** | Per-track and queue repeat |
| ❤️ **Like / Unlike** | Synced to Spotify library |
| 📱 **APK Splits** | Per-ABI APKs for smallest download size |
| 🔄 **Auto Token Refresh** | Silent Spotify token renewal |

---

## 🛠 Tech Stack

- **Framework:** React Native 0.83 + TypeScript
- **State:** Zustand + React Query
- **Navigation:** Tab-based (no heavy nav library)
- **Audio:** `react-native-track-player` (ExoPlayer on Android)
- **Storage:** `react-native-mmkv` (ultra-fast key-value)
- **Images:** `react-native-fast-image`
- **Animations:** `react-native-reanimated` + `react-native-gesture-handler`
- **Build:** Gradle 8.10.2 + Hermes JS engine + R8 minification

---

## ⚡ Quick Start

### Prerequisites

| Tool | Version |
|------|---------|
| Node.js | ≥ 20 |
| Yarn | 4.6.0 |
| Java JDK | 17 |
| Android Studio | Ladybug+ |
| Android SDK | API 35 |

### 1. Setup

```bash
# Clone / unzip the project
cd wavify

# Download gradle-wrapper.jar + check setup
node scripts/setup.js

# Install JS dependencies
yarn install
```

### 2. Configure Spotify

1. Go to [developer.spotify.com/dashboard](https://developer.spotify.com/dashboard)
2. Create an app → set **Redirect URI** to `wavify://spotify-callback`
3. Copy your **Client ID** into `src/services/spotify.ts`:

```ts
export const SPOTIFY_CONFIG = {
  CLIENT_ID: 'YOUR_CLIENT_ID_HERE',   // ← paste here
  ...
};
```

### 3. Run on Android

```bash
# Start Metro (in one terminal)
yarn dev

# Run on connected device / emulator (in another)
yarn android
```

### 4. Build Release APK

```bash
# Generate a keystore (first time only)
mkdir -p android/keystores
keytool -genkeypair -v -storetype PKCS12 \
  -keystore android/keystores/release.keystore \
  -alias wavify -keyalg RSA -keysize 2048 -validity 10000

# Fill in credentials
cp android/keystore.properties.example android/keystore.properties
# Edit android/keystore.properties with your passwords

# Build (produces APKs split by ABI + universal)
yarn build:apk
```

APKs will be in `android/app/build/outputs/apk/release/`.

---

## 📁 Project Structure

```
wavify/
├── android/                    ← Full Android project
│   ├── gradlew                 ← Gradle wrapper (Unix)
│   ├── gradlew.bat             ← Gradle wrapper (Windows)
│   ├── gradle/wrapper/
│   │   └── gradle-wrapper.properties
│   ├── build.gradle            ← Top-level Gradle config
│   ├── settings.gradle
│   ├── gradle.properties       ← JVM args, Hermes, new arch flags
│   ├── keystore.properties.example
│   └── app/
│       ├── build.gradle        ← APK splits, signing, ProGuard
│       ├── proguard-rules.pro
│       └── src/main/
│           ├── AndroidManifest.xml
│           ├── java/com/wavify/
│           │   ├── MainActivity.kt
│           │   └── MainApplication.kt
│           └── res/
├── src/
│   ├── services/
│   │   ├── spotify.ts          ← Full Spotify Web API (OAuth2 PKCE + all endpoints)
│   │   └── player.ts           ← react-native-track-player wrapper
│   ├── store/index.ts          ← Zustand store (player, auth, EQ, library, UI)
│   ├── theme/index.ts          ← Design tokens
│   ├── screens/
│   │   ├── LoginScreen.tsx     ← Spotify OAuth login
│   │   ├── HomeScreen.tsx      ← Recommendations, top tracks, new releases
│   │   ├── SearchScreen.tsx    ← Search tracks/albums/artists/playlists
│   │   ├── LibraryScreen.tsx   ← Saved tracks, albums, recently played
│   │   ├── ProfileScreen.tsx   ← User info, top artists, settings
│   │   └── EqualizerScreen.tsx ← 10-band EQ, presets, preamp
│   └── components/
│       └── player/
│           ├── MiniPlayer.tsx  ← Sticky bottom player
│           └── FullPlayer.tsx  ← Full-screen player (swipe to dismiss)
├── .github/workflows/
│   └── android.yml             ← CI: build debug on push, release APK on tag
├── scripts/setup.js            ← Downloads gradle-wrapper.jar
├── App.tsx                     ← Root component
└── index.js                    ← Entry point
```

---

## 🚀 CI/CD (GitHub Actions)

The included workflow (`.github/workflows/android.yml`) automatically:

- **Every push** → builds a debug APK and uploads it as an artifact
- **On `v*` tag** → builds release APKs + AAB, creates a GitHub Release

### Required Secrets (for release builds)

| Secret | Value |
|--------|-------|
| `KEYSTORE_BASE64` | `base64 android/keystores/release.keystore` |
| `KEYSTORE_PASSWORD` | Your store password |
| `KEY_ALIAS` | `wavify` |
| `KEY_PASSWORD` | Your key password |

---

## 📄 License

MIT © 2025
