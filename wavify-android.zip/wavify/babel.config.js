module.exports = {
  presets: ['module:@react-native/babel-preset'],
  plugins: [
    ['module-resolver', {
      root: ['./src'],
      extensions: ['.ios.js', '.android.js', '.js', '.ts', '.tsx', '.json'],
      alias: {
        '@components': './src/components',
        '@screens':    './src/screens',
        '@store':      './src/store',
        '@services':   './src/services',
        '@navigation': './src/navigation',
        '@hooks':      './src/hooks',
        '@theme':      './src/theme',
        '@utils':      './src/utils',
      },
    }],
    'react-native-reanimated/plugin',
  ],
};
