# Add project specific ProGuard rules here.

# React Native
-keep class com.facebook.react.** { *; }
-keep class com.facebook.hermes.** { *; }
-keep class com.facebook.jni.** { *; }

# Kotlin
-keep class kotlin.** { *; }
-keep class kotlinx.** { *; }

# Firebase
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }

# Track Player / Media3
-keep class androidx.media3.** { *; }
-keep class com.doublesymmetry.** { *; }

# MMKV
-keep class com.tencent.mmkv.** { *; }

# Fast Image
-keep class com.dylanvann.fastimage.** { *; }

# OkHttp (used by networking)
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

# Prevent stripping enums
-keepclassmembers enum * { *; }

# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Reanimated
-keep class com.swmansion.reanimated.** { *; }

# Gesture Handler
-keep class com.swmansion.gesturehandler.** { *; }

# Vector Icons
-keep class com.oblador.vectoricons.** { *; }
