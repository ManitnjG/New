import React, {useEffect, useState} from 'react';
import {
  StatusBar, StyleSheet, View,
  Text, TouchableOpacity, Platform,
} from 'react-native';
import {GestureHandlerRootView} from 'react-native-gesture-handler';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import {QueryClient, QueryClientProvider} from '@tanstack/react-query';
import {setupPlayer} from './src/services/player';
import {useAppStore, useCurrentTrack, useIsAuthenticated} from './src/store';
import {Colors} from './src/theme';

import LoginScreen    from './src/screens/LoginScreen';
import HomeScreen     from './src/screens/HomeScreen';
import SearchScreen   from './src/screens/SearchScreen';
import LibraryScreen  from './src/screens/LibraryScreen';
import ProfileScreen  from './src/screens/ProfileScreen';
import EqualizerScreen from './src/screens/EqualizerScreen';
import MiniPlayer     from './src/components/player/MiniPlayer';
import FullPlayer     from './src/components/player/FullPlayer';
import NetworkBanner  from './src/components/common/NetworkBanner';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 3,
      retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 10_000),
      staleTime:  60_000,
      gcTime:     5 * 60_000,
      refetchOnWindowFocus: false,
      refetchOnReconnect:   true,  // re-fetch when network restores
    },
  },
});

type Tab = 'home' | 'search' | 'library' | 'profile';

const TABS: {id: Tab; label: string; icon: string}[] = [
  {id: 'home',    label: 'Home',    icon: '⌂'},
  {id: 'search',  label: 'Search',  icon: '⌕'},
  {id: 'library', label: 'Library', icon: '♫'},
  {id: 'profile', label: 'You',     icon: '◉'},
];

function MainApp() {
  const isAuthenticated  = useIsAuthenticated();
  const currentTrack     = useCurrentTrack();
  const showFullPlayer   = useAppStore(s => s.showFullPlayer);
  const toggleFullPlayer = useAppStore(s => s.toggleFullPlayer);
  const activeTab        = useAppStore(s => s.activeTab);
  const setActiveTab     = useAppStore(s => s.setActiveTab);
  const [showEQ, setShowEQ] = useState(false);

  if (!isAuthenticated) return <LoginScreen />;

  const renderScreen = () => {
    switch (activeTab) {
      case 'home':    return <HomeScreen />;
      case 'search':  return <SearchScreen />;
      case 'library': return <LibraryScreen />;
      case 'profile': return <ProfileScreen onOpenEQ={() => setShowEQ(true)} />;
    }
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />

      {/* Network loss banner — slides in/out automatically */}
      <NetworkBanner />

      {/* Screen */}
      <View style={styles.screen}>{renderScreen()}</View>

      {/* Mini player (above tab bar) */}
      {currentTrack && !showFullPlayer && (
        <MiniPlayer onPress={toggleFullPlayer} />
      )}

      {/* Tab bar */}
      <View style={styles.tabBar}>
        {TABS.map(tab => {
          const active = activeTab === tab.id;
          return (
            <TouchableOpacity
              key={tab.id}
              style={styles.tabItem}
              onPress={() => setActiveTab(tab.id as Tab)}>
              <Text style={[styles.tabIcon, active && styles.tabIconActive]}>{tab.icon}</Text>
              <Text style={[styles.tabLabel, active && styles.tabLabelActive]}>{tab.label}</Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Full player */}
      {showFullPlayer && <FullPlayer />}

      {/* EQ overlay */}
      {showEQ && (
        <View style={styles.eqOverlay}>
          <View style={styles.eqHeader}>
            <TouchableOpacity onPress={() => setShowEQ(false)}>
              <Text style={styles.eqClose}>✕  Close</Text>
            </TouchableOpacity>
          </View>
          <EqualizerScreen />
        </View>
      )}
    </View>
  );
}

export default function App() {
  const [playerReady, setPlayerReady] = useState(false);

  useEffect(() => {
    setupPlayer().then(() => setPlayerReady(true));
  }, []);

  if (!playerReady) {
    return (
      <View style={styles.splash}>
        <Text style={styles.splashText}>🎵</Text>
        <Text style={styles.splashSub}>Starting up...</Text>
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{flex: 1}}>
      <SafeAreaProvider>
        <QueryClientProvider client={queryClient}>
          <MainApp />
        </QueryClientProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root:    {flex: 1, backgroundColor: Colors.bg},
  screen:  {flex: 1},
  tabBar: {
    flexDirection:  'row',
    backgroundColor: Colors.bgCard,
    borderTopWidth:  1,
    borderTopColor:  Colors.border,
    paddingBottom:   Platform.OS === 'android' ? 8 : 20,
    paddingTop:      8,
  },
  tabItem:        {flex: 1, alignItems: 'center', gap: 2},
  tabIcon:        {fontSize: 22, color: Colors.textMuted},
  tabIconActive:  {color: Colors.primary},
  tabLabel:       {fontSize: 10, color: Colors.textMuted},
  tabLabelActive: {color: Colors.primary, fontWeight: '700'},
  splash: {
    flex: 1, backgroundColor: Colors.bg,
    justifyContent: 'center', alignItems: 'center', gap: 16,
  },
  splashText: {fontSize: 72},
  splashSub:  {color: Colors.textSecondary, fontSize: 16},
  eqOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: Colors.bg, zIndex: 90,
  },
  eqHeader: {
    padding: 16,
    paddingTop: Platform.OS === 'android' ? 48 : 60,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  eqClose: {color: Colors.primary, fontSize: 16, fontWeight: '600'},
});
