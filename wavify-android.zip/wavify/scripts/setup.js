#!/usr/bin/env node
/**
 * setup.js — Downloads gradle-wrapper.jar and prepares the project for building.
 * Run: node scripts/setup.js
 */

const fs   = require('fs');
const path = require('path');
const https = require('https');

const WRAPPER_JAR_URL =
  'https://github.com/gradle/gradle/raw/v8.10.2/gradle/wrapper/gradle-wrapper.jar';
const WRAPPER_JAR_PATH = path.join(__dirname, '..', 'android', 'gradle', 'wrapper', 'gradle-wrapper.jar');

function download(url, dest) {
  return new Promise((resolve, reject) => {
    if (fs.existsSync(dest)) {
      console.log('✅ gradle-wrapper.jar already exists, skipping download.');
      return resolve();
    }
    console.log('⬇️  Downloading gradle-wrapper.jar...');
    const dir = path.dirname(dest);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, {recursive: true});
    const file = fs.createWriteStream(dest);
    const get = (u) => https.get(u, res => {
      if (res.statusCode === 302 || res.statusCode === 301) return get(res.headers.location);
      if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
      res.pipe(file);
      file.on('finish', () => { file.close(); console.log('✅ gradle-wrapper.jar downloaded.'); resolve(); });
    }).on('error', reject);
    get(url);
  });
}

async function main() {
  console.log('\n🎵 Wavify — Project Setup\n');

  // 1. Download gradle-wrapper.jar
  await download(WRAPPER_JAR_URL, WRAPPER_JAR_PATH);

  // 2. Make gradlew executable (Unix only)
  const gradlew = path.join(__dirname, '..', 'android', 'gradlew');
  if (process.platform !== 'win32' && fs.existsSync(gradlew)) {
    fs.chmodSync(gradlew, '755');
    console.log('✅ gradlew is now executable.');
  }

  // 3. Check for keystore.properties
  const kp = path.join(__dirname, '..', 'android', 'keystore.properties');
  if (!fs.existsSync(kp)) {
    console.log('ℹ️  No keystore.properties found — debug builds will use the default debug keystore.');
    console.log('   For release builds, copy android/keystore.properties.example → android/keystore.properties');
  }

  console.log('\n🚀 Ready! Run:\n');
  console.log('   yarn install        # Install JS dependencies');
  console.log('   yarn dev            # Start Metro bundler');
  console.log('   yarn android        # Run debug on connected device');
  console.log('   yarn build:apk      # Build release APKs\n');
}

main().catch(err => { console.error('❌ Setup failed:', err.message); process.exit(1); });
