import React, {useCallback, useEffect, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  StatusBar,
  Platform,
  ScrollView,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSpring,
  interpolate,
  Extrapolation,
  runOnJS,
} from 'react-native-reanimated';
import {GestureDetector, Gesture} from 'react-native-gesture-handler';
import FastImage from 'react-native-fast-image';
import Slider from '@react-native-community/slider';
import LinearGradient from 'react-native-linear-gradient';
import {Colors, Spacing, BorderRadius, Typography, Shadow} from '@theme/index';
import {useAppStore, useCurrentTrack, useIsPlaying} from '@store/index';
import {PlayerService} from '@services/player';
import SpotifyAPI from '@services/spotify';

const {width: SCREEN_W, height: SCREEN_H} = Dimensions.get('window');
const ARTWORK_SIZE = SCREEN_W - Spacing.xl * 2;

const FullPlayer: React.FC = () => {
  const currentTrack = useCurrentTrack();
  const isPlaying = useIsPlaying();
  const {progress, progressMs} = useAppStore(s => ({
    progress: s.progress,
    progressMs: s.progressMs,
  }));
  const repeatMode = useAppStore(s => s.repeatMode);
  const isShuffle = useAppStore(s => s.isShuffle);
  const volume = useAppStore(s => s.volume);
  const showFullPlayer = useAppStore(s => s.showFullPlayer);
  const toggleFullPlayer = useAppStore(s => s.toggleFullPlayer);
  const setRepeatMode = useAppStore(s => s.setRepeatMode);
  const toggleShuffle = useAppStore(s => s.toggleShuffle);
  const isLiked = useAppStore(s => s.isLiked);

  const translateY = useSharedValue(SCREEN_H);
  const artworkScale = useSharedValue(isPlaying ? 1 : 0.85);

  useEffect(() => {
    translateY.value = withSpring(showFullPlayer ? 0 : SCREEN_H, {
      damping: 25,
      stiffness: 200,
    });
  }, [showFullPlayer, translateY]);

  useEffect(() => {
    artworkScale.value = withSpring(isPlaying ? 1 : 0.85, {
      damping: 18,
      stiffness: 150,
    });
  }, [isPlaying, artworkScale]);

  const containerStyle = useAnimatedStyle(() => ({
    transform: [{translateY: translateY.value}],
  }));

  const artworkStyle = useAnimatedStyle(() => ({
    transform: [{scale: artworkScale.value}],
  }));

  // Swipe down to close
  const swipeGesture = Gesture.Pan()
    .onUpdate(e => {
      if (e.translationY > 0) {
        translateY.value = e.translationY;
      }
    })
    .onEnd(e => {
      if (e.translationY > SCREEN_H * 0.25 || e.velocityY > 800) {
        translateY.value = withSpring(SCREEN_H);
        runOnJS(toggleFullPlayer)();
      } else {
        translateY.value = withSpring(0, {damping: 25});
      }
    });

  const handleSeek = useCallback(async (value: number) => {
    const duration = (currentTrack?.duration_ms ?? 0) / 1000;
    await PlayerService.seekTo(value * duration);
  }, [currentTrack]);

  const handleRepeat = useCallback(() => {
    const modes = ['off', 'queue', 'track'] as const;
    const idx = modes.indexOf(repeatMode);
    const next = modes[(idx + 1) % modes.length];
    setRepeatMode(next);
    PlayerService.setRepeatMode(next);
  }, [repeatMode, setRepeatMode]);

  const handleLike = useCallback(() => {
    const store = useAppStore.getState();
    if (currentTrack) {
      if (isLiked) {
        store.removeLiked(currentTrack.id);
        SpotifyAPI.removeTrack(currentTrack.id).catch(() => {});
      } else {
        store.addLiked(currentTrack.id);
        SpotifyAPI.saveTrack(currentTrack.id).catch(() => {});
      }
      store.setIsLiked(!isLiked);
    }
  }, [currentTrack, isLiked]);

  if (!currentTrack) return null;

  const artwork = SpotifyAPI.getBestImage(currentTrack.album?.images ?? [], 'large');
  const artistNames = currentTrack.artists?.map(a => a.name).join(', ') ?? '';
  const durationSec = Math.floor((currentTrack.duration_ms ?? 0) / 1000);
  const progressSec = Math.floor(progressMs / 1000);

  const formatTime = (sec: number): string => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const repeatIcon = repeatMode === 'track' ? '🔂' : repeatMode === 'queue' ? '🔁' : '↩️';
  const repeatActive = repeatMode !== 'off';

  return (
    <Animated.View style={[styles.container, containerStyle]}>
      <GestureDetector gesture={swipeGesture}>
        <LinearGradient
          colors={[Colors.bgElevated, Colors.bg]}
          style={styles.gradient}>
          <StatusBar barStyle="light-content" />

          {/* Handle */}
          <View style={styles.handle} />

          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity onPress={toggleFullPlayer} style={styles.headerBtn}>
              <Text style={styles.chevron}>⌄</Text>
            </TouchableOpacity>
            <View style={styles.headerCenter}>
              <Text style={styles.headerLabel}>Now Playing</Text>
              <Text style={styles.headerAlbum} numberOfLines={1}>
                {currentTrack.album?.name}
              </Text>
            </View>
            <TouchableOpacity style={styles.headerBtn}>
              <Text style={styles.moreIcon}>•••</Text>
            </TouchableOpacity>
          </View>

          {/* Artwork */}
          <View style={styles.artworkContainer}>
            <Animated.View style={[styles.artworkWrapper, artworkStyle, Shadow.lg]}>
              <FastImage
                source={{uri: artwork, priority: FastImage.priority.high}}
                style={styles.artwork}
                resizeMode={FastImage.resizeMode.cover}
              />
            </Animated.View>
          </View>

          {/* Track Info */}
          <View style={styles.trackInfo}>
            <View style={styles.trackInfoRow}>
              <View style={styles.trackInfoText}>
                <Text style={styles.trackTitle} numberOfLines={1}>
                  {currentTrack.name}
                </Text>
                <Text style={styles.trackArtist} numberOfLines={1}>
                  {artistNames}
                </Text>
              </View>
              <TouchableOpacity onPress={handleLike} style={styles.likeBtn}>
                <Text style={[styles.likeIcon, isLiked && styles.likeIconActive]}>
                  {isLiked ? '♥' : '♡'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Progress Slider */}
          <View style={styles.progressContainer}>
            <Slider
              style={styles.slider}
              value={progress}
              onSlidingComplete={handleSeek}
              minimumValue={0}
              maximumValue={1}
              minimumTrackTintColor={Colors.white}
              maximumTrackTintColor={Colors.progressTrack}
              thumbTintColor={Colors.white}
            />
            <View style={styles.timeRow}>
              <Text style={styles.timeText}>{formatTime(progressSec)}</Text>
              <Text style={styles.timeText}>{formatTime(durationSec)}</Text>
            </View>
          </View>

          {/* Main Controls */}
          <View style={styles.controls}>
            <TouchableOpacity
              onPress={toggleShuffle}
              style={styles.controlBtn}>
              <Text style={[styles.controlIcon, isShuffle && styles.controlActive]}>
                🔀
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={PlayerService.skipToPrevious}
              style={styles.controlBtn}>
              <Text style={styles.skipIcon}>⏮</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={PlayerService.toggle}
              style={styles.playPauseBtn}>
              <Text style={styles.playPauseIcon}>{isPlaying ? '⏸' : '▶'}</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={PlayerService.skipToNext}
              style={styles.controlBtn}>
              <Text style={styles.skipIcon}>⏭</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleRepeat}
              style={styles.controlBtn}>
              <Text style={[styles.controlIcon, repeatActive && styles.controlActive]}>
                {repeatIcon}
              </Text>
            </TouchableOpacity>
          </View>

          {/* Volume */}
          <View style={styles.volumeContainer}>
            <Text style={styles.volumeIcon}>🔈</Text>
            <Slider
              style={styles.volumeSlider}
              value={volume}
              onValueChange={val => PlayerService.setVolume(val)}
              minimumValue={0}
              maximumValue={1}
              minimumTrackTintColor={Colors.textSecondary}
              maximumTrackTintColor={Colors.progressTrack}
              thumbTintColor={Colors.textSecondary}
            />
            <Text style={styles.volumeIcon}>🔊</Text>
          </View>

          {/* Extra Actions */}
          <View style={styles.extraActions}>
            <TouchableOpacity style={styles.extraBtn}>
              <Text style={styles.extraIcon}>📱</Text>
              <Text style={styles.extraLabel}>Devices</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.extraBtn}>
              <Text style={styles.extraIcon}>📋</Text>
              <Text style={styles.extraLabel}>Queue</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.extraBtn}>
              <Text style={styles.extraIcon}>↗️</Text>
              <Text style={styles.extraLabel}>Share</Text>
            </TouchableOpacity>
          </View>
        </LinearGradient>
      </GestureDetector>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 100,
  },
  gradient: {
    flex: 1,
    paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight ?? 0) + 8 : 50,
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.xxl,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: Colors.textMuted,
    alignSelf: 'center',
    marginBottom: Spacing.base,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.xxl,
  },
  headerBtn: {
    padding: Spacing.sm,
    minWidth: 44,
    minHeight: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chevron: {fontSize: 28, color: Colors.textPrimary, lineHeight: 32},
  moreIcon: {fontSize: 16, color: Colors.textPrimary, letterSpacing: 2},
  headerCenter: {alignItems: 'center', flex: 1},
  headerLabel: {
    color: Colors.textSecondary,
    fontSize: Typography.sm,
    fontWeight: '500',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  headerAlbum: {
    color: Colors.textPrimary,
    fontSize: Typography.sm,
    fontWeight: '600',
    marginTop: 2,
  },
  artworkContainer: {
    alignItems: 'center',
    marginBottom: Spacing.xxl,
  },
  artworkWrapper: {
    width: ARTWORK_SIZE,
    height: ARTWORK_SIZE,
    borderRadius: BorderRadius.md,
    overflow: 'hidden',
  },
  artwork: {
    width: '100%',
    height: '100%',
  },
  trackInfo: {
    marginBottom: Spacing.lg,
  },
  trackInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  trackInfoText: {flex: 1, marginRight: Spacing.base},
  trackTitle: {
    color: Colors.textPrimary,
    fontSize: Typography.xl,
    fontWeight: '700',
  },
  trackArtist: {
    color: Colors.textSecondary,
    fontSize: Typography.base,
    marginTop: 4,
  },
  likeBtn: {
    padding: Spacing.sm,
    minWidth: 44,
    minHeight: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  likeIcon: {fontSize: 26, color: Colors.textMuted},
  likeIconActive: {color: Colors.primary},
  progressContainer: {
    marginBottom: Spacing.lg,
  },
  slider: {width: '100%', height: 40},
  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: -8,
  },
  timeText: {color: Colors.textMuted, fontSize: Typography.xs},
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.xl,
  },
  controlBtn: {
    padding: Spacing.sm,
    minWidth: 44,
    minHeight: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  controlIcon: {fontSize: 22, color: Colors.textSecondary},
  controlActive: {color: Colors.primary},
  skipIcon: {fontSize: 26, color: Colors.textPrimary},
  playPauseBtn: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.md,
  },
  playPauseIcon: {fontSize: 30, color: Colors.black},
  volumeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Spacing.xl,
    gap: Spacing.sm,
  },
  volumeSlider: {flex: 1, height: 40},
  volumeIcon: {fontSize: 16},
  extraActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  extraBtn: {alignItems: 'center', gap: 4},
  extraIcon: {fontSize: 20},
  extraLabel: {color: Colors.textSecondary, fontSize: Typography.xs},
});

export default FullPlayer;
