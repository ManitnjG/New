import React, {useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Pressable,
  Platform,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  interpolate,
} from 'react-native-reanimated';
import FastImage from 'react-native-fast-image';
import {Colors, Spacing, BorderRadius, Typography} from '@theme/index';
import {useAppStore, useCurrentTrack, useIsPlaying} from '@store/index';
import {PlayerService} from '@services/player';
import SpotifyAPI from '@services/spotify';

interface MiniPlayerProps {
  onPress: () => void;
}

const MiniPlayer: React.FC<MiniPlayerProps> = ({onPress}) => {
  const currentTrack = useCurrentTrack();
  const isPlaying = useIsPlaying();
  const progress = useAppStore(s => s.progress);
  const scale = useSharedValue(1);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{scale: scale.value}],
  }));

  const handlePressIn = useCallback(() => {
    scale.value = withSpring(0.98, {damping: 15});
  }, [scale]);

  const handlePressOut = useCallback(() => {
    scale.value = withSpring(1, {damping: 15});
  }, [scale]);

  const handleToggle = useCallback(async (e: any) => {
    e.stopPropagation();
    await PlayerService.toggle();
  }, []);

  const handleNext = useCallback(async (e: any) => {
    e.stopPropagation();
    await PlayerService.skipToNext();
  }, []);

  if (!currentTrack) return null;

  const artwork = SpotifyAPI.getBestImage(currentTrack.album?.images ?? [], 'small');
  const artistNames = currentTrack.artists?.map(a => a.name).join(', ') ?? '';

  return (
    <Pressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={styles.container}>
      <Animated.View style={[styles.inner, animStyle]}>
        {/* Progress Bar */}
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, {width: `${progress * 100}%`}]} />
        </View>

        <View style={styles.row}>
          {/* Artwork */}
          <FastImage
            source={{uri: artwork, priority: FastImage.priority.high}}
            style={styles.artwork}
            resizeMode={FastImage.resizeMode.cover}
          />

          {/* Track Info */}
          <View style={styles.info}>
            <Text style={styles.title} numberOfLines={1}>
              {currentTrack.name}
            </Text>
            <Text style={styles.artist} numberOfLines={1}>
              {artistNames}
            </Text>
          </View>

          {/* Controls */}
          <View style={styles.controls}>
            <TouchableOpacity
              onPress={handleToggle}
              style={styles.playBtn}
              hitSlop={{top: 10, bottom: 10, left: 8, right: 8}}>
              <Text style={styles.playIcon}>{isPlaying ? '⏸' : '▶'}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleNext}
              style={styles.nextBtn}
              hitSlop={{top: 10, bottom: 10, left: 8, right: 8}}>
              <Text style={styles.nextIcon}>⏭</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Animated.View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: Spacing.base,
    right: Spacing.base,
    bottom: Platform.OS === 'android' ? 60 : 80,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    backgroundColor: Colors.bgElevated,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: -4},
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 20,
  },
  inner: {
    backgroundColor: Colors.bgSurface,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
  },
  progressBar: {
    height: 2,
    backgroundColor: Colors.progressTrack,
  },
  progressFill: {
    height: '100%',
    backgroundColor: Colors.primary,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    gap: Spacing.md,
  },
  artwork: {
    width: 44,
    height: 44,
    borderRadius: BorderRadius.sm,
  },
  info: {
    flex: 1,
  },
  title: {
    color: Colors.textPrimary,
    fontSize: Typography.base,
    fontWeight: '600',
    lineHeight: 20,
  },
  artist: {
    color: Colors.textSecondary,
    fontSize: Typography.sm,
    marginTop: 2,
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.base,
  },
  playBtn: {
    padding: Spacing.xs,
  },
  playIcon: {
    fontSize: 22,
    color: Colors.textPrimary,
  },
  nextBtn: {
    padding: Spacing.xs,
  },
  nextIcon: {
    fontSize: 20,
    color: Colors.textSecondary,
  },
});

export default MiniPlayer;
