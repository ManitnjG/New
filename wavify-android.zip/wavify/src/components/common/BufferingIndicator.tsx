import React, {useEffect, useRef} from 'react';
import {View, StyleSheet, Animated} from 'react-native';
import {Colors} from '@theme/index';
import {useAppStore} from '@store/index';

const BufferingIndicator: React.FC = () => {
  const playerState = useAppStore(s => s.playerState);
  const isBuffering = playerState === 'buffering' || playerState === 'loading';
  const spin = useRef(new Animated.Value(0)).current;
  const anim = useRef<Animated.CompositeAnimation | null>(null);

  useEffect(() => {
    if (isBuffering) {
      anim.current = Animated.loop(
        Animated.timing(spin, {toValue: 1, duration: 900, useNativeDriver: true}),
      );
      anim.current.start();
    } else {
      anim.current?.stop();
      spin.setValue(0);
    }
    return () => anim.current?.stop();
  }, [isBuffering, spin]);

  if (!isBuffering) return null;

  const rotate = spin.interpolate({inputRange: [0, 1], outputRange: ['0deg', '360deg']});

  return (
    <View style={styles.container} pointerEvents="none">
      <Animated.View style={[styles.ring, {transform: [{rotate}]}]} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position:       'absolute',
    alignSelf:      'center',
    justifyContent: 'center',
    alignItems:     'center',
    zIndex:         10,
  },
  ring: {
    width:       48,
    height:      48,
    borderRadius: 24,
    borderWidth:  4,
    borderColor:  Colors.primary,
    borderTopColor: 'transparent',
  },
});

export default BufferingIndicator;
