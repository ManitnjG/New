import React, {useEffect, useRef} from 'react';
import {View, Text, StyleSheet, Animated} from 'react-native';
import {Colors, Typography, Spacing} from '@theme/index';
import {useNetwork} from '@hooks/useNetwork';

const NetworkBanner: React.FC = () => {
  const {isConnected} = useNetwork();
  const opacity    = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(-48)).current;

  useEffect(() => {
    if (!isConnected) {
      Animated.parallel([
        Animated.timing(opacity,    {toValue: 1, duration: 250, useNativeDriver: true}),
        Animated.spring(translateY, {toValue: 0, tension: 80,   useNativeDriver: true}),
      ]).start();
    } else {
      // Show "Back online" briefly then hide
      Animated.sequence([
        Animated.delay(1000),
        Animated.parallel([
          Animated.timing(opacity,    {toValue: 0, duration: 400, useNativeDriver: true}),
          Animated.timing(translateY, {toValue: -48, duration: 400, useNativeDriver: true}),
        ]),
      ]).start();
    }
  }, [isConnected, opacity, translateY]);

  return (
    <Animated.View style={[styles.banner, {opacity, transform: [{translateY}]},
      isConnected ? styles.online : styles.offline]}>
      <Text style={styles.icon}>{isConnected ? '✅' : '📶'}</Text>
      <Text style={styles.text}>
        {isConnected ? 'Back online' : 'No internet — music paused'}
      </Text>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  banner: {
    position:       'absolute',
    top:            0,
    left:           0,
    right:          0,
    zIndex:         999,
    flexDirection:  'row',
    alignItems:     'center',
    justifyContent: 'center',
    paddingVertical: Spacing.sm,
    gap: Spacing.sm,
  },
  offline: {backgroundColor: '#b91c1c'},
  online:  {backgroundColor: '#15803d'},
  icon:    {fontSize: 14},
  text:    {color: Colors.white, fontSize: Typography.sm, fontWeight: '600'},
});

export default NetworkBanner;
