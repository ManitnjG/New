export const Colors = {
  // Primary palette
  primary: '#1DB954',        // Spotify green
  primaryDark: '#158a3e',
  primaryLight: '#1ed760',

  // Backgrounds
  bg: '#0a0a0a',
  bgCard: '#161616',
  bgElevated: '#1e1e1e',
  bgSurface: '#282828',
  bgModal: '#121212',

  // Text
  textPrimary: '#FFFFFF',
  textSecondary: '#B3B3B3',
  textMuted: '#535353',
  textDisabled: '#3e3e3e',

  // Accent
  accent: '#1DB954',
  accentBlue: '#2196f3',
  accentPurple: '#9c27b0',
  accentOrange: '#ff6b35',

  // Player
  playerBg: '#121212',
  progressTrack: '#535353',
  progressFill: '#FFFFFF',
  progressThumb: '#FFFFFF',

  // Equalizer bands
  eqBand: '#1DB954',
  eqBandInactive: '#535353',

  // Status
  success: '#1DB954',
  warning: '#FFA500',
  error: '#E91429',
  info: '#2196f3',

  // Misc
  border: '#282828',
  divider: '#1e1e1e',
  overlay: 'rgba(0,0,0,0.7)',
  overlayLight: 'rgba(0,0,0,0.4)',
  white: '#FFFFFF',
  black: '#000000',
  transparent: 'transparent',
};

export const Typography = {
  // Font families
  regular: 'System',
  medium: 'System',
  bold: 'System',

  // Sizes
  xs: 11,
  sm: 13,
  base: 15,
  md: 17,
  lg: 20,
  xl: 24,
  xxl: 28,
  xxxl: 34,
  display: 42,
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  xxxl: 40,
};

export const BorderRadius = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
};

export const Shadow = {
  sm: {
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 4},
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 8},
    shadowOpacity: 0.5,
    shadowRadius: 16,
    elevation: 12,
  },
};

export default {Colors, Typography, Spacing, BorderRadius, Shadow};
