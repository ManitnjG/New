import {create} from 'zustand';
import {subscribeWithSelector} from 'zustand/middleware';
import {SpotifyTrack, SpotifyUser} from '@services/spotify';

// ─── Player Types ──────────────────────────────────────────────────────────
export type RepeatMode = 'off' | 'track' | 'queue';
export type PlayerState = 'playing' | 'paused' | 'loading' | 'stopped' | 'buffering' | 'error';

export interface QueueItem extends SpotifyTrack {
  queueId: string; // unique per queue slot (same song can appear twice)
  addedAt: number;
}

export interface EQBand {
  frequency: number;
  label: string;
  gain: number; // -12 to +12 dB
}

export interface EQPreset {
  id: string;
  name: string;
  bands: number[];
}

// ─── Player Slice ──────────────────────────────────────────────────────────
interface PlayerSlice {
  currentTrack: QueueItem | null;
  queue: QueueItem[];
  queueIndex: number;
  playerState: PlayerState;
  progress: number;        // 0-1
  progressMs: number;      // ms
  volume: number;          // 0-1
  isMuted: boolean;
  isShuffle: boolean;
  repeatMode: RepeatMode;
  isLiked: boolean;
  showFullPlayer: boolean;

  setCurrentTrack: (track: QueueItem | null) => void;
  setQueue: (tracks: SpotifyTrack[], startIndex?: number) => void;
  addToQueue: (track: SpotifyTrack) => void;
  removeFromQueue: (queueId: string) => void;
  reorderQueue: (from: number, to: number) => void;
  clearQueue: () => void;
  nextTrack: () => void;
  prevTrack: () => void;
  setPlayerState: (state: PlayerState) => void;
  setProgress: (progress: number, ms: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  setRepeatMode: (mode: RepeatMode) => void;
  setIsLiked: (liked: boolean) => void;
  toggleFullPlayer: () => void;
  networkError: boolean;
  setNetworkError: (v: boolean) => void;
}

// ─── Auth Slice ────────────────────────────────────────────────────────────
interface AuthSlice {
  user: SpotifyUser | null;
  isAuthenticated: boolean;
  isAuthLoading: boolean;
  authError: string | null;

  setUser: (user: SpotifyUser | null) => void;
  setIsAuthenticated: (val: boolean) => void;
  setAuthLoading: (val: boolean) => void;
  setAuthError: (err: string | null) => void;
  logout: () => void;
}

// ─── EQ Slice ──────────────────────────────────────────────────────────────
export const DEFAULT_EQ_BANDS: EQBand[] = [
  {frequency: 32,    label: '32',   gain: 0},
  {frequency: 64,    label: '64',   gain: 0},
  {frequency: 125,   label: '125',  gain: 0},
  {frequency: 250,   label: '250',  gain: 0},
  {frequency: 500,   label: '500',  gain: 0},
  {frequency: 1000,  label: '1K',   gain: 0},
  {frequency: 2000,  label: '2K',   gain: 0},
  {frequency: 4000,  label: '4K',   gain: 0},
  {frequency: 8000,  label: '8K',   gain: 0},
  {frequency: 16000, label: '16K',  gain: 0},
];

export const EQ_PRESETS: EQPreset[] = [
  {id: 'flat',       name: 'Flat',        bands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]},
  {id: 'bass',       name: 'Bass Boost',  bands: [6, 5, 4, 2, 1, 0, 0, 0, 0, 0]},
  {id: 'treble',     name: 'Treble',      bands: [0, 0, 0, 0, 0, 1, 2, 4, 5, 6]},
  {id: 'vocal',      name: 'Vocal',       bands: [-2, -1, 0, 2, 4, 4, 2, 0, -1, -2]},
  {id: 'rock',       name: 'Rock',        bands: [4, 3, 2, 1, -1, -1, 1, 2, 3, 4]},
  {id: 'pop',        name: 'Pop',         bands: [-1, 0, 2, 3, 4, 3, 2, 0, -1, -1]},
  {id: 'jazz',       name: 'Jazz',        bands: [2, 1, 0, 2, -1, -1, 0, 1, 2, 3]},
  {id: 'classical',  name: 'Classical',   bands: [3, 2, 1, 0, -1, -1, 0, 1, 2, 3]},
  {id: 'electronic', name: 'Electronic',  bands: [4, 3, 1, 0, -2, 0, 1, 3, 4, 5]},
  {id: 'acoustic',   name: 'Acoustic',    bands: [2, 2, 3, 1, 0, 0, 0, 1, 2, 2]},
  {id: 'lounge',     name: 'Lounge',      bands: [-1, 0, 1, 2, 2, 1, 0, -1, 0, 1]},
  {id: 'podcast',    name: 'Podcast',     bands: [-3, -2, 0, 3, 4, 4, 3, 0, -1, -2]},
];

interface EQSlice {
  eqEnabled: boolean;
  eqBands: EQBand[];
  activePreset: string;
  preampGain: number; // -12 to +12

  setEQEnabled: (enabled: boolean) => void;
  setBandGain: (index: number, gain: number) => void;
  applyPreset: (presetId: string) => void;
  resetEQ: () => void;
  setPreampGain: (gain: number) => void;
}

// ─── UI Slice ──────────────────────────────────────────────────────────────
interface UISlice {
  activeTab: 'home' | 'search' | 'library' | 'profile';
  themeColor: string;
  isDynamicTheme: boolean;

  setActiveTab: (tab: UISlice['activeTab']) => void;
  setThemeColor: (color: string) => void;
  setDynamicTheme: (enabled: boolean) => void;
}

// ─── Library Slice ─────────────────────────────────────────────────────────
interface LibrarySlice {
  likedTrackIds: Set<string>;
  recentlyPlayed: QueueItem[];
  downloadedIds: Set<string>;

  addLiked: (id: string) => void;
  removeLiked: (id: string) => void;
  isLiked: (id: string) => boolean;
  addRecentlyPlayed: (track: QueueItem) => void;
  markDownloaded: (id: string) => void;
  removeDownloaded: (id: string) => void;
  isDownloaded: (id: string) => boolean;
}

// ─── Combined Store ─────────────────────────────────────────────────────────
type AppStore = PlayerSlice & AuthSlice & EQSlice & UISlice & LibrarySlice;

const makeQueueItem = (track: SpotifyTrack): QueueItem => ({
  ...track,
  queueId: `${track.id}_${Date.now()}_${Math.random()}`,
  addedAt: Date.now(),
});

export const useAppStore = create<AppStore>()(
  subscribeWithSelector((set, get) => ({
    // ── Player ──────────────────────────────────────────
    currentTrack: null,
    queue: [],
    queueIndex: 0,
    playerState: 'stopped',
    progress: 0,
    progressMs: 0,
    volume: 1,
    isMuted: false,
    isShuffle: false,
    repeatMode: 'off',
    isLiked: false,
    showFullPlayer: false,
    networkError: false,

    setCurrentTrack: track => set({currentTrack: track}),

    setQueue: (tracks, startIndex = 0) => {
      const queueItems = tracks.map(makeQueueItem);
      set({
        queue: queueItems,
        queueIndex: startIndex,
        currentTrack: queueItems[startIndex] ?? null,
      });
    },

    addToQueue: track => {
      const item = makeQueueItem(track);
      set(state => ({queue: [...state.queue, item]}));
    },

    removeFromQueue: queueId => {
      set(state => {
        const newQueue = state.queue.filter(t => t.queueId !== queueId);
        const newIndex = Math.min(state.queueIndex, newQueue.length - 1);
        return {queue: newQueue, queueIndex: Math.max(0, newIndex)};
      });
    },

    reorderQueue: (from, to) => {
      set(state => {
        const newQueue = [...state.queue];
        const [removed] = newQueue.splice(from, 1);
        newQueue.splice(to, 0, removed);
        let newIndex = state.queueIndex;
        if (from === state.queueIndex) newIndex = to;
        else if (from < state.queueIndex && to >= state.queueIndex) newIndex--;
        else if (from > state.queueIndex && to <= state.queueIndex) newIndex++;
        return {queue: newQueue, queueIndex: newIndex};
      });
    },

    clearQueue: () => set({queue: [], queueIndex: 0, currentTrack: null}),

    nextTrack: () => {
      const {queue, queueIndex, repeatMode, isShuffle} = get();
      if (queue.length === 0) return;
      if (repeatMode === 'track') return; // TrackPlayer handles this
      let nextIndex: number;
      if (isShuffle) {
        nextIndex = Math.floor(Math.random() * queue.length);
      } else if (queueIndex < queue.length - 1) {
        nextIndex = queueIndex + 1;
      } else if (repeatMode === 'queue') {
        nextIndex = 0;
      } else {
        return;
      }
      set({queueIndex: nextIndex, currentTrack: queue[nextIndex]});
    },

    prevTrack: () => {
      const {queue, queueIndex, progressMs} = get();
      if (queue.length === 0) return;
      // If > 3 seconds in, restart current; else go prev
      if (progressMs > 3000 || queueIndex === 0) {
        set({progress: 0, progressMs: 0});
        return;
      }
      const prevIndex = queueIndex - 1;
      set({queueIndex: prevIndex, currentTrack: queue[prevIndex]});
    },

    setPlayerState: playerState => set({playerState}),
    setProgress: (progress, progressMs) => set({progress, progressMs}),
    setVolume: volume => set({volume, isMuted: volume === 0}),
    toggleMute: () => set(state => ({isMuted: !state.isMuted})),
    toggleShuffle: () => set(state => ({isShuffle: !state.isShuffle})),
    setRepeatMode: repeatMode => set({repeatMode}),
    setIsLiked: isLiked => set({isLiked}),
    toggleFullPlayer: () => set(state => ({showFullPlayer: !state.showFullPlayer})),
    networkError: false,
    setNetworkError: (networkError: boolean) => set({networkError}),

    // ── Auth ────────────────────────────────────────────
    user: null,
    isAuthenticated: false,
    isAuthLoading: true,
    authError: null,

    setUser: user => set({user}),
    setIsAuthenticated: isAuthenticated => set({isAuthenticated}),
    setAuthLoading: isAuthLoading => set({isAuthLoading}),
    setAuthError: authError => set({authError}),
    logout: () => set({user: null, isAuthenticated: false, authError: null}),

    // ── EQ ──────────────────────────────────────────────
    eqEnabled: false,
    eqBands: DEFAULT_EQ_BANDS,
    activePreset: 'flat',
    preampGain: 0,

    setEQEnabled: eqEnabled => set({eqEnabled}),

    setBandGain: (index, gain) => {
      set(state => {
        const newBands = state.eqBands.map((band, i) =>
          i === index ? {...band, gain: Math.max(-12, Math.min(12, gain))} : band,
        );
        return {eqBands: newBands, activePreset: 'custom'};
      });
    },

    applyPreset: presetId => {
      const preset = EQ_PRESETS.find(p => p.id === presetId);
      if (!preset) return;
      set(state => ({
        eqBands: state.eqBands.map((band, i) => ({
          ...band,
          gain: preset.bands[i] ?? 0,
        })),
        activePreset: presetId,
      }));
    },

    resetEQ: () => {
      set({eqBands: DEFAULT_EQ_BANDS, activePreset: 'flat', preampGain: 0});
    },

    setPreampGain: preampGain => set({preampGain: Math.max(-12, Math.min(12, preampGain))}),

    // ── UI ──────────────────────────────────────────────
    activeTab: 'home',
    themeColor: '#1DB954',
    isDynamicTheme: true,

    setActiveTab: activeTab => set({activeTab}),
    setThemeColor: themeColor => set({themeColor}),
    setDynamicTheme: isDynamicTheme => set({isDynamicTheme}),

    // ── Library ─────────────────────────────────────────
    likedTrackIds: new Set(),
    recentlyPlayed: [],
    downloadedIds: new Set(),

    addLiked: id => {
      set(state => ({likedTrackIds: new Set([...state.likedTrackIds, id])}));
    },
    removeLiked: id => {
      set(state => {
        const next = new Set(state.likedTrackIds);
        next.delete(id);
        return {likedTrackIds: next};
      });
    },
    isLiked: id => get().likedTrackIds.has(id),

    addRecentlyPlayed: track => {
      set(state => {
        const filtered = state.recentlyPlayed.filter(t => t.id !== track.id);
        return {recentlyPlayed: [track, ...filtered].slice(0, 50)};
      });
    },

    markDownloaded: id => {
      set(state => ({downloadedIds: new Set([...state.downloadedIds, id])}));
    },
    removeDownloaded: id => {
      set(state => {
        const next = new Set(state.downloadedIds);
        next.delete(id);
        return {downloadedIds: next};
      });
    },
    isDownloaded: id => get().downloadedIds.has(id),
  })),
);

// ─── Selectors (memoized) ─────────────────────────────────────────────────
export const useCurrentTrack = () => useAppStore(s => s.currentTrack);
export const useQueue = () => useAppStore(s => s.queue);
export const usePlayerState = () => useAppStore(s => s.playerState);
export const useProgress = () => useAppStore(s => ({progress: s.progress, progressMs: s.progressMs}));
export const useIsPlaying = () => useAppStore(s => s.playerState === 'playing');
export const useEQ = () => useAppStore(s => ({bands: s.eqBands, enabled: s.eqEnabled, preset: s.activePreset}));
export const useAuthUser = () => useAppStore(s => s.user);
export const useIsAuthenticated = () => useAppStore(s => s.isAuthenticated);
