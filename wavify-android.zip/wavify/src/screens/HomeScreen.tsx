import React, {useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList,
  Dimensions,
  RefreshControl,
} from 'react-native';
import {useQuery} from '@tanstack/react-query';
import FastImage from 'react-native-fast-image';
import LinearGradient from 'react-native-linear-gradient';
import {Colors, Spacing, BorderRadius, Typography} from '@theme/index';
import {useAppStore, useAuthUser} from '@store/index';
import SpotifyAPI, {SpotifyTrack, SpotifyAlbum, SpotifyPlaylist} from '@services/spotify';
import {PlayerService} from '@services/player';

const {width: SCREEN_W} = Dimensions.get('window');
const FEATURED_W = SCREEN_W - Spacing.base * 2;
const CARD_W = 160;

const HomeScreen: React.FC = () => {
  const user = useAuthUser();
  const greeting = getGreeting();

  const {data: recentTracks, isLoading: recentLoading, refetch: refetchRecent} =
    useQuery({
      queryKey: ['recentlyPlayed'],
      queryFn: () => SpotifyAPI.getRecentlyPlayed(10),
      staleTime: 2 * 60 * 1000,
    });

  const {data: topTracks, refetch: refetchTop} =
    useQuery({
      queryKey: ['topTracks'],
      queryFn: () => SpotifyAPI.getTopTracks('short_term', 10),
      staleTime: 5 * 60 * 1000,
    });

  const {data: newReleases, refetch: refetchNew} =
    useQuery({
      queryKey: ['newReleases'],
      queryFn: () => SpotifyAPI.getNewReleases(12),
      staleTime: 10 * 60 * 1000,
    });

  const {data: featured} =
    useQuery({
      queryKey: ['featuredPlaylists'],
      queryFn: () => SpotifyAPI.getFeaturedPlaylists(6),
      staleTime: 10 * 60 * 1000,
    });

  const {data: recommendations} =
    useQuery({
      queryKey: ['recommendations', topTracks?.[0]?.id],
      queryFn: () =>
        SpotifyAPI.getRecommendations({
          seed_tracks: topTracks?.slice(0, 3).map(t => t.id),
          limit: 10,
        }),
      enabled: !!topTracks?.length,
      staleTime: 5 * 60 * 1000,
    });

  const handlePlayTrack = useCallback(
    async (tracks: SpotifyTrack[], index: number) => {
      await PlayerService.loadQueue(tracks, index, true);
    },
    [],
  );

  const [refreshing, setRefreshing] = React.useState(false);
  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([refetchRecent(), refetchTop(), refetchNew()]);
    setRefreshing(false);
  }, [refetchRecent, refetchTop, refetchNew]);

  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={handleRefresh}
          tintColor={Colors.primary}
          colors={[Colors.primary]}
        />
      }>
      {/* Header */}
      <LinearGradient
        colors={[Colors.bgElevated, Colors.bg]}
        style={styles.headerGradient}>
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>{greeting}</Text>
            <Text style={styles.username}>{user?.display_name ?? 'Music Lover'}</Text>
          </View>
          {user?.images?.[0] && (
            <FastImage
              source={{uri: user.images[0].url}}
              style={styles.avatar}
              resizeMode={FastImage.resizeMode.cover}
            />
          )}
        </View>
      </LinearGradient>

      {/* Quick Picks Grid */}
      {recentTracks && recentTracks.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Picks</Text>
          <View style={styles.quickGrid}>
            {recentTracks.slice(0, 6).map((track, idx) => (
              <QuickPickCard
                key={track.id}
                track={track}
                onPress={() => handlePlayTrack(recentTracks, idx)}
              />
            ))}
          </View>
        </View>
      )}

      {/* New Releases */}
      {newReleases && (
        <View style={styles.section}>
          <SectionHeader title="New Releases" />
          <FlatList
            data={newReleases}
            keyExtractor={item => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.horizontalList}
            renderItem={({item, index}) => (
              <AlbumCard
                album={item}
                onPress={() =>
                  SpotifyAPI.getAlbumTracks(item.id).then(tracks =>
                    handlePlayTrack(tracks, 0),
                  )
                }
              />
            )}
          />
        </View>
      )}

      {/* Top Tracks */}
      {topTracks && (
        <View style={styles.section}>
          <SectionHeader title="Your Top Tracks" />
          {topTracks.slice(0, 5).map((track, idx) => (
            <TrackRow
              key={track.id}
              track={track}
              index={idx + 1}
              onPress={() => handlePlayTrack(topTracks, idx)}
            />
          ))}
        </View>
      )}

      {/* Featured Playlists */}
      {featured?.playlists?.items && (
        <View style={styles.section}>
          <SectionHeader title={featured.message ?? 'Featured Playlists'} />
          <FlatList
            data={featured.playlists.items}
            keyExtractor={item => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.horizontalList}
            renderItem={({item}) => <PlaylistCard playlist={item} />}
          />
        </View>
      )}

      {/* Recommended */}
      {recommendations?.tracks && (
        <View style={styles.section}>
          <SectionHeader title="Recommended For You" />
          <FlatList
            data={recommendations.tracks}
            keyExtractor={item => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.horizontalList}
            renderItem={({item, index}) => (
              <TrackCard
                track={item}
                onPress={() =>
                  recommendations.tracks && handlePlayTrack(recommendations.tracks, index)
                }
              />
            )}
          />
        </View>
      )}

      <View style={{height: 100}} />
    </ScrollView>
  );
};

// ── Sub-components ──────────────────────────────────────────────────────────
const SectionHeader: React.FC<{title: string; onMore?: () => void}> = ({title, onMore}) => (
  <View style={styles.sectionHeader}>
    <Text style={styles.sectionTitle}>{title}</Text>
    {onMore && (
      <TouchableOpacity onPress={onMore}>
        <Text style={styles.seeAll}>See all</Text>
      </TouchableOpacity>
    )}
  </View>
);

const QuickPickCard: React.FC<{track: SpotifyTrack; onPress: () => void}> = ({track, onPress}) => {
  const artwork = SpotifyAPI.getBestImage(track.album?.images ?? [], 'small');
  return (
    <TouchableOpacity style={styles.quickCard} onPress={onPress}>
      <FastImage source={{uri: artwork}} style={styles.quickArt} resizeMode={FastImage.resizeMode.cover} />
      <Text style={styles.quickTitle} numberOfLines={2}>{track.name}</Text>
    </TouchableOpacity>
  );
};

const AlbumCard: React.FC<{album: SpotifyAlbum; onPress: () => void}> = ({album, onPress}) => {
  const artwork = SpotifyAPI.getBestImage(album.images, 'medium');
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <FastImage source={{uri: artwork}} style={styles.cardArt} resizeMode={FastImage.resizeMode.cover} />
      <Text style={styles.cardTitle} numberOfLines={2}>{album.name}</Text>
      <Text style={styles.cardSub} numberOfLines={1}>
        {album.artists.map(a => a.name).join(', ')}
      </Text>
    </TouchableOpacity>
  );
};

const PlaylistCard: React.FC<{playlist: SpotifyPlaylist}> = ({playlist}) => {
  const artwork = SpotifyAPI.getBestImage(playlist.images, 'medium');
  return (
    <TouchableOpacity style={styles.card}>
      <FastImage source={{uri: artwork}} style={styles.cardArt} resizeMode={FastImage.resizeMode.cover} />
      <Text style={styles.cardTitle} numberOfLines={2}>{playlist.name}</Text>
      <Text style={styles.cardSub} numberOfLines={1}>{playlist.tracks.total} tracks</Text>
    </TouchableOpacity>
  );
};

const TrackCard: React.FC<{track: SpotifyTrack; onPress: () => void}> = ({track, onPress}) => {
  const artwork = SpotifyAPI.getBestImage(track.album?.images ?? [], 'medium');
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <FastImage source={{uri: artwork}} style={styles.cardArt} resizeMode={FastImage.resizeMode.cover} />
      <Text style={styles.cardTitle} numberOfLines={2}>{track.name}</Text>
      <Text style={styles.cardSub} numberOfLines={1}>
        {track.artists.map(a => a.name).join(', ')}
      </Text>
    </TouchableOpacity>
  );
};

const TrackRow: React.FC<{track: SpotifyTrack; index: number; onPress: () => void}> = ({
  track, index, onPress,
}) => {
  const artwork = SpotifyAPI.getBestImage(track.album?.images ?? [], 'small');
  return (
    <TouchableOpacity style={styles.trackRow} onPress={onPress}>
      <Text style={styles.trackIndex}>{index}</Text>
      <FastImage source={{uri: artwork}} style={styles.trackArt} resizeMode={FastImage.resizeMode.cover} />
      <View style={styles.trackMeta}>
        <Text style={styles.trackName} numberOfLines={1}>{track.name}</Text>
        <Text style={styles.trackArtist} numberOfLines={1}>
          {track.artists.map(a => a.name).join(', ')}
        </Text>
      </View>
      <Text style={styles.trackDuration}>{SpotifyAPI.formatDuration(track.duration_ms)}</Text>
    </TouchableOpacity>
  );
};

// ── Utils ───────────────────────────────────────────────────────────────────
function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

// ── Styles ──────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: Colors.bg},
  headerGradient: {paddingBottom: Spacing.base},
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Spacing.base,
    paddingTop: Spacing.xl,
  },
  greeting: {color: Colors.textSecondary, fontSize: Typography.base},
  username: {
    color: Colors.textPrimary,
    fontSize: Typography.xl,
    fontWeight: '700',
    marginTop: 2,
  },
  avatar: {width: 44, height: 44, borderRadius: 22},
  section: {paddingHorizontal: Spacing.base, marginBottom: Spacing.xl},
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    color: Colors.textPrimary,
    fontSize: Typography.lg,
    fontWeight: '700',
    marginBottom: Spacing.md,
  },
  seeAll: {color: Colors.primary, fontSize: Typography.sm, fontWeight: '600'},
  quickGrid: {flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm},
  quickCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bgCard,
    borderRadius: BorderRadius.sm,
    overflow: 'hidden',
    width: (SCREEN_W - Spacing.base * 2 - Spacing.sm) / 2,
    gap: Spacing.sm,
  },
  quickArt: {width: 54, height: 54},
  quickTitle: {
    flex: 1,
    color: Colors.textPrimary,
    fontSize: Typography.sm,
    fontWeight: '600',
    paddingRight: Spacing.sm,
  },
  horizontalList: {paddingRight: Spacing.base, gap: Spacing.md},
  card: {width: CARD_W},
  cardArt: {
    width: CARD_W,
    height: CARD_W,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.sm,
  },
  cardTitle: {
    color: Colors.textPrimary,
    fontSize: Typography.sm,
    fontWeight: '600',
    lineHeight: 18,
  },
  cardSub: {color: Colors.textSecondary, fontSize: Typography.xs, marginTop: 2},
  trackRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
    gap: Spacing.md,
  },
  trackIndex: {
    color: Colors.textMuted,
    fontSize: Typography.base,
    width: 20,
    textAlign: 'center',
  },
  trackArt: {width: 48, height: 48, borderRadius: BorderRadius.xs},
  trackMeta: {flex: 1},
  trackName: {color: Colors.textPrimary, fontSize: Typography.base, fontWeight: '600'},
  trackArtist: {color: Colors.textSecondary, fontSize: Typography.sm, marginTop: 2},
  trackDuration: {color: Colors.textMuted, fontSize: Typography.sm},
});

export default HomeScreen;
