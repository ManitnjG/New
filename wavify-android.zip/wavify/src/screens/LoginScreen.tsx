import React, {useEffect, useState, useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Linking,
  Alert,
  Platform,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import {Colors, Spacing, BorderRadius, Typography} from '@theme/index';
import {useAppStore} from '@store/index';
import {
  buildAuthURL,
  exchangeCodeForTokens,
  generatePKCE,
  getTokens,
  SpotifyAPI,
  SPOTIFY_CONFIG,
} from '@services/spotify';
import {MMKV} from 'react-native-mmkv';

const storage = new MMKV({id: 'pkce'});

const LoginScreen: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const setUser = useAppStore(s => s.setUser);
  const setIsAuthenticated = useAppStore(s => s.setIsAuthenticated);
  const setAuthLoading = useAppStore(s => s.setAuthLoading);
  const setAuthError = useAppStore(s => s.setAuthError);

  // Handle deep link callback
  useEffect(() => {
    const handleURL = async ({url}: {url: string}) => {
      if (!url.startsWith(SPOTIFY_CONFIG.REDIRECT_URI)) return;
      const parsed = new URL(url);
      const code = parsed.searchParams.get('code');
      const error = parsed.searchParams.get('error');

      if (error || !code) {
        setAuthError(error ?? 'Authorization failed');
        setLoading(false);
        return;
      }

      const verifier = storage.getString('pkce_verifier');
      if (!verifier) {
        setAuthError('Missing PKCE verifier');
        setLoading(false);
        return;
      }

      try {
        await exchangeCodeForTokens(code, verifier);
        storage.delete('pkce_verifier');
        const user = await SpotifyAPI.getCurrentUser();
        setUser(user);
        setIsAuthenticated(true);
      } catch (err: any) {
        setAuthError(err.message ?? 'Token exchange failed');
        Alert.alert('Login Error', err.message ?? 'Could not complete login');
      } finally {
        setLoading(false);
      }
    };

    const sub = Linking.addEventListener('url', handleURL);

    // Check for initial URL (app opened via link)
    Linking.getInitialURL().then(url => {
      if (url) handleURL({url});
    });

    return () => sub.remove();
  }, [setUser, setIsAuthenticated, setAuthError]);

  const handleLogin = useCallback(async () => {
    try {
      setLoading(true);
      setAuthError(null);

      const {verifier, challenge} = await generatePKCE();
      storage.set('pkce_verifier', verifier);

      const authURL = buildAuthURL(challenge);
      const supported = await Linking.canOpenURL(authURL);

      if (!supported) {
        throw new Error('Cannot open Spotify login URL');
      }

      await Linking.openURL(authURL);
    } catch (err: any) {
      setLoading(false);
      setAuthError(err.message);
      Alert.alert('Login Error', err.message);
    }
  }, [setAuthError]);

  // Check existing tokens on mount
  useEffect(() => {
    const checkAuth = async () => {
      const tokens = getTokens();
      if (tokens) {
        try {
          const user = await SpotifyAPI.getCurrentUser();
          setUser(user);
          setIsAuthenticated(true);
        } catch {
          // Token invalid, stay on login
        }
      }
      setAuthLoading(false);
    };
    checkAuth();
  }, [setUser, setIsAuthenticated, setAuthLoading]);

  return (
    <LinearGradient
      colors={['#1a1a2e', '#16213e', '#0f3460', '#1a1a2e']}
      style={styles.container}
      start={{x: 0, y: 0}}
      end={{x: 1, y: 1}}>
      {/* Logo */}
      <View style={styles.logoSection}>
        <View style={styles.logoCircle}>
          <Text style={styles.logoIcon}>🎵</Text>
        </View>
        <Text style={styles.appName}>Wavify</Text>
        <Text style={styles.tagline}>Premium Music Experience</Text>
      </View>

      {/* Features */}
      <View style={styles.features}>
        {[
          {icon: '🎛️', text: 'Built-in 10-band Equalizer'},
          {icon: '🔍', text: 'Spotify Full Metadata & Search'},
          {icon: '📋', text: 'Drag-and-drop Queue'},
          {icon: '⚡', text: 'Blazing Fast Performance'},
          {icon: '🎨', text: 'Dynamic Album Art Theming'},
          {icon: '📴', text: 'Background Playback'},
        ].map(({icon, text}) => (
          <View key={text} style={styles.feature}>
            <Text style={styles.featureIcon}>{icon}</Text>
            <Text style={styles.featureText}>{text}</Text>
          </View>
        ))}
      </View>

      {/* Login Button */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.spotifyBtn}
          onPress={handleLogin}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator color={Colors.black} />
          ) : (
            <>
              <Text style={styles.spotifyLogo}>●</Text>
              <Text style={styles.spotifyBtnText}>Continue with Spotify</Text>
            </>
          )}
        </TouchableOpacity>

        <Text style={styles.disclaimer}>
          By continuing, you agree to Spotify's Terms of Service.{'\n'}
          This app uses Spotify Web API for metadata only.
        </Text>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.xl,
    paddingTop: 80,
    paddingBottom: 50,
  },
  logoSection: {alignItems: 'center'},
  logoCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.base,
    shadowColor: Colors.primary,
    shadowOffset: {width: 0, height: 8},
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 15,
  },
  logoIcon: {fontSize: 48},
  appName: {
    color: Colors.white,
    fontSize: Typography.xxxl,
    fontWeight: '900',
    letterSpacing: 2,
  },
  tagline: {
    color: Colors.textSecondary,
    fontSize: Typography.base,
    marginTop: Spacing.xs,
  },
  features: {gap: Spacing.md, paddingVertical: Spacing.xl},
  feature: {flexDirection: 'row', alignItems: 'center', gap: Spacing.md},
  featureIcon: {fontSize: 24, width: 36, textAlign: 'center'},
  featureText: {color: Colors.textPrimary, fontSize: Typography.base, fontWeight: '500'},
  footer: {gap: Spacing.base},
  spotifyBtn: {
    backgroundColor: Colors.primary,
    borderRadius: BorderRadius.full,
    paddingVertical: Spacing.base + 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    shadowColor: Colors.primary,
    shadowOffset: {width: 0, height: 6},
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 10,
  },
  spotifyLogo: {color: Colors.black, fontSize: 22, fontWeight: '900'},
  spotifyBtnText: {
    color: Colors.black,
    fontSize: Typography.base,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  disclaimer: {
    color: Colors.textMuted,
    fontSize: Typography.xs,
    textAlign: 'center',
    lineHeight: 18,
  },
});

export default LoginScreen;
