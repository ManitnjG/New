import React, {useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Dimensions,
} from 'react-native';
import Slider from '@react-native-community/slider';
import {Colors, Spacing, BorderRadius, Typography} from '@theme/index';
import {useAppStore, EQ_PRESETS, DEFAULT_EQ_BANDS} from '@store/index';

const {width: SCREEN_W} = Dimensions.get('window');

const EqualizerScreen: React.FC = () => {
  const {
    eqEnabled,
    eqBands,
    activePreset,
    preampGain,
    setEQEnabled,
    setBandGain,
    applyPreset,
    resetEQ,
    setPreampGain,
  } = useAppStore();

  const handleBandChange = useCallback(
    (index: number, value: number) => {
      setBandGain(index, value);
    },
    [setBandGain],
  );

  const maxGain = 12;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Equalizer</Text>
        <View style={styles.toggleRow}>
          <Text style={styles.toggleLabel}>
            {eqEnabled ? 'ON' : 'OFF'}
          </Text>
          <Switch
            value={eqEnabled}
            onValueChange={setEQEnabled}
            trackColor={{false: Colors.bgSurface, true: Colors.primary}}
            thumbColor={Colors.white}
          />
        </View>
      </View>

      {/* Preamp */}
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>Preamp</Text>
          <Text style={styles.gainValue}>{preampGain > 0 ? '+' : ''}{preampGain.toFixed(1)} dB</Text>
        </View>
        <Slider
          style={styles.preampSlider}
          value={preampGain}
          onValueChange={setPreampGain}
          minimumValue={-12}
          maximumValue={12}
          step={0.5}
          minimumTrackTintColor={Colors.primary}
          maximumTrackTintColor={Colors.bgSurface}
          thumbTintColor={Colors.primary}
          disabled={!eqEnabled}
        />
        <View style={styles.preampLabels}>
          <Text style={styles.preampLabel}>-12 dB</Text>
          <Text style={styles.preampLabel}>0</Text>
          <Text style={styles.preampLabel}>+12 dB</Text>
        </View>
      </View>

      {/* EQ Bands - Vertical Sliders */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Bands</Text>
        <View style={styles.bandsContainer}>
          {/* Y-axis labels */}
          <View style={styles.yAxis}>
            {['+12', '+6', '0', '-6', '-12'].map(label => (
              <Text key={label} style={styles.yLabel}>{label}</Text>
            ))}
          </View>

          {/* Band Sliders */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.bandsScroll}>
            <View style={styles.bands}>
              {eqBands.map((band, index) => (
                <View key={band.frequency} style={styles.band}>
                  {/* Gain label */}
                  <Text style={styles.bandGain}>
                    {band.gain > 0 ? '+' : ''}{band.gain.toFixed(0)}
                  </Text>

                  {/* Vertical slider (rotated) */}
                  <View style={styles.sliderContainer}>
                    <Slider
                      style={styles.bandSlider}
                      value={band.gain}
                      onValueChange={val => handleBandChange(index, val)}
                      minimumValue={-maxGain}
                      maximumValue={maxGain}
                      step={0.5}
                      minimumTrackTintColor={Colors.eqBand}
                      maximumTrackTintColor={Colors.eqBandInactive}
                      thumbTintColor={eqEnabled ? Colors.primary : Colors.textMuted}
                      disabled={!eqEnabled}
                      inverted
                    />
                  </View>

                  {/* Frequency label */}
                  <Text style={styles.bandLabel}>{band.label}</Text>
                </View>
              ))}
            </View>
          </ScrollView>
        </View>
      </View>

      {/* Presets */}
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>Presets</Text>
          <TouchableOpacity onPress={resetEQ}>
            <Text style={styles.resetBtn}>Reset</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.presets}>
          {EQ_PRESETS.map(preset => (
            <TouchableOpacity
              key={preset.id}
              style={[
                styles.preset,
                activePreset === preset.id && styles.presetActive,
              ]}
              onPress={() => applyPreset(preset.id)}
              disabled={!eqEnabled}>
              <Text
                style={[
                  styles.presetText,
                  activePreset === preset.id && styles.presetTextActive,
                ]}>
                {preset.name}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Preset Visualizer */}
      {activePreset !== 'custom' && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Curve Preview</Text>
          <View style={styles.visualizer}>
            {eqBands.map((band, i) => {
              const heightPct = ((band.gain + maxGain) / (maxGain * 2)) * 100;
              return (
                <View key={i} style={styles.vizBar}>
                  <View
                    style={[
                      styles.vizFill,
                      {
                        height: `${heightPct}%`,
                        backgroundColor:
                          band.gain > 0 ? Colors.primary : Colors.accentBlue,
                        opacity: eqEnabled ? 1 : 0.3,
                      },
                    ]}
                  />
                </View>
              );
            })}
          </View>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: Colors.bg},
  content: {padding: Spacing.base, paddingBottom: Spacing.xxxl},
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.base,
    paddingVertical: Spacing.sm,
  },
  title: {
    color: Colors.textPrimary,
    fontSize: Typography.xxl,
    fontWeight: '700',
  },
  toggleRow: {flexDirection: 'row', alignItems: 'center', gap: Spacing.sm},
  toggleLabel: {color: Colors.textSecondary, fontSize: Typography.sm, fontWeight: '600'},
  card: {
    backgroundColor: Colors.bgCard,
    borderRadius: BorderRadius.lg,
    padding: Spacing.base,
    marginBottom: Spacing.base,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  cardTitle: {
    color: Colors.textPrimary,
    fontSize: Typography.base,
    fontWeight: '700',
    marginBottom: Spacing.sm,
  },
  gainValue: {color: Colors.primary, fontSize: Typography.sm, fontWeight: '600'},
  preampSlider: {width: '100%', height: 40},
  preampLabels: {flexDirection: 'row', justifyContent: 'space-between', marginTop: -8},
  preampLabel: {color: Colors.textMuted, fontSize: Typography.xs},
  bandsContainer: {flexDirection: 'row'},
  yAxis: {justifyContent: 'space-between', paddingVertical: 10, marginRight: Spacing.sm},
  yLabel: {color: Colors.textMuted, fontSize: 9, textAlign: 'right'},
  bandsScroll: {flex: 1},
  bands: {flexDirection: 'row', alignItems: 'center', gap: 2},
  band: {alignItems: 'center', width: (SCREEN_W - 100) / 10},
  bandGain: {color: Colors.primary, fontSize: 8, marginBottom: 2, fontWeight: '600'},
  sliderContainer: {height: 150, justifyContent: 'center'},
  bandSlider: {width: 150, height: 40, transform: [{rotate: '-90deg'}]},
  bandLabel: {color: Colors.textSecondary, fontSize: 9, marginTop: 4},
  resetBtn: {color: Colors.primary, fontSize: Typography.sm, fontWeight: '600'},
  presets: {flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, marginTop: Spacing.xs},
  preset: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs + 2,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.bgSurface,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  presetActive: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  presetText: {color: Colors.textSecondary, fontSize: Typography.sm},
  presetTextActive: {color: Colors.black, fontWeight: '700'},
  visualizer: {
    flexDirection: 'row',
    height: 80,
    gap: 3,
    alignItems: 'flex-end',
    marginTop: Spacing.sm,
  },
  vizBar: {flex: 1, height: '100%', justifyContent: 'flex-end'},
  vizFill: {width: '100%', borderRadius: 2, minHeight: 2},
});

export default EqualizerScreen;
