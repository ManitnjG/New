import React, {useState, useCallback, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  Keyboard,
} from 'react-native';
import {useQuery} from '@tanstack/react-query';
import FastImage from 'react-native-fast-image';
import {Colors, Spacing, BorderRadius, Typography} from '@theme/index';
import SpotifyAPI, {SpotifyTrack, SpotifyArtist, SpotifyAlbum, SearchType} from '@services/spotify';
import {PlayerService} from '@services/player';

type FilterType = 'all' | 'tracks' | 'artists' | 'albums';

const FILTERS: {label: string; value: FilterType}[] = [
  {label: 'All', value: 'all'},
  {label: 'Songs', value: 'tracks'},
  {label: 'Artists', value: 'artists'},
  {label: 'Albums', value: 'albums'},
];

const SearchScreen: React.FC = () => {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleQueryChange = useCallback((text: string) => {
    setQuery(text);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setDebouncedQuery(text);
    }, 350);
  }, []);

  const getSearchTypes = (): SearchType[] => {
    if (filter === 'all') return ['track', 'artist', 'album'];
    if (filter === 'tracks') return ['track'];
    if (filter === 'artists') return ['artist'];
    return ['album'];
  };

  const {data, isLoading, isFetching} = useQuery({
    queryKey: ['search', debouncedQuery, filter],
    queryFn: () => SpotifyAPI.search(debouncedQuery, getSearchTypes(), 20),
    enabled: debouncedQuery.trim().length >= 1,
    staleTime: 30_000,
  });

  const handlePlayTrack = useCallback(async (tracks: SpotifyTrack[], index: number) => {
    await PlayerService.loadQueue(tracks, index, true);
  }, []);

  const tracks = data?.tracks?.items ?? [];
  const artists = data?.artists?.items ?? [];
  const albums = data?.albums?.items ?? [];

  return (
    <View style={styles.container}>
      {/* Search Bar */}
      <View style={styles.searchBar}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.input}
          placeholder="Songs, artists, albums..."
          placeholderTextColor={Colors.textMuted}
          value={query}
          onChangeText={handleQueryChange}
          autoCapitalize="none"
          autoCorrect={false}
          returnKeyType="search"
        />
        {query.length > 0 && (
          <TouchableOpacity onPress={() => {setQuery(''); setDebouncedQuery('');}}>
            <Text style={styles.clearIcon}>✕</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Filters */}
      <View style={styles.filters}>
        {FILTERS.map(f => (
          <TouchableOpacity
            key={f.value}
            style={[styles.filter, filter === f.value && styles.filterActive]}
            onPress={() => setFilter(f.value)}>
            <Text style={[styles.filterText, filter === f.value && styles.filterTextActive]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {isLoading || isFetching ? (
        <View style={styles.loader}>
          <ActivityIndicator color={Colors.primary} size="large" />
        </View>
      ) : debouncedQuery.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyIcon}>🎵</Text>
          <Text style={styles.emptyText}>Search for your favorite music</Text>
        </View>
      ) : (
        <FlatList
          data={[
            ...(tracks.length > 0 ? [{type: 'header', label: 'Songs', key: 'h1'}] : []),
            ...tracks.map(t => ({type: 'track', data: t, key: `t_${t.id}`})),
            ...(artists.length > 0 ? [{type: 'header', label: 'Artists', key: 'h2'}] : []),
            ...artists.map(a => ({type: 'artist', data: a, key: `a_${a.id}`})),
            ...(albums.length > 0 ? [{type: 'header', label: 'Albums', key: 'h3'}] : []),
            ...albums.map(al => ({type: 'album', data: al, key: `al_${al.id}`})),
          ]}
          keyExtractor={item => item.key}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.results}
          onScroll={() => Keyboard.dismiss()}
          keyboardShouldPersistTaps="handled"
          renderItem={({item}) => {
            if (item.type === 'header') {
              return <Text style={styles.resultHeader}>{(item as any).label}</Text>;
            }
            if (item.type === 'track') {
              const track = (item as any).data as SpotifyTrack;
              return (
                <TrackResult
                  track={track}
                  onPress={() => handlePlayTrack(tracks, tracks.indexOf(track))}
                />
              );
            }
            if (item.type === 'artist') {
              return <ArtistResult artist={(item as any).data as SpotifyArtist} />;
            }
            return <AlbumResult album={(item as any).data as SpotifyAlbum} />;
          }}
        />
      )}
    </View>
  );
};

// ── Result Items ─────────────────────────────────────────────────────────────
const TrackResult: React.FC<{track: SpotifyTrack; onPress: () => void}> = ({track, onPress}) => {
  const artwork = SpotifyAPI.getBestImage(track.album?.images ?? [], 'small');
  return (
    <TouchableOpacity style={styles.resultRow} onPress={onPress}>
      <FastImage source={{uri: artwork}} style={styles.resultArt} resizeMode={FastImage.resizeMode.cover} />
      <View style={styles.resultMeta}>
        <Text style={styles.resultTitle} numberOfLines={1}>{track.name}</Text>
        <View style={styles.resultSubRow}>
          {track.explicit && <Text style={styles.explicit}>E</Text>}
          <Text style={styles.resultSub} numberOfLines={1}>
            {track.artists.map(a => a.name).join(', ')} · {track.album.name}
          </Text>
        </View>
      </View>
      <Text style={styles.resultDuration}>{SpotifyAPI.formatDuration(track.duration_ms)}</Text>
    </TouchableOpacity>
  );
};

const ArtistResult: React.FC<{artist: SpotifyArtist}> = ({artist}) => {
  const image = SpotifyAPI.getBestImage(artist.images ?? [], 'small');
  return (
    <TouchableOpacity style={styles.resultRow}>
      <FastImage
        source={{uri: image}}
        style={styles.resultArtCircle}
        resizeMode={FastImage.resizeMode.cover}
      />
      <View style={styles.resultMeta}>
        <Text style={styles.resultTitle} numberOfLines={1}>{artist.name}</Text>
        <Text style={styles.resultSub}>
          {artist.followers?.total
            ? `${(artist.followers.total / 1000).toFixed(0)}K followers`
            : 'Artist'}
        </Text>
      </View>
      <Text style={styles.resultDuration}>▶</Text>
    </TouchableOpacity>
  );
};

const AlbumResult: React.FC<{album: SpotifyAlbum}> = ({album}) => {
  const artwork = SpotifyAPI.getBestImage(album.images, 'small');
  return (
    <TouchableOpacity style={styles.resultRow}>
      <FastImage source={{uri: artwork}} style={styles.resultArt} resizeMode={FastImage.resizeMode.cover} />
      <View style={styles.resultMeta}>
        <Text style={styles.resultTitle} numberOfLines={1}>{album.name}</Text>
        <Text style={styles.resultSub} numberOfLines={1}>
          {album.album_type.charAt(0).toUpperCase() + album.album_type.slice(1)} · {album.artists.map(a => a.name).join(', ')}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: Colors.bg},
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bgCard,
    borderRadius: BorderRadius.full,
    margin: Spacing.base,
    paddingHorizontal: Spacing.md,
    gap: Spacing.sm,
  },
  searchIcon: {fontSize: 16},
  input: {
    flex: 1,
    color: Colors.textPrimary,
    fontSize: Typography.base,
    paddingVertical: Spacing.md,
  },
  clearIcon: {color: Colors.textMuted, fontSize: 16, padding: Spacing.xs},
  filters: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.base,
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  filter: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs + 2,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.bgCard,
  },
  filterActive: {backgroundColor: Colors.white},
  filterText: {color: Colors.textSecondary, fontSize: Typography.sm, fontWeight: '500'},
  filterTextActive: {color: Colors.black, fontWeight: '700'},
  loader: {flex: 1, justifyContent: 'center', alignItems: 'center'},
  empty: {flex: 1, justifyContent: 'center', alignItems: 'center', gap: Spacing.md},
  emptyIcon: {fontSize: 48},
  emptyText: {color: Colors.textSecondary, fontSize: Typography.base, textAlign: 'center'},
  results: {paddingHorizontal: Spacing.base, paddingBottom: 100},
  resultHeader: {
    color: Colors.textPrimary,
    fontSize: Typography.lg,
    fontWeight: '700',
    marginTop: Spacing.base,
    marginBottom: Spacing.sm,
  },
  resultRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
    gap: Spacing.md,
  },
  resultArt: {width: 54, height: 54, borderRadius: BorderRadius.xs},
  resultArtCircle: {width: 54, height: 54, borderRadius: 27},
  resultMeta: {flex: 1},
  resultTitle: {color: Colors.textPrimary, fontSize: Typography.base, fontWeight: '600'},
  resultSubRow: {flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginTop: 2},
  explicit: {
    color: Colors.textMuted,
    fontSize: 9,
    fontWeight: '700',
    borderWidth: 1,
    borderColor: Colors.textMuted,
    paddingHorizontal: 3,
    borderRadius: 2,
  },
  resultSub: {color: Colors.textSecondary, fontSize: Typography.sm, flex: 1},
  resultDuration: {color: Colors.textMuted, fontSize: Typography.sm},
});

export default SearchScreen;
