import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  SectionList,
} from 'react-native';
import {useQuery} from '@tanstack/react-query';
import FastImage from 'react-native-fast-image';
import {Colors, Spacing, BorderRadius, Typography} from '@theme/index';
import {useAppStore} from '@store/index';
import SpotifyAPI from '@services/spotify';
import {PlayerService} from '@services/player';

type LibTab = 'playlists' | 'albums' | 'liked';

const LibraryScreen: React.FC = () => {
  const [tab, setTab] = useState<LibTab>('playlists');
  const recentlyPlayed = useAppStore(s => s.recentlyPlayed);

  const {data: playlists, isLoading: playlistsLoading} = useQuery({
    queryKey: ['userPlaylists'],
    queryFn: () => SpotifyAPI.getUserPlaylists(50),
    staleTime: 2 * 60 * 1000,
  });

  const {data: likedTracks, isLoading: likedLoading} = useQuery({
    queryKey: ['likedTracks'],
    queryFn: () => SpotifyAPI.getSavedTracks(50),
    enabled: tab === 'liked',
    staleTime: 2 * 60 * 1000,
  });

  const {data: newReleases} = useQuery({
    queryKey: ['savedAlbums'],
    queryFn: () => SpotifyAPI.getNewReleases(20),
    enabled: tab === 'albums',
    staleTime: 5 * 60 * 1000,
  });

  const TABS: {label: string; value: LibTab}[] = [
    {label: 'Playlists', value: 'playlists'},
    {label: 'Albums', value: 'albums'},
    {label: 'Liked', value: 'liked'},
  ];

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Your Library</Text>
        <TouchableOpacity style={styles.addBtn}>
          <Text style={styles.addIcon}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        {TABS.map(t => (
          <TouchableOpacity
            key={t.value}
            style={[styles.tab, tab === t.value && styles.tabActive]}
            onPress={() => setTab(t.value)}>
            <Text style={[styles.tabText, tab === t.value && styles.tabTextActive]}>
              {t.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Recently Played Strip */}
      {recentlyPlayed.length > 0 && (
        <View style={styles.recentSection}>
          <Text style={styles.recentLabel}>Recently Played</Text>
          <FlatList
            data={recentlyPlayed.slice(0, 10)}
            keyExtractor={item => item.queueId}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.recentList}
            renderItem={({item, index}) => {
              const artwork = SpotifyAPI.getBestImage(item.album?.images ?? [], 'small');
              return (
                <TouchableOpacity
                  style={styles.recentCard}
                  onPress={() => PlayerService.loadQueue(recentlyPlayed, index, true)}>
                  <FastImage
                    source={{uri: artwork}}
                    style={styles.recentArt}
                    resizeMode={FastImage.resizeMode.cover}
                  />
                  <Text style={styles.recentTitle} numberOfLines={2}>{item.name}</Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      )}

      {/* Tab Content */}
      {tab === 'playlists' && (
        <FlatList
          data={playlists ?? []}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          renderItem={({item}) => {
            const artwork = SpotifyAPI.getBestImage(item.images, 'small');
            return (
              <TouchableOpacity style={styles.row}>
                <FastImage
                  source={{uri: artwork}}
                  style={styles.rowArt}
                  resizeMode={FastImage.resizeMode.cover}
                />
                <View style={styles.rowMeta}>
                  <Text style={styles.rowTitle} numberOfLines={1}>{item.name}</Text>
                  <Text style={styles.rowSub}>
                    {item.tracks.total} songs · {item.owner.display_name}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          }}
        />
      )}

      {tab === 'albums' && (
        <FlatList
          data={newReleases ?? []}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          renderItem={({item}) => {
            const artwork = SpotifyAPI.getBestImage(item.images, 'small');
            return (
              <TouchableOpacity style={styles.row}>
                <FastImage
                  source={{uri: artwork}}
                  style={styles.rowArt}
                  resizeMode={FastImage.resizeMode.cover}
                />
                <View style={styles.rowMeta}>
                  <Text style={styles.rowTitle} numberOfLines={1}>{item.name}</Text>
                  <Text style={styles.rowSub}>
                    {item.artists.map((a: any) => a.name).join(', ')} · {item.release_date.slice(0, 4)}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          }}
        />
      )}

      {tab === 'liked' && (
        <FlatList
          data={likedTracks?.items ?? []}
          keyExtractor={item => item.track.id}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          renderItem={({item, index}) => {
            const track = item.track;
            const artwork = SpotifyAPI.getBestImage(track.album?.images ?? [], 'small');
            const allTracks = likedTracks?.items.map(i => i.track) ?? [];
            return (
              <TouchableOpacity
                style={styles.row}
                onPress={() => PlayerService.loadQueue(allTracks, index, true)}>
                <FastImage
                  source={{uri: artwork}}
                  style={styles.rowArt}
                  resizeMode={FastImage.resizeMode.cover}
                />
                <View style={styles.rowMeta}>
                  <Text style={styles.rowTitle} numberOfLines={1}>{track.name}</Text>
                  <Text style={styles.rowSub} numberOfLines={1}>
                    {track.artists.map((a: any) => a.name).join(', ')}
                  </Text>
                </View>
                <Text style={styles.rowDuration}>{SpotifyAPI.formatDuration(track.duration_ms)}</Text>
              </TouchableOpacity>
            );
          }}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: Colors.bg},
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Spacing.base,
    paddingTop: Spacing.xl,
  },
  title: {color: Colors.textPrimary, fontSize: Typography.xxl, fontWeight: '700'},
  addBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.bgCard,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addIcon: {color: Colors.textPrimary, fontSize: 24, lineHeight: 28},
  tabs: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.base,
    gap: Spacing.sm,
    marginBottom: Spacing.base,
  },
  tab: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs + 2,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.bgCard,
  },
  tabActive: {backgroundColor: Colors.white},
  tabText: {color: Colors.textSecondary, fontSize: Typography.sm, fontWeight: '500'},
  tabTextActive: {color: Colors.black, fontWeight: '700'},
  recentSection: {marginBottom: Spacing.base},
  recentLabel: {
    color: Colors.textSecondary,
    fontSize: Typography.sm,
    fontWeight: '600',
    paddingHorizontal: Spacing.base,
    marginBottom: Spacing.sm,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  recentList: {paddingHorizontal: Spacing.base, gap: Spacing.md},
  recentCard: {width: 90, alignItems: 'center'},
  recentArt: {width: 80, height: 80, borderRadius: BorderRadius.sm, marginBottom: Spacing.xs},
  recentTitle: {color: Colors.textSecondary, fontSize: 11, textAlign: 'center'},
  list: {paddingHorizontal: Spacing.base, paddingBottom: 100},
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
    gap: Spacing.md,
  },
  rowArt: {width: 56, height: 56, borderRadius: BorderRadius.xs},
  rowMeta: {flex: 1},
  rowTitle: {color: Colors.textPrimary, fontSize: Typography.base, fontWeight: '600'},
  rowSub: {color: Colors.textSecondary, fontSize: Typography.sm, marginTop: 2},
  rowDuration: {color: Colors.textMuted, fontSize: Typography.sm},
});

export default LibraryScreen;
