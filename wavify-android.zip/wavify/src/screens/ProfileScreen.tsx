import React from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Alert, Switch,
} from 'react-native';
import {useQuery} from '@tanstack/react-query';
import FastImage from 'react-native-fast-image';
import LinearGradient from 'react-native-linear-gradient';
import {Colors, Spacing, BorderRadius, Typography} from '@theme/index';
import {useAppStore, useAuthUser} from '@store/index';
import SpotifyAPI, {clearTokens} from '@services/spotify';

interface Props {
  onOpenEQ?: () => void;
}

const ProfileScreen: React.FC<Props> = ({onOpenEQ}) => {
  const user            = useAuthUser();
  const logout          = useAppStore(s => s.logout);
  const isDynamicTheme  = useAppStore(s => s.isDynamicTheme);
  const setDynamicTheme = useAppStore(s => s.setDynamicTheme);
  const eqEnabled       = useAppStore(s => s.eqEnabled);
  const setEQEnabled    = useAppStore(s => s.setEQEnabled);

  const {data: topArtists} = useQuery({
    queryKey: ['topArtists'],
    queryFn:  () => SpotifyAPI.getTopArtists('medium_term', 5),
    staleTime: 10 * 60_000,
  });

  const avatar    = user?.images?.[0]?.url;
  const isPremium = user?.product === 'premium';

  const handleLogout = () =>
    Alert.alert('Sign Out', 'Are you sure?', [
      {text: 'Cancel', style: 'cancel'},
      {text: 'Sign Out', style: 'destructive', onPress: () => { clearTokens(); logout(); }},
    ]);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <LinearGradient colors={[Colors.bgElevated, Colors.bg]} style={styles.headerGradient}>
        <View style={styles.avatarSection}>
          {avatar ? (
            <FastImage source={{uri: avatar}} style={styles.avatar} resizeMode={FastImage.resizeMode.cover} />
          ) : (
            <View style={[styles.avatar, styles.avatarPlaceholder]}>
              <Text style={styles.avatarText}>{(user?.display_name?.[0] ?? '?').toUpperCase()}</Text>
            </View>
          )}
          <Text style={styles.displayName}>{user?.display_name ?? 'User'}</Text>
          <Text style={styles.email}>{user?.email}</Text>
          {isPremium && (
            <View style={styles.premiumBadge}><Text style={styles.premiumText}>✦ SPOTIFY PREMIUM</Text></View>
          )}
        </View>
      </LinearGradient>

      {topArtists && topArtists.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Top Artists</Text>
          {topArtists.map((artist, idx) => {
            const image = SpotifyAPI.getBestImage(artist.images ?? [], 'small');
            return (
              <View key={artist.id} style={styles.artistRow}>
                <Text style={styles.rank}>{idx + 1}</Text>
                <FastImage source={{uri: image}} style={styles.artistImg} resizeMode={FastImage.resizeMode.cover} />
                <View style={styles.artistMeta}>
                  <Text style={styles.artistName}>{artist.name}</Text>
                  <Text style={styles.artistGenre}>{artist.genres?.slice(0, 2).join(', ') ?? ''}</Text>
                </View>
                <Text style={styles.popularity}>{artist.popularity}%</Text>
              </View>
            );
          })}
        </View>
      )}

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Settings</Text>

        <View style={styles.settingsRow}>
          <Text style={styles.navIcon}>🎨</Text>
          <View style={styles.navMeta}>
            <Text style={styles.navLabel}>Dynamic Theme</Text>
            <Text style={styles.navSub}>Adapt color to album art</Text>
          </View>
          <Switch value={isDynamicTheme} onValueChange={setDynamicTheme}
            trackColor={{false: Colors.bgSurface, true: Colors.primary}} thumbColor={Colors.white} />
        </View>

        <View style={styles.settingsRow}>
          <Text style={styles.navIcon}>🎛️</Text>
          <View style={styles.navMeta}>
            <Text style={styles.navLabel}>Equalizer</Text>
            <Text style={styles.navSub}>Enable audio enhancement</Text>
          </View>
          <Switch value={eqEnabled} onValueChange={setEQEnabled}
            trackColor={{false: Colors.bgSurface, true: Colors.primary}} thumbColor={Colors.white} />
        </View>

        <TouchableOpacity style={styles.settingsNav} onPress={onOpenEQ}>
          <Text style={styles.navIcon}>🎚️</Text>
          <View style={styles.navMeta}>
            <Text style={styles.navLabel}>Equalizer Settings</Text>
            <Text style={styles.navSub}>10-band EQ, presets & preamp</Text>
          </View>
          <Text style={styles.navChev}>›</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.settingsNav}>
          <Text style={styles.navIcon}>🎵</Text>
          <View style={styles.navMeta}>
            <Text style={styles.navLabel}>Audio Quality</Text>
            <Text style={styles.navSub}>{isPremium ? 'High (320kbps)' : 'Normal (160kbps)'}</Text>
          </View>
          <Text style={styles.navChev}>›</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.settingsNav}>
          <Text style={styles.navIcon}>🔔</Text>
          <View style={styles.navMeta}>
            <Text style={styles.navLabel}>Notifications</Text>
            <Text style={styles.navSub}>New releases & updates</Text>
          </View>
          <Text style={styles.navChev}>›</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
        <Text style={styles.logoutText}>Sign Out of Spotify</Text>
      </TouchableOpacity>
      <Text style={styles.version}>Wavify v1.0.0 · Spotify Metadata</Text>
      <View style={{height: 100}} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: Colors.bg},
  content: {},
  headerGradient: {paddingBottom: Spacing.xl},
  avatarSection: {alignItems: 'center', paddingTop: Spacing.xxl, paddingHorizontal: Spacing.base},
  avatar: {width: 100, height: 100, borderRadius: 50, marginBottom: Spacing.md},
  avatarPlaceholder: {backgroundColor: Colors.primary, justifyContent: 'center', alignItems: 'center'},
  avatarText: {color: Colors.white, fontSize: Typography.xxxl, fontWeight: '700'},
  displayName: {color: Colors.textPrimary, fontSize: Typography.xl, fontWeight: '700'},
  email: {color: Colors.textSecondary, fontSize: Typography.sm, marginTop: 4},
  premiumBadge: {marginTop: Spacing.sm, backgroundColor: Colors.primary, paddingHorizontal: Spacing.md, paddingVertical: 4, borderRadius: BorderRadius.full},
  premiumText: {color: Colors.black, fontSize: Typography.xs, fontWeight: '800', letterSpacing: 1},
  section: {padding: Spacing.base, marginBottom: Spacing.sm},
  sectionTitle: {color: Colors.textPrimary, fontSize: Typography.lg, fontWeight: '700', marginBottom: Spacing.md},
  artistRow: {flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.sm, gap: Spacing.md},
  rank: {color: Colors.textMuted, fontSize: Typography.base, width: 20, textAlign: 'center'},
  artistImg: {width: 50, height: 50, borderRadius: 25},
  artistMeta: {flex: 1},
  artistName: {color: Colors.textPrimary, fontSize: Typography.base, fontWeight: '600'},
  artistGenre: {color: Colors.textSecondary, fontSize: Typography.sm, marginTop: 2},
  popularity: {color: Colors.primary, fontSize: Typography.sm, fontWeight: '700'},
  settingsRow: {flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.md, gap: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.divider},
  settingsNav: {flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.md, gap: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.divider},
  navIcon: {fontSize: 22, width: 32, textAlign: 'center'},
  navMeta: {flex: 1},
  navLabel: {color: Colors.textPrimary, fontSize: Typography.base, fontWeight: '600'},
  navSub: {color: Colors.textSecondary, fontSize: Typography.sm, marginTop: 2},
  navChev: {color: Colors.textMuted, fontSize: Typography.xl},
  logoutBtn: {margin: Spacing.base, padding: Spacing.md, borderRadius: BorderRadius.md, borderWidth: 1, borderColor: Colors.error, alignItems: 'center'},
  logoutText: {color: Colors.error, fontSize: Typography.base, fontWeight: '600'},
  version: {textAlign: 'center', color: Colors.textMuted, fontSize: Typography.xs, marginTop: Spacing.sm},
});

export default ProfileScreen;
