/**
 * useNetwork.ts
 * Monitors connection state. Auto-pauses player on disconnect,
 * auto-resumes when back online, and exposes isConnected flag for UI.
 */
import {useEffect, useRef, useState} from 'react';
import NetInfo, {NetInfoState} from '@react-native-community/netinfo';
import TrackPlayer, {State} from 'react-native-track-player';
import {useAppStore} from '@store/index';

export const useNetwork = () => {
  const [isConnected, setIsConnected] = useState(true);
  const [connectionType, setConnectionType] = useState<string>('unknown');
  const wasPlayingRef = useRef(false);
  const setNetworkError = useAppStore(s => s.setNetworkError);

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(async (state: NetInfoState) => {
      const connected = state.isConnected ?? false;
      setIsConnected(connected);
      setConnectionType(state.type ?? 'unknown');

      if (!connected) {
        // Lost connection — pause and remember state
        const {state: playState} = await TrackPlayer.getPlaybackState();
        wasPlayingRef.current = playState === State.Playing;
        if (wasPlayingRef.current) await TrackPlayer.pause();
        setNetworkError(true);
      } else {
        // Back online
        setNetworkError(false);
        // Auto-resume if we were playing
        if (wasPlayingRef.current) {
          setTimeout(async () => {
            try { await TrackPlayer.play(); wasPlayingRef.current = false; }
            catch {}
          }, 500); // slight delay so connection is stable
        }
      }
    });

    return () => unsubscribe();
  }, [setNetworkError]);

  return {isConnected, connectionType};
};
