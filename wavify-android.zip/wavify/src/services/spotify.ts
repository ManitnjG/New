/**
 * Spotify Web API Service
 * Handles OAuth2 PKCE auth + full metadata fetching
 * Docs: https://developer.spotify.com/documentation/web-api
 */

import axios, {AxiosInstance} from 'axios';
import {MMKV} from 'react-native-mmkv';

const storage = new MMKV({id: 'spotify-auth'});

// ─── Config ────────────────────────────────────────────────────────────────
// Replace these with your Spotify Developer Dashboard credentials
// https://developer.spotify.com/dashboard
export const SPOTIFY_CONFIG = {
  CLIENT_ID: 'YOUR_SPOTIFY_CLIENT_ID',
  CLIENT_SECRET: 'YOUR_SPOTIFY_CLIENT_SECRET', // Only for server-side / CC flow
  REDIRECT_URI: 'musicapp://spotify-callback',
  SCOPES: [
    'user-read-private',
    'user-read-email',
    'user-read-playback-state',
    'user-modify-playback-state',
    'user-read-currently-playing',
    'user-library-read',
    'user-library-modify',
    'playlist-read-private',
    'playlist-read-collaborative',
    'playlist-modify-public',
    'playlist-modify-private',
    'user-top-read',
    'user-read-recently-played',
    'streaming',
  ].join(' '),
  AUTH_URL: 'https://accounts.spotify.com/authorize',
  TOKEN_URL: 'https://accounts.spotify.com/api/token',
  API_BASE: 'https://api.spotify.com/v1',
};

// ─── Types ─────────────────────────────────────────────────────────────────
export interface SpotifyImage {
  url: string;
  height: number;
  width: number;
}

export interface SpotifyArtist {
  id: string;
  name: string;
  uri: string;
  href: string;
  images?: SpotifyImage[];
  genres?: string[];
  popularity?: number;
  followers?: {total: number};
  external_urls: {spotify: string};
}

export interface SpotifyAlbum {
  id: string;
  name: string;
  album_type: 'album' | 'single' | 'compilation';
  release_date: string;
  total_tracks: number;
  images: SpotifyImage[];
  artists: SpotifyArtist[];
  uri: string;
  href: string;
  label?: string;
  popularity?: number;
  copyrights?: Array<{text: string; type: string}>;
  external_urls: {spotify: string};
}

export interface SpotifyTrack {
  id: string;
  name: string;
  duration_ms: number;
  track_number: number;
  disc_number: number;
  explicit: boolean;
  preview_url: string | null;
  uri: string;
  href: string;
  popularity: number;
  is_playable?: boolean;
  artists: SpotifyArtist[];
  album: SpotifyAlbum;
  external_ids?: {isrc?: string; ean?: string; upc?: string};
  external_urls: {spotify: string};
  linked_from?: {id: string; uri: string};
}

export interface SpotifyPlaylist {
  id: string;
  name: string;
  description: string;
  public: boolean;
  collaborative: boolean;
  images: SpotifyImage[];
  owner: {id: string; display_name: string};
  tracks: {total: number; href: string};
  uri: string;
  href: string;
  external_urls: {spotify: string};
}

export interface SpotifyPlaylistTrack {
  added_at: string;
  added_by: {id: string};
  track: SpotifyTrack;
}

export interface SpotifyUser {
  id: string;
  display_name: string;
  email: string;
  country: string;
  product: 'premium' | 'free' | 'open';
  images: SpotifyImage[];
  followers: {total: number};
  uri: string;
  external_urls: {spotify: string};
}

export interface SpotifyAudioFeatures {
  id: string;
  danceability: number;     // 0-1
  energy: number;           // 0-1
  key: number;              // -1 to 11 (Pitch class notation)
  loudness: number;         // dB
  mode: 0 | 1;              // minor=0, major=1
  speechiness: number;      // 0-1
  acousticness: number;     // 0-1
  instrumentalness: number; // 0-1
  liveness: number;         // 0-1
  valence: number;          // 0-1 (musical positiveness)
  tempo: number;            // BPM
  time_signature: number;
  duration_ms: number;
}

export interface SpotifyRecommendations {
  tracks: SpotifyTrack[];
  seeds: Array<{
    id: string;
    type: string;
    initialPoolSize: number;
    afterFilteringSize: number;
    afterRelinkingSize: number;
  }>;
}

export interface SpotifySearchResult {
  tracks?: {items: SpotifyTrack[]; total: number; next: string | null};
  albums?: {items: SpotifyAlbum[]; total: number; next: string | null};
  artists?: {items: SpotifyArtist[]; total: number; next: string | null};
  playlists?: {items: SpotifyPlaylist[]; total: number; next: string | null};
}

export interface SpotifyAuthTokens {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  expires_at: number;
  token_type: string;
  scope: string;
}

export type SearchType = 'track' | 'album' | 'artist' | 'playlist';

// ─── Auth Helpers ──────────────────────────────────────────────────────────
const generateCodeVerifier = (length: number = 128): string => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

const sha256 = async (plain: string): Promise<ArrayBuffer> => {
  const encoder = new TextEncoder();
  const data = encoder.encode(plain);
  return crypto.subtle.digest('SHA-256', data);
};

const base64URLEncode = (buffer: ArrayBuffer): string => {
  return btoa(String.fromCharCode(...new Uint8Array(buffer)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '');
};

export const generatePKCE = async (): Promise<{verifier: string; challenge: string}> => {
  const verifier = generateCodeVerifier();
  const hashed = await sha256(verifier);
  const challenge = base64URLEncode(hashed);
  return {verifier, challenge};
};

export const buildAuthURL = (codeChallenge: string): string => {
  const params = new URLSearchParams({
    client_id: SPOTIFY_CONFIG.CLIENT_ID,
    response_type: 'code',
    redirect_uri: SPOTIFY_CONFIG.REDIRECT_URI,
    scope: SPOTIFY_CONFIG.SCOPES,
    code_challenge_method: 'S256',
    code_challenge: codeChallenge,
    show_dialog: 'false',
  });
  return `${SPOTIFY_CONFIG.AUTH_URL}?${params.toString()}`;
};

// ─── Token Management ───────────────────────────────────────────────────────
export const saveTokens = (tokens: SpotifyAuthTokens): void => {
  const withExpiry: SpotifyAuthTokens = {
    ...tokens,
    expires_at: Date.now() + tokens.expires_in * 1000,
  };
  storage.set('tokens', JSON.stringify(withExpiry));
};

export const getTokens = (): SpotifyAuthTokens | null => {
  const raw = storage.getString('tokens');
  if (!raw) return null;
  return JSON.parse(raw) as SpotifyAuthTokens;
};

export const clearTokens = (): void => {
  storage.delete('tokens');
};

export const isTokenExpired = (): boolean => {
  const tokens = getTokens();
  if (!tokens) return true;
  return Date.now() >= tokens.expires_at - 60_000; // 1 min buffer
};

export const exchangeCodeForTokens = async (
  code: string,
  verifier: string,
): Promise<SpotifyAuthTokens> => {
  const params = new URLSearchParams({
    client_id: SPOTIFY_CONFIG.CLIENT_ID,
    grant_type: 'authorization_code',
    code,
    redirect_uri: SPOTIFY_CONFIG.REDIRECT_URI,
    code_verifier: verifier,
  });

  const response = await axios.post(SPOTIFY_CONFIG.TOKEN_URL, params.toString(), {
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
  });

  const tokens: SpotifyAuthTokens = response.data;
  saveTokens(tokens);
  return tokens;
};

export const refreshAccessToken = async (): Promise<SpotifyAuthTokens> => {
  const tokens = getTokens();
  if (!tokens?.refresh_token) throw new Error('No refresh token');

  const params = new URLSearchParams({
    client_id: SPOTIFY_CONFIG.CLIENT_ID,
    grant_type: 'refresh_token',
    refresh_token: tokens.refresh_token,
  });

  const response = await axios.post(SPOTIFY_CONFIG.TOKEN_URL, params.toString(), {
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
  });

  const newTokens: SpotifyAuthTokens = {
    ...response.data,
    refresh_token: response.data.refresh_token ?? tokens.refresh_token,
  };
  saveTokens(newTokens);
  return newTokens;
};

// ─── Axios Instance ─────────────────────────────────────────────────────────
const createSpotifyClient = (): AxiosInstance => {
  const client = axios.create({
    baseURL: SPOTIFY_CONFIG.API_BASE,
    headers: {'Content-Type': 'application/json'},
  });

  // Auto-attach & refresh token
  client.interceptors.request.use(async config => {
    if (isTokenExpired()) {
      await refreshAccessToken();
    }
    const tokens = getTokens();
    if (tokens) {
      config.headers.Authorization = `Bearer ${tokens.access_token}`;
    }
    return config;
  });

  // Retry on 401
  client.interceptors.response.use(
    res => res,
    async error => {
      if (error.response?.status === 401) {
        const tokens = await refreshAccessToken();
        error.config.headers.Authorization = `Bearer ${tokens.access_token}`;
        return client(error.config);
      }
      return Promise.reject(error);
    },
  );

  return client;
};

const spotifyClient = createSpotifyClient();

// ─── API Methods ────────────────────────────────────────────────────────────
export const SpotifyAPI = {
  // ── User ─────────────────────────────────────────────
  getCurrentUser: async (): Promise<SpotifyUser> => {
    const {data} = await spotifyClient.get('/me');
    return data;
  },

  getTopTracks: async (
    timeRange: 'short_term' | 'medium_term' | 'long_term' = 'medium_term',
    limit: number = 20,
  ): Promise<SpotifyTrack[]> => {
    const {data} = await spotifyClient.get('/me/top/tracks', {
      params: {time_range: timeRange, limit},
    });
    return data.items;
  },

  getTopArtists: async (
    timeRange: 'short_term' | 'medium_term' | 'long_term' = 'medium_term',
    limit: number = 20,
  ): Promise<SpotifyArtist[]> => {
    const {data} = await spotifyClient.get('/me/top/artists', {
      params: {time_range: timeRange, limit},
    });
    return data.items;
  },

  getRecentlyPlayed: async (limit: number = 20): Promise<SpotifyTrack[]> => {
    const {data} = await spotifyClient.get('/me/player/recently-played', {
      params: {limit},
    });
    return data.items.map((item: {track: SpotifyTrack}) => item.track);
  },

  // ── Search ────────────────────────────────────────────
  search: async (
    query: string,
    types: SearchType[] = ['track', 'album', 'artist', 'playlist'],
    limit: number = 20,
    offset: number = 0,
  ): Promise<SpotifySearchResult> => {
    const {data} = await spotifyClient.get('/search', {
      params: {
        q: query,
        type: types.join(','),
        limit,
        offset,
        market: 'from_token',
      },
    });
    return data;
  },

  // ── Tracks ────────────────────────────────────────────
  getTrack: async (id: string): Promise<SpotifyTrack> => {
    const {data} = await spotifyClient.get(`/tracks/${id}`, {
      params: {market: 'from_token'},
    });
    return data;
  },

  getTracks: async (ids: string[]): Promise<SpotifyTrack[]> => {
    const {data} = await spotifyClient.get('/tracks', {
      params: {ids: ids.join(','), market: 'from_token'},
    });
    return data.tracks;
  },

  getAudioFeatures: async (id: string): Promise<SpotifyAudioFeatures> => {
    const {data} = await spotifyClient.get(`/audio-features/${id}`);
    return data;
  },

  getMultipleAudioFeatures: async (ids: string[]): Promise<SpotifyAudioFeatures[]> => {
    const {data} = await spotifyClient.get('/audio-features', {
      params: {ids: ids.join(',')},
    });
    return data.audio_features;
  },

  getSavedTracks: async (
    limit: number = 50,
    offset: number = 0,
  ): Promise<{items: Array<{added_at: string; track: SpotifyTrack}>; total: number}> => {
    const {data} = await spotifyClient.get('/me/tracks', {
      params: {limit, offset, market: 'from_token'},
    });
    return data;
  },

  saveTrack: async (id: string): Promise<void> => {
    await spotifyClient.put('/me/tracks', null, {params: {ids: id}});
  },

  removeTrack: async (id: string): Promise<void> => {
    await spotifyClient.delete('/me/tracks', {params: {ids: id}});
  },

  isTrackSaved: async (ids: string[]): Promise<boolean[]> => {
    const {data} = await spotifyClient.get('/me/tracks/contains', {
      params: {ids: ids.join(',')},
    });
    return data;
  },

  // ── Albums ────────────────────────────────────────────
  getAlbum: async (id: string): Promise<SpotifyAlbum & {tracks: {items: SpotifyTrack[]}}> => {
    const {data} = await spotifyClient.get(`/albums/${id}`, {
      params: {market: 'from_token'},
    });
    return data;
  },

  getAlbumTracks: async (
    id: string,
    limit: number = 50,
    offset: number = 0,
  ): Promise<SpotifyTrack[]> => {
    const {data} = await spotifyClient.get(`/albums/${id}/tracks`, {
      params: {limit, offset, market: 'from_token'},
    });
    return data.items;
  },

  getNewReleases: async (
    limit: number = 20,
    offset: number = 0,
  ): Promise<SpotifyAlbum[]> => {
    const {data} = await spotifyClient.get('/browse/new-releases', {
      params: {limit, offset},
    });
    return data.albums.items;
  },

  // ── Artists ───────────────────────────────────────────
  getArtist: async (id: string): Promise<SpotifyArtist> => {
    const {data} = await spotifyClient.get(`/artists/${id}`);
    return data;
  },

  getArtistTopTracks: async (id: string, market: string = 'US'): Promise<SpotifyTrack[]> => {
    const {data} = await spotifyClient.get(`/artists/${id}/top-tracks`, {
      params: {market},
    });
    return data.tracks;
  },

  getArtistAlbums: async (
    id: string,
    limit: number = 20,
  ): Promise<SpotifyAlbum[]> => {
    const {data} = await spotifyClient.get(`/artists/${id}/albums`, {
      params: {limit, include_groups: 'album,single', market: 'from_token'},
    });
    return data.items;
  },

  getRelatedArtists: async (id: string): Promise<SpotifyArtist[]> => {
    const {data} = await spotifyClient.get(`/artists/${id}/related-artists`);
    return data.artists;
  },

  // ── Playlists ─────────────────────────────────────────
  getPlaylist: async (id: string): Promise<SpotifyPlaylist> => {
    const {data} = await spotifyClient.get(`/playlists/${id}`, {
      params: {market: 'from_token'},
    });
    return data;
  },

  getPlaylistTracks: async (
    id: string,
    limit: number = 50,
    offset: number = 0,
  ): Promise<SpotifyPlaylistTrack[]> => {
    const {data} = await spotifyClient.get(`/playlists/${id}/tracks`, {
      params: {limit, offset, market: 'from_token'},
    });
    return data.items;
  },

  getUserPlaylists: async (
    limit: number = 50,
    offset: number = 0,
  ): Promise<SpotifyPlaylist[]> => {
    const {data} = await spotifyClient.get('/me/playlists', {
      params: {limit, offset},
    });
    return data.items;
  },

  createPlaylist: async (
    userId: string,
    name: string,
    description: string = '',
    isPublic: boolean = false,
  ): Promise<SpotifyPlaylist> => {
    const {data} = await spotifyClient.post(`/users/${userId}/playlists`, {
      name,
      description,
      public: isPublic,
    });
    return data;
  },

  addTracksToPlaylist: async (playlistId: string, uris: string[]): Promise<void> => {
    await spotifyClient.post(`/playlists/${playlistId}/tracks`, {uris});
  },

  removeTracksFromPlaylist: async (playlistId: string, uris: string[]): Promise<void> => {
    await spotifyClient.delete(`/playlists/${playlistId}/tracks`, {
      data: {tracks: uris.map(uri => ({uri}))},
    });
  },

  // ── Recommendations ───────────────────────────────────
  getRecommendations: async (params: {
    seed_tracks?: string[];
    seed_artists?: string[];
    seed_genres?: string[];
    limit?: number;
    target_energy?: number;
    target_valence?: number;
    target_tempo?: number;
    min_popularity?: number;
  }): Promise<SpotifyRecommendations> => {
    const {data} = await spotifyClient.get('/recommendations', {
      params: {
        ...params,
        seed_tracks: params.seed_tracks?.join(','),
        seed_artists: params.seed_artists?.join(','),
        seed_genres: params.seed_genres?.join(','),
        limit: params.limit ?? 20,
        market: 'from_token',
      },
    });
    return data;
  },

  getAvailableGenreSeeds: async (): Promise<string[]> => {
    const {data} = await spotifyClient.get('/recommendations/available-genre-seeds');
    return data.genres;
  },

  // ── Browse / Featured ─────────────────────────────────
  getFeaturedPlaylists: async (
    limit: number = 20,
  ): Promise<{message: string; playlists: {items: SpotifyPlaylist[]}}> => {
    const {data} = await spotifyClient.get('/browse/featured-playlists', {
      params: {limit},
    });
    return data;
  },

  getCategoryPlaylists: async (
    categoryId: string,
    limit: number = 20,
  ): Promise<SpotifyPlaylist[]> => {
    const {data} = await spotifyClient.get(`/browse/categories/${categoryId}/playlists`, {
      params: {limit},
    });
    return data.playlists.items;
  },

  // ── Metadata helpers ──────────────────────────────────
  getBestImage: (images: SpotifyImage[], preferSize: 'large' | 'medium' | 'small' = 'large'): string => {
    if (!images || images.length === 0) return '';
    const sorted = [...images].sort((a, b) => (b.width ?? 0) - (a.width ?? 0));
    if (preferSize === 'large') return sorted[0]?.url ?? '';
    if (preferSize === 'small') return sorted[sorted.length - 1]?.url ?? '';
    return sorted[Math.floor(sorted.length / 2)]?.url ?? sorted[0]?.url ?? '';
  },

  formatDuration: (ms: number): string => {
    const totalSec = Math.floor(ms / 1000);
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return `${min}:${sec.toString().padStart(2, '0')}`;
  },

  getKeyName: (key: number, mode: 0 | 1): string => {
    const keys = ['C', 'C♯', 'D', 'D♯', 'E', 'F', 'F♯', 'G', 'G♯', 'A', 'A♯', 'B'];
    const modeName = mode === 1 ? 'Major' : 'Minor';
    return key === -1 ? 'Unknown' : `${keys[key]} ${modeName}`;
  },
};

export default SpotifyAPI;
