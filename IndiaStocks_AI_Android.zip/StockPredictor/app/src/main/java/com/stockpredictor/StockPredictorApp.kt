package com.stockpredictor

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.google.firebase.FirebaseApp
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class StockPredictorApp : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        createNotificationChannels()
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Price Alerts Channel
            NotificationChannel(
                CHANNEL_PRICE_ALERTS,
                "Price Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Get notified when stocks hit your target price"
                enableVibration(true)
                notificationManager.createNotificationChannel(this)
            }

            // Market Updates Channel
            NotificationChannel(
                CHANNEL_MARKET_UPDATES,
                "Market Updates",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Daily market opening/closing updates"
                notificationManager.createNotificationChannel(this)
            }

            // AI Signals Channel
            NotificationChannel(
                CHANNEL_AI_SIGNALS,
                "AI Signals",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "AI-powered buy/sell signals"
                enableVibration(true)
                notificationManager.createNotificationChannel(this)
            }

            // Portfolio Channel
            NotificationChannel(
                CHANNEL_PORTFOLIO,
                "Portfolio Updates",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Portfolio performance updates"
                notificationManager.createNotificationChannel(this)
            }
        }
    }

    companion object {
        const val CHANNEL_PRICE_ALERTS = "price_alerts"
        const val CHANNEL_MARKET_UPDATES = "market_updates"
        const val CHANNEL_AI_SIGNALS = "ai_signals"
        const val CHANNEL_PORTFOLIO = "portfolio"
    }
}
