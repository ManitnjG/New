package com.stockpredictor.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// ===========================
// STOCK QUOTE MODEL
// ===========================
@Parcelize
@Entity(tableName = "stocks")
data class Stock(
    @PrimaryKey val symbol: String,
    val companyName: String,
    val exchange: String, // NSE or BSE
    val sector: String,
    val industry: String,
    val currentPrice: Double,
    val previousClose: Double,
    val change: Double,
    val changePercent: Double,
    val open: Double,
    val high: Double,
    val low: Double,
    val volume: Long,
    val avgVolume: Long,
    val marketCap: Long,
    val pe: Double,
    val eps: Double,
    val week52High: Double,
    val week52Low: Double,
    val dividendYield: Double,
    val beta: Double,
    val isInWatchlist: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
) : Parcelable {
    val isGaining: Boolean get() = change >= 0
    val changeColor: String get() = if (isGaining) "#00C853" else "#FF1744"
}

// ===========================
// CANDLE / OHLCV DATA
// ===========================
data class CandleData(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Long
) {
    val isGreen: Boolean get() = close >= open
    val bodySize: Double get() = Math.abs(close - open)
    val upperWick: Double get() = high - maxOf(open, close)
    val lowerWick: Double get() = minOf(open, close) - low
}

// ===========================
// AI PREDICTION MODEL
// ===========================
data class StockPrediction(
    val symbol: String,
    val currentPrice: Double,
    val predictedPrice1D: Double,
    val predictedPrice1W: Double,
    val predictedPrice1M: Double,
    val predictedPrice3M: Double,
    val confidence: Double, // 0-100
    val signal: PredictionSignal,
    val supportLevel: Double,
    val resistanceLevel: Double,
    val rsi: Double,
    val macd: Double,
    val macdSignal: Double,
    val bollingerUpper: Double,
    val bollingerLower: Double,
    val bollingerMid: Double,
    val sentiment: MarketSentiment,
    val aiAnalysis: String,
    val keyFactors: List<String>,
    val riskLevel: RiskLevel,
    val targetPrice: Double,
    val stopLoss: Double,
    val timestamp: Long = System.currentTimeMillis()
)

enum class PredictionSignal {
    STRONG_BUY, BUY, HOLD, SELL, STRONG_SELL
}

enum class MarketSentiment {
    VERY_BULLISH, BULLISH, NEUTRAL, BEARISH, VERY_BEARISH
}

enum class RiskLevel {
    VERY_LOW, LOW, MEDIUM, HIGH, VERY_HIGH
}

// ===========================
// PORTFOLIO MODEL
// ===========================
@Entity(tableName = "portfolio")
data class PortfolioHolding(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbol: String,
    val companyName: String,
    val exchange: String,
    val quantity: Double,
    val avgBuyPrice: Double,
    val currentPrice: Double = 0.0,
    val totalInvested: Double = quantity * avgBuyPrice,
    val currentValue: Double = quantity * currentPrice,
    val profitLoss: Double = currentValue - totalInvested,
    val profitLossPercent: Double = if (totalInvested > 0) (profitLoss / totalInvested) * 100 else 0.0,
    val purchaseDate: Long = System.currentTimeMillis(),
    val notes: String = "",
    val sector: String = ""
)

data class PortfolioSummary(
    val totalInvested: Double,
    val currentValue: Double,
    val totalProfitLoss: Double,
    val totalProfitLossPercent: Double,
    val dayGain: Double,
    val dayGainPercent: Double,
    val holdings: List<PortfolioHolding>,
    val sectorAllocation: Map<String, Double>,
    val topGainer: PortfolioHolding?,
    val topLoser: PortfolioHolding?
)

// ===========================
// PRICE ALERT MODEL
// ===========================
@Entity(tableName = "price_alerts")
data class PriceAlert(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbol: String,
    val companyName: String,
    val targetPrice: Double,
    val alertType: AlertType,
    val isActive: Boolean = true,
    val isTriggered: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val triggeredAt: Long? = null,
    val notes: String = ""
)

enum class AlertType {
    ABOVE, BELOW, PERCENT_CHANGE
}

// ===========================
// MARKET INDEX MODEL
// ===========================
data class MarketIndex(
    val name: String,
    val value: Double,
    val change: Double,
    val changePercent: Double,
    val open: Double,
    val high: Double,
    val low: Double,
    val previousClose: Double,
    val timestamp: Long = System.currentTimeMillis()
) {
    val isGaining: Boolean get() = change >= 0
}

// ===========================
// NEWS MODEL
// ===========================
data class StockNews(
    val id: String,
    val title: String,
    val summary: String,
    val source: String,
    val url: String,
    val imageUrl: String?,
    val publishedAt: Long,
    val sentiment: NewsSentiment,
    val relatedSymbols: List<String>,
    val category: String
)

enum class NewsSentiment {
    POSITIVE, NEUTRAL, NEGATIVE
}

// ===========================
// IPO MODEL
// ===========================
data class IPO(
    val companyName: String,
    val symbol: String,
    val issuePrice: ClosedFloatingPointRange<Double>,
    val lotSize: Int,
    val totalIssueSize: Long,
    val openDate: Long,
    val closeDate: Long,
    val listingDate: Long,
    val gmpPrice: Double? = null, // Grey Market Premium
    val subscriptionStatus: SubscriptionStatus,
    val category: String,
    val registrar: String,
    val sector: String,
    val minInvestment: Double
)

enum class SubscriptionStatus {
    UPCOMING, OPEN, CLOSED, LISTED
}

// ===========================
// F&O MODEL
// ===========================
data class OptionsChain(
    val symbol: String,
    val expiryDate: Long,
    val underlyingPrice: Double,
    val calls: List<OptionData>,
    val puts: List<OptionData>,
    val maxPainStrike: Double,
    val pcRatio: Double,
    val totalCallOI: Long,
    val totalPutOI: Long
)

data class OptionData(
    val strikePrice: Double,
    val expiry: Long,
    val optionType: String, // CE or PE
    val ltp: Double,
    val change: Double,
    val changePercent: Double,
    val oi: Long,
    val oiChange: Long,
    val volume: Long,
    val iv: Double, // Implied Volatility
    val delta: Double,
    val gamma: Double,
    val theta: Double,
    val vega: Double,
    val bid: Double,
    val ask: Double
)

// ===========================
// SCREENER MODEL
// ===========================
data class ScreenerFilter(
    val minPrice: Double? = null,
    val maxPrice: Double? = null,
    val minMarketCap: Long? = null,
    val maxMarketCap: Long? = null,
    val minPE: Double? = null,
    val maxPE: Double? = null,
    val minChange: Double? = null,
    val maxChange: Double? = null,
    val sector: String? = null,
    val exchange: String? = null,
    val minVolume: Long? = null,
    val signal: PredictionSignal? = null,
    val rsiMin: Double? = null,
    val rsiMax: Double? = null
)

// ===========================
// USER PREFERENCES
// ===========================
data class UserPreferences(
    val isPremium: Boolean = false,
    val theme: AppTheme = AppTheme.DARK,
    val defaultExchange: String = "NSE",
    val currency: String = "INR",
    val notificationsEnabled: Boolean = true,
    val biometricsEnabled: Boolean = false,
    val defaultChartType: ChartType = ChartType.CANDLESTICK,
    val defaultTimeFrame: TimeFrame = TimeFrame.ONE_DAY
)

enum class AppTheme { LIGHT, DARK, AMOLED }
enum class ChartType { CANDLESTICK, LINE, BAR, AREA }
enum class TimeFrame(val label: String, val days: Int) {
    ONE_DAY("1D", 1),
    ONE_WEEK("1W", 7),
    ONE_MONTH("1M", 30),
    THREE_MONTHS("3M", 90),
    SIX_MONTHS("6M", 180),
    ONE_YEAR("1Y", 365),
    THREE_YEARS("3Y", 1095),
    FIVE_YEARS("5Y", 1825),
    ALL("ALL", -1)
}

// ===========================
// API RESPONSE WRAPPERS
// ===========================
sealed class Resource<T> {
    data class Success<T>(val data: T) : Resource<T>()
    data class Error<T>(val message: String, val code: Int? = null) : Resource<T>()
    class Loading<T> : Resource<T>()
}
