package com.stockpredictor.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import com.stockpredictor.data.models.*
import com.stockpredictor.ui.components.*
import com.stockpredictor.ui.navigation.Routes
import com.stockpredictor.ui.theme.StockColors
import com.stockpredictor.viewmodel.StockUiState
import com.stockpredictor.viewmodel.StockViewModel
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: StockViewModel,
    onStockClick: (Stock) -> Unit,
    onNavigate: (String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val topGainers by viewModel.topGainers.collectAsState()
    val topLosers by viewModel.topLosers.collectAsState()
    val watchlist by viewModel.watchlist.collectAsState()

    Scaffold(
        containerColor = StockColors.Background,
        bottomBar = { BottomNavBar(currentRoute = Routes.HOME, onNavigate = onNavigate) },
        topBar = {
            HomeTopBar(
                onSearchClick = { onNavigate(Routes.SEARCH) },
                onNotificationClick = { onNavigate(Routes.ALERTS) },
                onProfileClick = { onNavigate(Routes.SETTINGS) }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            // Market Status Banner
            item {
                MarketStatusBanner(isMarketOpen = isMarketOpen())
            }

            // Portfolio Summary Card
            item {
                PortfolioSummaryCard(
                    totalValue = 385420.50,
                    totalInvested = 340000.0,
                    dayGain = 2150.0,
                    dayGainPct = 0.56,
                    totalGain = 45420.50,
                    totalGainPct = 13.36,
                    onViewPortfolio = { onNavigate(Routes.PORTFOLIO) }
                )
            }

            // Market Indices
            item {
                SectionHeader(title = "Market Indices", onSeeAll = { onNavigate(Routes.INDICES) })
                if (uiState.isLoadingMarket) {
                    LoadingShimmer()
                } else {
                    MarketIndicesRow(indices = uiState.marketIndices)
                }
            }

            // Quick Actions
            item {
                QuickActionsGrid(onNavigate = onNavigate)
            }

            // AI Signals Banner
            item {
                AISignalsBanner(onNavigate = onNavigate)
            }

            // Top Gainers
            item {
                SectionHeader(title = "🚀 Top Gainers", onSeeAll = { onNavigate(Routes.MARKET) })
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(topGainers.take(8)) { stock ->
                        CompactStockCard(stock = stock, onClick = { onStockClick(stock) })
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            // Top Losers
            item {
                SectionHeader(title = "📉 Top Losers", onSeeAll = { onNavigate(Routes.MARKET) })
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(topLosers.take(8)) { stock ->
                        CompactStockCard(stock = stock, onClick = { onStockClick(stock) })
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            // Watchlist Preview
            if (watchlist.isNotEmpty()) {
                item {
                    SectionHeader(title = "⭐ My Watchlist", onSeeAll = { onNavigate(Routes.WATCHLIST) })
                }
                items(watchlist.take(5)) { stock ->
                    StockListItem(stock = stock, onClick = { onStockClick(stock) })
                }
            }

            // Sector Heatmap Button
            item {
                HeatmapPromoCard(onNavigate = onNavigate)
            }

            // IPO Spotlight
            item {
                IPOSpotlightCard(onNavigate = onNavigate)
            }

            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

// ===========================
// TOP BAR
// ===========================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeTopBar(
    onSearchClick: () -> Unit,
    onNotificationClick: () -> Unit,
    onProfileClick: () -> Unit
) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = StockColors.Background
        ),
        title = {
            Column {
                Text(
                    text = "IndiaStocks AI",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = StockColors.Primary
                )
                Text(
                    text = "NSE • BSE • F&O",
                    style = MaterialTheme.typography.labelSmall,
                    color = StockColors.TextSecondary
                )
            }
        },
        actions = {
            IconButton(onClick = onSearchClick) {
                Icon(Icons.Default.Search, "Search", tint = StockColors.TextPrimary)
            }
            IconButton(onClick = onNotificationClick) {
                BadgedBox(badge = { Badge { Text("3") } }) {
                    Icon(Icons.Default.Notifications, "Alerts", tint = StockColors.TextPrimary)
                }
            }
            IconButton(onClick = onProfileClick) {
                Icon(Icons.Default.AccountCircle, "Profile", tint = StockColors.TextPrimary)
            }
        }
    )
}

// ===========================
// MARKET STATUS BANNER
// ===========================
@Composable
fun MarketStatusBanner(isMarketOpen: Boolean) {
    val color = if (isMarketOpen) StockColors.Gain else StockColors.Loss
    val text = if (isMarketOpen) "🟢 Market OPEN • NSE & BSE" else "🔴 Market CLOSED"

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.1f))
            .padding(vertical = 6.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}

// ===========================
// PORTFOLIO SUMMARY CARD
// ===========================
@Composable
fun PortfolioSummaryCard(
    totalValue: Double,
    totalInvested: Double,
    dayGain: Double,
    dayGainPct: Double,
    totalGain: Double,
    totalGainPct: Double,
    onViewPortfolio: () -> Unit
) {
    val isPositive = totalGain >= 0
    val gainColor = if (isPositive) StockColors.Gain else StockColors.Loss

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clickable { onViewPortfolio() },
        colors = CardDefaults.cardColors(containerColor = StockColors.Card),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            StockColors.Primary.copy(alpha = 0.15f),
                            StockColors.Background.copy(alpha = 0.0f)
                        )
                    )
                )
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Portfolio Value", style = MaterialTheme.typography.bodyMedium, color = StockColors.TextSecondary)
                    Text(
                        text = if (dayGain >= 0) "+₹${formatNumber(dayGain)} (${dayGainPct}%) today"
                        else "-₹${formatNumber(-dayGain)} (${-dayGainPct}%) today",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (dayGain >= 0) StockColors.Gain else StockColors.Loss
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "₹${formatNumber(totalValue)}",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = StockColors.TextPrimary
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    MiniStat("Invested", "₹${formatNumber(totalInvested)}", StockColors.TextSecondary)
                    MiniStat(
                        "Total P&L",
                        "${if (isPositive) "+" else ""}₹${formatNumber(totalGain)} (${totalGainPct}%)",
                        gainColor
                    )
                }
            }
        }
    }
}

@Composable
fun MiniStat(label: String, value: String, color: Color) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = StockColors.TextMuted)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = color, fontWeight = FontWeight.SemiBold)
    }
}

// ===========================
// MARKET INDICES ROW
// ===========================
@Composable
fun MarketIndicesRow(indices: List<MarketIndex>) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(indices) { index ->
            IndexCard(index = index)
        }
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
fun IndexCard(index: MarketIndex) {
    val isGaining = index.isGaining
    val color = if (isGaining) StockColors.Gain else StockColors.Loss

    Card(
        modifier = Modifier.width(140.dp),
        colors = CardDefaults.cardColors(containerColor = StockColors.SurfaceVariant),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = index.name,
                style = MaterialTheme.typography.labelSmall,
                color = StockColors.TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = formatNumber(index.value),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = StockColors.TextPrimary
            )
            Text(
                text = "${if (isGaining) "+" else ""}${String.format("%.2f", index.changePercent)}%",
                style = MaterialTheme.typography.labelMedium,
                color = color,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

// ===========================
// QUICK ACTIONS GRID
// ===========================
@Composable
fun QuickActionsGrid(onNavigate: (String) -> Unit) {
    val actions = listOf(
        Triple(Icons.Default.Analytics, "AI Signals", Routes.AI_SIGNALS),
        Triple(Icons.Default.ShowChart, "Screener", Routes.SCREENER),
        Triple(Icons.Default.Receipt, "IPO", Routes.IPO),
        Triple(Icons.Default.Timeline, "F&O", Routes.OPTIONS),
        Triple(Icons.Default.Newspaper, "News", Routes.NEWS),
        Triple(Icons.Default.GridView, "Heatmap", Routes.HEATMAP)
    )

    Column(modifier = Modifier.padding(16.dp)) {
        Text(
            "Quick Access",
            style = MaterialTheme.typography.titleSmall,
            color = StockColors.TextSecondary,
            modifier = Modifier.padding(bottom = 12.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            actions.take(3).forEach { (icon, label, route) ->
                QuickActionItem(icon, label, route, onNavigate, Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            actions.drop(3).forEach { (icon, label, route) ->
                QuickActionItem(icon, label, route, onNavigate, Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun QuickActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    route: String,
    onNavigate: (String) -> Unit,
    modifier: Modifier
) {
    Card(
        modifier = modifier.clickable { onNavigate(route) },
        colors = CardDefaults.cardColors(containerColor = StockColors.SurfaceVariant),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, label, tint = StockColors.Primary, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = StockColors.TextSecondary)
        }
    }
}

// ===========================
// AI SIGNALS BANNER
// ===========================
@Composable
fun AISignalsBanner(onNavigate: (String) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clickable { onNavigate(Routes.AI_SIGNALS) },
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFF1A0533), Color(0xFF0D2B52))
                    )
                )
                .border(
                    1.dp,
                    Brush.linearGradient(
                        colors = listOf(StockColors.Primary.copy(0.5f), Color(0xFF0066FF).copy(0.5f))
                    ),
                    RoundedCornerShape(16.dp)
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "🤖 AI Stock Signals",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = StockColors.TextPrimary
                    )
                    Text(
                        "12 Strong Buy • 8 Buy • 5 Sell signals today",
                        style = MaterialTheme.typography.bodySmall,
                        color = StockColors.TextSecondary
                    )
                }
                Button(
                    onClick = { onNavigate(Routes.AI_SIGNALS) },
                    colors = ButtonDefaults.buttonColors(containerColor = StockColors.Primary),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("View", style = MaterialTheme.typography.labelMedium, color = Color.Black)
                }
            }
        }
    }
    Spacer(Modifier.height(16.dp))
}

// ===========================
// COMPACT STOCK CARD
// ===========================
@Composable
fun CompactStockCard(stock: Stock, onClick: () -> Unit) {
    val isGaining = stock.isGaining
    val color = if (isGaining) StockColors.Gain else StockColors.Loss

    Card(
        modifier = Modifier
            .width(130.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = StockColors.SurfaceVariant),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    stock.symbol,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = StockColors.TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    if (isGaining) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                    null, tint = color, modifier = Modifier.size(16.dp)
                )
            }
            Spacer(Modifier.height(2.dp))
            Text(
                stock.companyName,
                style = MaterialTheme.typography.bodySmall,
                color = StockColors.TextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "₹${formatNumber(stock.currentPrice)}",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = StockColors.TextPrimary
            )
            Text(
                "${if (isGaining) "+" else ""}${String.format("%.2f", stock.changePercent)}%",
                style = MaterialTheme.typography.labelMedium,
                color = color,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

// ===========================
// STOCK LIST ITEM
// ===========================
@Composable
fun StockListItem(stock: Stock, onClick: () -> Unit) {
    val isGaining = stock.isGaining
    val color = if (isGaining) StockColors.Gain else StockColors.Loss

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(StockColors.Primary.copy(0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    stock.symbol.take(2),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = StockColors.Primary
                )
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(stock.symbol, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
                Text(stock.companyName, style = MaterialTheme.typography.bodySmall, color = StockColors.TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("₹${formatNumber(stock.currentPrice)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
            Text(
                "${if (isGaining) "+" else ""}${String.format("%.2f", stock.changePercent)}%",
                style = MaterialTheme.typography.bodySmall,
                color = color,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
    HorizontalDivider(color = StockColors.SurfaceVariant, thickness = 0.5.dp)
}

// ===========================
// OTHER PROMO CARDS
// ===========================
@Composable
fun HeatmapPromoCard(onNavigate: (String) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clickable { onNavigate(Routes.HEATMAP) },
        colors = CardDefaults.cardColors(containerColor = StockColors.SurfaceVariant),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("📊 Market Heatmap", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
                Text("Visualize sector performance at a glance", style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary)
            }
            Icon(Icons.Default.ChevronRight, null, tint = StockColors.Primary)
        }
    }
}

@Composable
fun IPOSpotlightCard(onNavigate: (String) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clickable { onNavigate(Routes.IPO) },
        colors = CardDefaults.cardColors(containerColor = StockColors.SurfaceVariant),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("🚀 IPO Spotlight", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
                Text("2 upcoming IPOs this week • Check GMP", style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary)
            }
            Icon(Icons.Default.ChevronRight, null, tint = StockColors.Primary)
        }
    }
}

@Composable
fun SectionHeader(title: String, onSeeAll: (() -> Unit)? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
        if (onSeeAll != null) {
            TextButton(onClick = onSeeAll, contentPadding = PaddingValues(4.dp)) {
                Text("See All", style = MaterialTheme.typography.labelMedium, color = StockColors.Primary)
            }
        }
    }
}

@Composable
fun LoadingShimmer() {
    Row(
        modifier = Modifier.padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        repeat(3) {
            Box(
                modifier = Modifier
                    .width(140.dp)
                    .height(80.dp)
                    .background(StockColors.SurfaceVariant, RoundedCornerShape(12.dp))
            )
        }
    }
    Spacer(Modifier.height(8.dp))
}

fun formatNumber(value: Double): String {
    return when {
        value >= 1_00_00_000 -> "₹${String.format("%.2f", value / 1_00_00_000)}Cr"
        value >= 1_00_000 -> "₹${String.format("%.2f", value / 1_00_000)}L"
        else -> NumberFormat.getNumberInstance(Locale("en", "IN")).format(value.toLong())
    }
}

fun isMarketOpen(): Boolean {
    val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Kolkata"))
    val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
    val minute = cal.get(java.util.Calendar.MINUTE)
    val dayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK)
    val isWeekday = dayOfWeek in java.util.Calendar.MONDAY..java.util.Calendar.FRIDAY
    val afterOpen = hour > 9 || (hour == 9 && minute >= 15)
    val beforeClose = hour < 15 || (hour == 15 && minute <= 30)
    return isWeekday && afterOpen && beforeClose
}
