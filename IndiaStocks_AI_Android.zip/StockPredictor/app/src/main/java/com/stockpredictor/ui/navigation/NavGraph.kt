package com.stockpredictor.ui.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.stockpredictor.ui.screens.*
import com.stockpredictor.viewmodel.StockViewModel

object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val MARKET = "market"
    const val STOCK_DETAIL = "stock_detail/{symbol}"
    const val PORTFOLIO = "portfolio"
    const val WATCHLIST = "watchlist"
    const val SCREENER = "screener"
    const val NEWS = "news"
    const val IPO = "ipo"
    const val OPTIONS = "options"
    const val ALERTS = "alerts"
    const val SETTINGS = "settings"
    const val SEARCH = "search"
    const val PREMIUM = "premium"
    const val CHART_FULL = "chart_full/{symbol}"
    const val AI_SIGNALS = "ai_signals"
    const val MUTUAL_FUNDS = "mutual_funds"
    const val INDICES = "indices"
    const val HEATMAP = "heatmap"
    const val COMPARE = "compare"

    fun stockDetail(symbol: String) = "stock_detail/$symbol"
    fun chartFull(symbol: String) = "chart_full/$symbol"
}

@Composable
fun StockNavGraph(
    viewModel: StockViewModel,
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = Routes.HOME,
        enterTransition = {
            slideInHorizontally(
                initialOffsetX = { it },
                animationSpec = tween(300)
            ) + fadeIn(animationSpec = tween(300))
        },
        exitTransition = {
            slideOutHorizontally(
                targetOffsetX = { -it / 3 },
                animationSpec = tween(300)
            ) + fadeOut(animationSpec = tween(300))
        },
        popEnterTransition = {
            slideInHorizontally(
                initialOffsetX = { -it / 3 },
                animationSpec = tween(300)
            ) + fadeIn(animationSpec = tween(300))
        },
        popExitTransition = {
            slideOutHorizontally(
                targetOffsetX = { it },
                animationSpec = tween(300)
            ) + fadeOut(animationSpec = tween(300))
        }
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                viewModel = viewModel,
                onStockClick = { stock ->
                    viewModel.selectStock(stock)
                    navController.navigate(Routes.stockDetail(stock.symbol))
                },
                onNavigate = { route -> navController.navigate(route) }
            )
        }

        composable(Routes.MARKET) {
            MarketScreen(
                viewModel = viewModel,
                onStockClick = { stock ->
                    viewModel.selectStock(stock)
                    navController.navigate(Routes.stockDetail(stock.symbol))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.STOCK_DETAIL) { backStackEntry ->
            val symbol = backStackEntry.arguments?.getString("symbol") ?: ""
            StockDetailScreen(
                symbol = symbol,
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onFullChart = { navController.navigate(Routes.chartFull(symbol)) },
                onNavigate = { route -> navController.navigate(route) }
            )
        }

        composable(Routes.CHART_FULL) { backStackEntry ->
            val symbol = backStackEntry.arguments?.getString("symbol") ?: ""
            FullScreenChartScreen(
                symbol = symbol,
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.PORTFOLIO) {
            PortfolioScreen(
                viewModel = viewModel,
                onStockClick = { stock ->
                    viewModel.selectStock(stock)
                    navController.navigate(Routes.stockDetail(stock.symbol))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.WATCHLIST) {
            WatchlistScreen(
                viewModel = viewModel,
                onStockClick = { stock ->
                    viewModel.selectStock(stock)
                    navController.navigate(Routes.stockDetail(stock.symbol))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SCREENER) {
            ScreenerScreen(
                viewModel = viewModel,
                onStockClick = { stock ->
                    viewModel.selectStock(stock)
                    navController.navigate(Routes.stockDetail(stock.symbol))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.NEWS) {
            NewsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.IPO) {
            IPOScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.OPTIONS) {
            OptionsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.ALERTS) {
            AlertsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onNavigate = { route -> navController.navigate(route) }
            )
        }

        composable(Routes.SEARCH) {
            SearchScreen(
                viewModel = viewModel,
                onStockClick = { stock ->
                    viewModel.selectStock(stock)
                    navController.navigate(Routes.stockDetail(stock.symbol))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.AI_SIGNALS) {
            AISignalsScreen(
                viewModel = viewModel,
                onStockClick = { stock ->
                    viewModel.selectStock(stock)
                    navController.navigate(Routes.stockDetail(stock.symbol))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.INDICES) {
            IndicesScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.HEATMAP) {
            HeatmapScreen(
                viewModel = viewModel,
                onStockClick = { stock ->
                    viewModel.selectStock(stock)
                    navController.navigate(Routes.stockDetail(stock.symbol))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.PREMIUM) {
            PremiumScreen(
                onBack = { navController.popBackStack() }
            )
        }
    }
}
