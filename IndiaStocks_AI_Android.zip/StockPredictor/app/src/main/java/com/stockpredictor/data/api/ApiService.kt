package com.stockpredictor.data.api

import com.google.gson.JsonObject
import com.stockpredictor.data.models.*
import retrofit2.Response
import retrofit2.http.*

// ===========================
// NSE API
// ===========================
interface NseApiService {

    @GET("quote-equity")
    suspend fun getStockQuote(
        @Query("symbol") symbol: String,
        @Query("identifier") identifier: String = "EQUITY"
    ): Response<JsonObject>

    @GET("chart-databyindex")
    suspend fun getHistoricalData(
        @Query("index") symbol: String,
        @Query("indices") indices: Boolean = false
    ): Response<JsonObject>

    @GET("equity-stockIndices")
    suspend fun getIndexData(
        @Query("index") index: String
    ): Response<JsonObject>

    @GET("option-chain-equities")
    suspend fun getOptionsChain(
        @Query("symbol") symbol: String
    ): Response<JsonObject>

    @GET("live-analysis-data")
    suspend fun getLiveAnalysis(): Response<JsonObject>

    @GET("market-status")
    suspend fun getMarketStatus(): Response<JsonObject>

    @GET("ipo-current-allot")
    suspend fun getIPOData(): Response<JsonObject>

    @GET("search/autocomplete")
    suspend fun searchStocks(
        @Query("q") query: String
    ): Response<JsonObject>
}

// ===========================
// ALPHA VANTAGE API (for extra data)
// ===========================
interface AlphaVantageApiService {

    @GET("query")
    suspend fun getTimeSeriesDaily(
        @Query("function") function: String = "TIME_SERIES_DAILY",
        @Query("symbol") symbol: String,
        @Query("outputsize") outputsize: String = "compact",
        @Query("apikey") apiKey: String
    ): Response<JsonObject>

    @GET("query")
    suspend fun getIntraday(
        @Query("function") function: String = "TIME_SERIES_INTRADAY",
        @Query("symbol") symbol: String,
        @Query("interval") interval: String = "5min",
        @Query("apikey") apiKey: String
    ): Response<JsonObject>

    @GET("query")
    suspend fun getRSI(
        @Query("function") function: String = "RSI",
        @Query("symbol") symbol: String,
        @Query("interval") interval: String = "daily",
        @Query("time_period") timePeriod: Int = 14,
        @Query("series_type") seriesType: String = "close",
        @Query("apikey") apiKey: String
    ): Response<JsonObject>

    @GET("query")
    suspend fun getMACD(
        @Query("function") function: String = "MACD",
        @Query("symbol") symbol: String,
        @Query("interval") interval: String = "daily",
        @Query("series_type") seriesType: String = "close",
        @Query("apikey") apiKey: String
    ): Response<JsonObject>

    @GET("query")
    suspend fun getBollingerBands(
        @Query("function") function: String = "BBANDS",
        @Query("symbol") symbol: String,
        @Query("interval") interval: String = "daily",
        @Query("time_period") timePeriod: Int = 20,
        @Query("series_type") seriesType: String = "close",
        @Query("apikey") apiKey: String
    ): Response<JsonObject>

    @GET("query")
    suspend fun getNewsAndSentiment(
        @Query("function") function: String = "NEWS_SENTIMENT",
        @Query("tickers") tickers: String,
        @Query("limit") limit: Int = 50,
        @Query("apikey") apiKey: String
    ): Response<JsonObject>

    @GET("query")
    suspend fun getFundamentals(
        @Query("function") function: String = "OVERVIEW",
        @Query("symbol") symbol: String,
        @Query("apikey") apiKey: String
    ): Response<JsonObject>
}

// ===========================
// SCREENER.IN API
// ===========================
interface ScreenerApiService {

    @GET("api/company/{symbol}/")
    suspend fun getCompanyDetails(
        @Path("symbol") symbol: String
    ): Response<JsonObject>
}
