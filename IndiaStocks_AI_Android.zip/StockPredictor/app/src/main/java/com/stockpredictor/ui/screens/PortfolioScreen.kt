package com.stockpredictor.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.stockpredictor.data.models.*
import com.stockpredictor.ui.theme.StockColors
import com.stockpredictor.viewmodel.StockViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PortfolioScreen(viewModel: StockViewModel, onStockClick: (Stock) -> Unit, onBack: () -> Unit) {
    val holdings by viewModel.portfolioHoldings.collectAsState()
    val summary = viewModel.getPortfolioSummary(holdings)
    val isPositive = summary.totalProfitLoss >= 0
    val plColor = if (isPositive) StockColors.Gain else StockColors.Loss

    Scaffold(
        containerColor = StockColors.Background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StockColors.Background),
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = StockColors.TextPrimary) } },
                title = { Text("My Portfolio", color = StockColors.TextPrimary, fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Summary
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = StockColors.Card),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("Total Value", style = MaterialTheme.typography.bodyMedium, color = StockColors.TextSecondary)
                        Text("₹${String.format("%.2f", summary.currentValue)}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                            Column {
                                Text("Invested", style = MaterialTheme.typography.labelSmall, color = StockColors.TextMuted)
                                Text("₹${String.format("%.0f", summary.totalInvested)}", style = MaterialTheme.typography.bodyMedium, color = StockColors.TextPrimary, fontWeight = FontWeight.SemiBold)
                            }
                            Column {
                                Text("P&L", style = MaterialTheme.typography.labelSmall, color = StockColors.TextMuted)
                                Text("${if(isPositive)"+" else ""}₹${String.format("%.2f", summary.totalProfitLoss)} (${String.format("%.2f", summary.totalProfitLossPercent)}%)", style = MaterialTheme.typography.bodyMedium, color = plColor, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            // Holdings
            item { Text("Holdings (${holdings.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) }

            if (holdings.isEmpty()) {
                item {
                    Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AccountBalance, null, tint = StockColors.TextMuted, modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("No holdings yet", color = StockColors.TextMuted, style = MaterialTheme.typography.bodyMedium)
                            Text("Add stocks from the detail screen", color = StockColors.TextMuted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            items(holdings) { holding ->
                val isPos = holding.profitLoss >= 0
                val c = if (isPos) StockColors.Gain else StockColors.Loss
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { }.padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(40.dp).background(StockColors.Primary.copy(0.15f), androidx.compose.foundation.shape.CircleShape), contentAlignment = Alignment.Center) {
                            Text(holding.symbol.take(2), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = StockColors.Primary)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(holding.symbol, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
                            Text("${holding.quantity.toInt()} shares @ ₹${String.format("%.2f", holding.avgBuyPrice)}", style = MaterialTheme.typography.bodySmall, color = StockColors.TextMuted)
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("₹${String.format("%.2f", holding.currentValue)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
                        Text("${if(isPos)"+" else ""}${String.format("%.2f", holding.profitLossPercent)}%", style = MaterialTheme.typography.bodySmall, color = c, fontWeight = FontWeight.SemiBold)
                    }
                }
                HorizontalDivider(color = StockColors.SurfaceVariant, thickness = 0.5.dp)
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}
