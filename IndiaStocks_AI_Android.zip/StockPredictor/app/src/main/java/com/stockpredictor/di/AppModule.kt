package com.stockpredictor.di

import android.content.Context
import androidx.room.Room
import com.google.gson.GsonBuilder
import com.stockpredictor.data.api.AlphaVantageApiService
import com.stockpredictor.data.api.NseApiService
import com.stockpredictor.data.repository.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        return OkHttpClient.Builder()
            .addInterceptor(logging)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .addHeader("User-Agent", "Mozilla/5.0")
                    .addHeader("Accept", "application/json")
                    .addHeader("Accept-Language", "en-US,en;q=0.9")
                    .build()
                chain.proceed(request)
            }
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    @Named("nse")
    fun provideNseRetrofit(client: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://www.nseindia.com/api/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(GsonBuilder().setLenient().create()))
            .build()
    }

    @Provides
    @Singleton
    @Named("alphavantage")
    fun provideAlphaVantageRetrofit(client: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://www.alphavantage.co/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    @Provides
    @Singleton
    fun provideNseApiService(@Named("nse") retrofit: Retrofit): NseApiService {
        return retrofit.create(NseApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideAlphaVantageApiService(@Named("alphavantage") retrofit: Retrofit): AlphaVantageApiService {
        return retrofit.create(AlphaVantageApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): StockDatabase {
        return Room.databaseBuilder(
            context,
            StockDatabase::class.java,
            "stock_predictor_db"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    fun provideStockDao(db: StockDatabase) = db.stockDao()

    @Provides
    fun providePortfolioDao(db: StockDatabase) = db.portfolioDao()

    @Provides
    fun provideAlertDao(db: StockDatabase) = db.alertDao()
}
