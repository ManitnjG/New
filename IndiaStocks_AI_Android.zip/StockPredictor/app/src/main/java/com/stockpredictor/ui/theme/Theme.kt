package com.stockpredictor.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ===========================
// COLORS
// ===========================
object StockColors {
    // Brand
    val Primary = Color(0xFF00D4AA)
    val PrimaryDark = Color(0xFF00A88A)
    val Secondary = Color(0xFF1E3A5F)
    val Accent = Color(0xFFFFD700)

    // Background (Dark)
    val Background = Color(0xFF0A0E1A)
    val Surface = Color(0xFF111827)
    val SurfaceVariant = Color(0xFF1E2736)
    val Card = Color(0xFF162032)

    // Text
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFFB0BEC5)
    val TextMuted = Color(0xFF607D8B)

    // Market Colors
    val Gain = Color(0xFF00C853)
    val GainLight = Color(0xFF1B5E20)
    val Loss = Color(0xFFFF1744)
    val LossLight = Color(0xFF7F0000)
    val Neutral = Color(0xFF607D8B)

    // Signal Colors
    val StrongBuy = Color(0xFF00C853)
    val Buy = Color(0xFF76FF03)
    val Hold = Color(0xFFFFD740)
    val Sell = Color(0xFFFF6D00)
    val StrongSell = Color(0xFFFF1744)

    // Chart Colors
    val ChartGreen = Color(0xFF00C853)
    val ChartRed = Color(0xFFFF1744)
    val ChartGreenTransparent = Color(0x4000C853)
    val ChartRedTransparent = Color(0x40FF1744)
    val GridLine = Color(0x201E3A5F)
    val CrosshairLine = Color(0x80B0BEC5)

    // Indicator Colors
    val RSI = Color(0xFFFF9800)
    val MACD = Color(0xFF2196F3)
    val MACDSignal = Color(0xFFE91E63)
    val BB = Color(0xFF9C27B0)
    val EMA9 = Color(0xFFFFEB3B)
    val EMA21 = Color(0xFF4CAF50)
    val EMA50 = Color(0xFF00BCD4)

    // Risk Colors
    val RiskVeryLow = Color(0xFF00C853)
    val RiskLow = Color(0xFF76FF03)
    val RiskMedium = Color(0xFFFFD740)
    val RiskHigh = Color(0xFFFF6D00)
    val RiskVeryHigh = Color(0xFFFF1744)

    // Gradients
    val GradientStart = Color(0xFF0A0E1A)
    val GradientEnd = Color(0xFF162032)
    val PrimaryGradientStart = Color(0xFF00D4AA)
    val PrimaryGradientEnd = Color(0xFF0066FF)
}

// ===========================
// TYPOGRAPHY (using system fonts for now)
// ===========================
val StockTypography = Typography(
    displayLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 57.sp,
        letterSpacing = (-0.25).sp
    ),
    displayMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 45.sp
    ),
    headlineLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp
    ),
    headlineMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 28.sp
    ),
    headlineSmall = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        letterSpacing = 0.15.sp
    ),
    titleSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        letterSpacing = 0.1.sp
    ),
    bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        letterSpacing = 0.5.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        letterSpacing = 0.25.sp
    ),
    bodySmall = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        letterSpacing = 0.4.sp
    ),
    labelLarge = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        letterSpacing = 0.1.sp
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        letterSpacing = 0.5.sp
    ),
    labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        letterSpacing = 0.5.sp
    )
)

// ===========================
// DARK COLOR SCHEME
// ===========================
private val DarkColorScheme = darkColorScheme(
    primary = StockColors.Primary,
    onPrimary = Color.Black,
    primaryContainer = StockColors.PrimaryDark,
    secondary = StockColors.Secondary,
    background = StockColors.Background,
    surface = StockColors.Surface,
    surfaceVariant = StockColors.SurfaceVariant,
    onBackground = StockColors.TextPrimary,
    onSurface = StockColors.TextPrimary,
    onSurfaceVariant = StockColors.TextSecondary,
    error = StockColors.Loss,
    tertiary = StockColors.Accent
)

// ===========================
// THEME
// ===========================
@Composable
fun StockPredictorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = StockTypography,
        content = content
    )
}
