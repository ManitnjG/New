package com.stockpredictor.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import com.stockpredictor.data.models.*
import com.stockpredictor.ui.components.CandlestickChart
import com.stockpredictor.ui.components.LineChart
import com.stockpredictor.ui.theme.StockColors
import com.stockpredictor.viewmodel.StockViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockDetailScreen(
    symbol: String,
    viewModel: StockViewModel,
    onBack: () -> Unit,
    onFullChart: () -> Unit,
    onNavigate: (String) -> Unit
) {
    val stock by viewModel.selectedStock.collectAsState()
    val prediction by viewModel.prediction.collectAsState()
    val historicalData by viewModel.historicalData.collectAsState()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val newsItems by viewModel.newsItems.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    var showAddToPortfolioDialog by remember { mutableStateOf(false) }
    var showAlertDialog by remember { mutableStateOf(false) }

    val tabs = listOf("Overview", "AI Predict", "Technicals", "Financials", "News", "Peers")

    Scaffold(
        containerColor = StockColors.Background,
        topBar = {
            stock?.let { s ->
                StockDetailTopBar(
                    stock = s,
                    onBack = onBack,
                    onWatchlistToggle = { viewModel.toggleWatchlist(s.symbol, s.isInWatchlist) },
                    onAddAlert = { showAlertDialog = true },
                    onShare = { }
                )
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            stock?.let { s ->
                // Price Header
                item { StockPriceHeader(stock = s, isLoading = uiState.isLoadingChart) }

                // Chart Controls
                item {
                    ChartTypeSelector(
                        selectedTimeframe = selectedTimeframe,
                        onTimeframeSelected = { viewModel.setTimeframe(it) },
                        onFullChart = onFullChart
                    )
                }

                // Chart
                item {
                    if (uiState.isLoadingChart) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = StockColors.Primary)
                        }
                    } else if (historicalData.isNotEmpty()) {
                        CandlestickChart(
                            candles = historicalData,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .padding(horizontal = 8.dp)
                        )
                    }
                }

                // Action Buttons
                item {
                    StockActionButtons(
                        onBuy = { showAddToPortfolioDialog = true },
                        onSell = { },
                        onSetAlert = { showAlertDialog = true }
                    )
                }

                // Tab Row
                item {
                    ScrollableTabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = StockColors.Background,
                        contentColor = StockColors.Primary,
                        edgePadding = 0.dp,
                        divider = { HorizontalDivider(color = StockColors.SurfaceVariant) }
                    ) {
                        tabs.forEachIndexed { idx, title ->
                            Tab(
                                selected = selectedTab == idx,
                                onClick = { selectedTab = idx },
                                text = {
                                    Text(
                                        title,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (selectedTab == idx) StockColors.Primary else StockColors.TextSecondary
                                    )
                                }
                            )
                        }
                    }
                }

                // Tab Content
                when (selectedTab) {
                    0 -> {
                        item { StockOverviewTab(stock = s) }
                    }
                    1 -> {
                        item {
                            prediction?.let { pred ->
                                AIPredictionTab(prediction = pred, isLoading = uiState.isLoadingPrediction)
                            } ?: item {
                                if (uiState.isLoadingPrediction) {
                                    Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator(color = StockColors.Primary)
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        item {
                            prediction?.let { pred ->
                                TechnicalIndicatorsTab(prediction = pred)
                            }
                        }
                    }
                    3 -> {
                        item { FinancialsTab(stock = s) }
                    }
                    4 -> {
                        items(newsItems) { news ->
                            NewsItem(news = news)
                        }
                    }
                    5 -> {
                        item { PeersTab(sector = s.sector) }
                    }
                }

                item { Spacer(Modifier.height(32.dp)) }
            }
        }
    }

    // Dialogs
    if (showAddToPortfolioDialog) {
        stock?.let { s ->
            AddToPortfolioDialog(
                stock = s,
                onDismiss = { showAddToPortfolioDialog = false },
                onAdd = { qty, price ->
                    viewModel.addToPortfolio(s.symbol, s.companyName, qty, price, s.exchange, s.sector)
                    showAddToPortfolioDialog = false
                }
            )
        }
    }

    if (showAlertDialog) {
        stock?.let { s ->
            SetPriceAlertDialog(
                stock = s,
                onDismiss = { showAlertDialog = false },
                onSetAlert = { price, type ->
                    viewModel.addPriceAlert(s.symbol, s.companyName, price, type)
                    showAlertDialog = false
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockDetailTopBar(
    stock: Stock,
    onBack: () -> Unit,
    onWatchlistToggle: () -> Unit,
    onAddAlert: () -> Unit,
    onShare: () -> Unit
) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(containerColor = StockColors.Background),
        navigationIcon = {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Back", tint = StockColors.TextPrimary)
            }
        },
        title = {
            Column {
                Text(stock.symbol, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
                Text("${stock.exchange} • ${stock.sector}", style = MaterialTheme.typography.labelSmall, color = StockColors.TextSecondary)
            }
        },
        actions = {
            IconButton(onClick = onWatchlistToggle) {
                Icon(
                    if (stock.isInWatchlist) Icons.Default.Star else Icons.Default.StarOutline,
                    "Watchlist",
                    tint = if (stock.isInWatchlist) StockColors.Accent else StockColors.TextSecondary
                )
            }
            IconButton(onClick = onAddAlert) {
                Icon(Icons.Default.NotificationsActive, "Alert", tint = StockColors.TextPrimary)
            }
        }
    )
}

@Composable
fun StockPriceHeader(stock: Stock, isLoading: Boolean) {
    val isGaining = stock.isGaining
    val color = if (isGaining) StockColors.Gain else StockColors.Loss

    Column(modifier = Modifier.padding(16.dp)) {
        Text(stock.companyName, style = MaterialTheme.typography.bodyMedium, color = StockColors.TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                "₹${String.format("%.2f", stock.currentPrice)}",
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Bold,
                color = StockColors.TextPrimary
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    "${if (isGaining) "+" else ""}${String.format("%.2f", stock.change)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = color,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    "(${if (isGaining) "+" else ""}${String.format("%.2f", stock.changePercent)}%)",
                    style = MaterialTheme.typography.bodySmall,
                    color = color
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            PriceInfoChip("H: ₹${String.format("%.0f", stock.high)}", StockColors.Gain)
            PriceInfoChip("L: ₹${String.format("%.0f", stock.low)}", StockColors.Loss)
            PriceInfoChip("O: ₹${String.format("%.0f", stock.open)}", StockColors.TextSecondary)
            PriceInfoChip("PC: ₹${String.format("%.0f", stock.previousClose)}", StockColors.TextSecondary)
        }
    }
}

@Composable
fun PriceInfoChip(text: String, color: Color) {
    Text(text, style = MaterialTheme.typography.labelSmall, color = color, fontWeight = FontWeight.Medium)
}

@Composable
fun ChartTypeSelector(
    selectedTimeframe: TimeFrame,
    onTimeframeSelected: (TimeFrame) -> Unit,
    onFullChart: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items(TimeFrame.values()) { tf ->
                val isSelected = tf == selectedTimeframe
                TextButton(
                    onClick = { onTimeframeSelected(tf) },
                    colors = ButtonDefaults.textButtonColors(
                        containerColor = if (isSelected) StockColors.Primary.copy(0.15f) else Color.Transparent,
                        contentColor = if (isSelected) StockColors.Primary else StockColors.TextSecondary
                    ),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(tf.label, style = MaterialTheme.typography.labelSmall, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
        IconButton(onClick = onFullChart, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Fullscreen, "Full Screen", tint = StockColors.TextSecondary, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun StockActionButtons(onBuy: () -> Unit, onSell: () -> Unit, onSetAlert: () -> Unit) {
    Row(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Button(
            onClick = onBuy,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = StockColors.Gain),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("Buy / Add", color = Color.White, fontWeight = FontWeight.Bold)
        }
        OutlinedButton(
            onClick = onSetAlert,
            modifier = Modifier.weight(1f),
            border = BorderStroke(1.dp, StockColors.Primary),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Default.Notifications, null, tint = StockColors.Primary, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("Alert", color = StockColors.Primary, fontWeight = FontWeight.Bold)
        }
    }
}

// ===========================
// OVERVIEW TAB
// ===========================
@Composable
fun StockOverviewTab(stock: Stock) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Key Statistics", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
        Card(
            colors = CardDefaults.cardColors(containerColor = StockColors.SurfaceVariant),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                StatRow("Market Cap", formatMarketCap(stock.marketCap))
                HorizontalDivider(color = StockColors.Background, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 8.dp))
                StatRow("P/E Ratio", String.format("%.2f", stock.pe))
                HorizontalDivider(color = StockColors.Background, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 8.dp))
                StatRow("EPS", "₹${String.format("%.2f", stock.eps)}")
                HorizontalDivider(color = StockColors.Background, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 8.dp))
                StatRow("52W High", "₹${String.format("%.2f", stock.week52High)}")
                HorizontalDivider(color = StockColors.Background, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 8.dp))
                StatRow("52W Low", "₹${String.format("%.2f", stock.week52Low)}")
                HorizontalDivider(color = StockColors.Background, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 8.dp))
                StatRow("Dividend Yield", "${String.format("%.2f", stock.dividendYield)}%")
                HorizontalDivider(color = StockColors.Background, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 8.dp))
                StatRow("Beta", String.format("%.2f", stock.beta))
                HorizontalDivider(color = StockColors.Background, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 8.dp))
                StatRow("Volume", formatVolume(stock.volume))
                HorizontalDivider(color = StockColors.Background, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 8.dp))
                StatRow("Avg Volume", formatVolume(stock.avgVolume))
            }
        }

        // 52W Range Slider
        Text("52-Week Range", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
        Card(
            colors = CardDefaults.cardColors(containerColor = StockColors.SurfaceVariant),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                val progress = ((stock.currentPrice - stock.week52Low) / (stock.week52High - stock.week52Low)).toFloat().coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(8.dp),
                    color = StockColors.Primary,
                    trackColor = StockColors.Background,
                    strokeCap = StrokeCap.Round
                )
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("₹${String.format("%.0f", stock.week52Low)}", style = MaterialTheme.typography.labelSmall, color = StockColors.Loss)
                    Text("₹${String.format("%.0f", stock.currentPrice)}", style = MaterialTheme.typography.labelSmall, color = StockColors.Primary, fontWeight = FontWeight.Bold)
                    Text("₹${String.format("%.0f", stock.week52High)}", style = MaterialTheme.typography.labelSmall, color = StockColors.Gain)
                }
            }
        }
    }
}

// ===========================
// AI PREDICTION TAB
// ===========================
@Composable
fun AIPredictionTab(prediction: StockPrediction, isLoading: Boolean) {
    if (isLoading) {
        Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = StockColors.Primary)
        }
        return
    }

    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Signal Card
        SignalCard(prediction = prediction)

        // Price Targets
        PriceTargetsCard(prediction = prediction)

        // AI Analysis Text
        Card(
            colors = CardDefaults.cardColors(containerColor = StockColors.SurfaceVariant),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("🤖 AI Analysis", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
                Spacer(Modifier.height(8.dp))
                Text(prediction.aiAnalysis, style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary, lineHeight = 20.sp)
            }
        }

        // Key Factors
        Card(
            colors = CardDefaults.cardColors(containerColor = StockColors.SurfaceVariant),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Key Factors", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
                Spacer(Modifier.height(8.dp))
                prediction.keyFactors.forEach { factor ->
                    Row(
                        modifier = Modifier.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text("•", color = StockColors.Primary, modifier = Modifier.padding(end = 8.dp))
                        Text(factor, style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary)
                    }
                }
            }
        }

        // Disclaimer
        Text(
            "⚠️ AI predictions are for educational purposes only. Not financial advice. Past performance ≠ future results.",
            style = MaterialTheme.typography.labelSmall,
            color = StockColors.TextMuted,
            modifier = Modifier.padding(4.dp)
        )
    }
}

@Composable
fun SignalCard(prediction: StockPrediction) {
    val (signalColor, signalText, signalBg) = when (prediction.signal) {
        PredictionSignal.STRONG_BUY -> Triple(StockColors.StrongBuy, "STRONG BUY", StockColors.StrongBuy.copy(0.15f))
        PredictionSignal.BUY -> Triple(StockColors.Buy, "BUY", StockColors.Buy.copy(0.15f))
        PredictionSignal.HOLD -> Triple(StockColors.Hold, "HOLD", StockColors.Hold.copy(0.15f))
        PredictionSignal.SELL -> Triple(StockColors.Sell, "SELL", StockColors.Sell.copy(0.15f))
        PredictionSignal.STRONG_SELL -> Triple(StockColors.StrongSell, "STRONG SELL", StockColors.StrongSell.copy(0.15f))
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = signalBg),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, signalColor.copy(0.3f), RoundedCornerShape(16.dp))
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("AI Signal", style = MaterialTheme.typography.labelSmall, color = signalColor.copy(0.7f))
                Text(signalText, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = signalColor)
                Text(
                    "Confidence: ${String.format("%.0f", prediction.confidence)}%",
                    style = MaterialTheme.typography.bodySmall,
                    color = signalColor.copy(0.7f)
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                val riskColor = when (prediction.riskLevel) {
                    RiskLevel.VERY_LOW -> StockColors.RiskVeryLow
                    RiskLevel.LOW -> StockColors.RiskLow
                    RiskLevel.MEDIUM -> StockColors.RiskMedium
                    RiskLevel.HIGH -> StockColors.RiskHigh
                    RiskLevel.VERY_HIGH -> StockColors.RiskVeryHigh
                }
                Text("Risk", style = MaterialTheme.typography.labelSmall, color = StockColors.TextMuted)
                Text(
                    prediction.riskLevel.name.replace("_", " "),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = riskColor
                )
            }
        }
    }
}

@Composable
fun PriceTargetsCard(prediction: StockPrediction) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StockColors.SurfaceVariant),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Price Targets", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PriceTarget("1D", prediction.predictedPrice1D, prediction.currentPrice, Modifier.weight(1f))
                PriceTarget("1W", prediction.predictedPrice1W, prediction.currentPrice, Modifier.weight(1f))
                PriceTarget("1M", prediction.predictedPrice1M, prediction.currentPrice, Modifier.weight(1f))
                PriceTarget("3M", prediction.predictedPrice3M, prediction.currentPrice, Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = StockColors.Background)
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("🎯 Target", style = MaterialTheme.typography.labelSmall, color = StockColors.TextMuted)
                    Text("₹${String.format("%.2f", prediction.targetPrice)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = StockColors.Gain)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("🛡 Stop Loss", style = MaterialTheme.typography.labelSmall, color = StockColors.TextMuted)
                    Text("₹${String.format("%.2f", prediction.stopLoss)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = StockColors.Loss)
                }
            }
        }
    }
}

@Composable
fun PriceTarget(label: String, target: Double, current: Double, modifier: Modifier) {
    val change = ((target - current) / current) * 100
    val isPositive = change >= 0
    val color = if (isPositive) StockColors.Gain else StockColors.Loss

    Column(
        modifier = modifier
            .background(StockColors.Background, RoundedCornerShape(8.dp))
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = StockColors.TextMuted)
        Spacer(Modifier.height(4.dp))
        Text("₹${String.format("%.0f", target)}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
        Text(
            "${if (isPositive) "+" else ""}${String.format("%.1f", change)}%",
            style = MaterialTheme.typography.labelSmall,
            color = color
        )
    }
}

// ===========================
// TECHNICAL INDICATORS TAB
// ===========================
@Composable
fun TechnicalIndicatorsTab(prediction: StockPrediction) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Technical Indicators", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)

        Card(colors = CardDefaults.cardColors(containerColor = StockColors.SurfaceVariant), shape = RoundedCornerShape(12.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RSIIndicator(rsi = prediction.rsi)
                HorizontalDivider(color = StockColors.Background, thickness = 0.5.dp)
                MACDIndicator(macd = prediction.macd, signal = prediction.macdSignal)
                HorizontalDivider(color = StockColors.Background, thickness = 0.5.dp)
                BollingerIndicator(upper = prediction.bollingerUpper, mid = prediction.bollingerMid, lower = prediction.bollingerLower, current = prediction.currentPrice)
                HorizontalDivider(color = StockColors.Background, thickness = 0.5.dp)
                SupportResistance(support = prediction.supportLevel, resistance = prediction.resistanceLevel, current = prediction.currentPrice)
            }
        }
    }
}

@Composable
fun RSIIndicator(rsi: Double) {
    val rsiColor = when {
        rsi < 30 -> StockColors.Gain
        rsi > 70 -> StockColors.Loss
        else -> StockColors.Hold
    }
    val signal = when {
        rsi < 30 -> "Oversold"
        rsi > 70 -> "Overbought"
        rsi < 45 -> "Bearish"
        rsi > 55 -> "Bullish"
        else -> "Neutral"
    }

    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("RSI (14)", style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(String.format("%.1f", rsi), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = rsiColor)
                Text(signal, style = MaterialTheme.typography.labelSmall, color = rsiColor)
            }
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (rsi / 100).toFloat() },
            modifier = Modifier.fillMaxWidth().height(6.dp),
            color = rsiColor,
            trackColor = StockColors.Background,
            strokeCap = StrokeCap.Round
        )
    }
}

@Composable
fun MACDIndicator(macd: Double, signal: Double) {
    val isBullish = macd > signal
    val color = if (isBullish) StockColors.Gain else StockColors.Loss
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column {
            Text("MACD", style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary)
            Text(String.format("%.4f", macd), style = MaterialTheme.typography.bodySmall, color = StockColors.MACD)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Signal", style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary)
            Text(String.format("%.4f", signal), style = MaterialTheme.typography.bodySmall, color = StockColors.MACDSignal)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("Trend", style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary)
            Text(if (isBullish) "Bullish ↑" else "Bearish ↓", style = MaterialTheme.typography.bodySmall, color = color, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun BollingerIndicator(upper: Double, mid: Double, lower: Double, current: Double) {
    val position = when {
        current > upper -> "Above Upper Band"
        current < lower -> "Below Lower Band"
        current > mid -> "Upper Half"
        else -> "Lower Half"
    }
    Column {
        Text("Bollinger Bands (20,2)", style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary)
        Spacer(Modifier.height(4.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("U: ₹${String.format("%.0f", upper)}", style = MaterialTheme.typography.labelSmall, color = StockColors.BB)
            Text("M: ₹${String.format("%.0f", mid)}", style = MaterialTheme.typography.labelSmall, color = StockColors.TextSecondary)
            Text("L: ₹${String.format("%.0f", lower)}", style = MaterialTheme.typography.labelSmall, color = StockColors.BB)
        }
        Text(position, style = MaterialTheme.typography.labelSmall, color = StockColors.Primary)
    }
}

@Composable
fun SupportResistance(support: Double, resistance: Double, current: Double) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column {
            Text("Support", style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary)
            Text("₹${String.format("%.2f", support)}", style = MaterialTheme.typography.bodySmall, color = StockColors.Gain, fontWeight = FontWeight.Bold)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Current", style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary)
            Text("₹${String.format("%.2f", current)}", style = MaterialTheme.typography.bodySmall, color = StockColors.Primary, fontWeight = FontWeight.Bold)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("Resistance", style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary)
            Text("₹${String.format("%.2f", resistance)}", style = MaterialTheme.typography.bodySmall, color = StockColors.Loss, fontWeight = FontWeight.Bold)
        }
    }
}

// ===========================
// FINANCIALS TAB
// ===========================
@Composable
fun FinancialsTab(stock: Stock) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Fundamental Analysis", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
        Card(colors = CardDefaults.cardColors(containerColor = StockColors.SurfaceVariant), shape = RoundedCornerShape(12.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                StatRow("Market Cap", formatMarketCap(stock.marketCap))
                StatRow("P/E Ratio", String.format("%.2f", stock.pe))
                StatRow("EPS (TTM)", "₹${String.format("%.2f", stock.eps)}")
                StatRow("Dividend Yield", "${String.format("%.2f", stock.dividendYield)}%")
                StatRow("Beta", String.format("%.2f", stock.beta))
            }
        }
    }
}

@Composable
fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = StockColors.TextPrimary)
    }
}

// ===========================
// NEWS TAB ITEM
// ===========================
@Composable
fun NewsItem(news: StockNews) {
    val sentimentColor = when (news.sentiment) {
        NewsSentiment.POSITIVE -> StockColors.Gain
        NewsSentiment.NEGATIVE -> StockColors.Loss
        NewsSentiment.NEUTRAL -> StockColors.TextMuted
    }

    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.Top) {
            Box(
                modifier = Modifier.size(6.dp).background(sentimentColor, CircleShape).offset(y = 6.dp)
            )
            Spacer(Modifier.width(8.dp))
            Column {
                Text(news.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = StockColors.TextPrimary, maxLines = 2)
                Spacer(Modifier.height(4.dp))
                Text(news.summary, style = MaterialTheme.typography.bodySmall, color = StockColors.TextSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(news.source, style = MaterialTheme.typography.labelSmall, color = StockColors.Primary)
                    Text(formatTimeAgo(news.publishedAt), style = MaterialTheme.typography.labelSmall, color = StockColors.TextMuted)
                }
            }
        }
        HorizontalDivider(color = StockColors.SurfaceVariant, thickness = 0.5.dp, modifier = Modifier.padding(top = 8.dp))
    }
}

// ===========================
// PEERS TAB
// ===========================
@Composable
fun PeersTab(sector: String) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("$sector Sector Peers", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StockColors.TextPrimary)
        Spacer(Modifier.height(8.dp))
        Text("Coming soon: Peer comparison with P/E, Revenue growth, ROE metrics", style = MaterialTheme.typography.bodySmall, color = StockColors.TextMuted)
    }
}

// ===========================
// DIALOGS
// ===========================
@Composable
fun AddToPortfolioDialog(stock: Stock, onDismiss: () -> Unit, onAdd: (Double, Double) -> Unit) {
    var qty by remember { mutableStateOf("") }
    var price by remember { mutableStateOf(String.format("%.2f", stock.currentPrice)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StockColors.SurfaceVariant,
        title = { Text("Add to Portfolio", color = StockColors.TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("${stock.symbol} • ₹${String.format("%.2f", stock.currentPrice)}", color = StockColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = qty,
                    onValueChange = { qty = it },
                    label = { Text("Quantity") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StockColors.Primary,
                        unfocusedBorderColor = StockColors.TextMuted,
                        focusedTextColor = StockColors.TextPrimary,
                        unfocusedTextColor = StockColors.TextPrimary
                    )
                )
                OutlinedTextField(
                    value = price,
                    onValueChange = { price = it },
                    label = { Text("Avg Buy Price (₹)") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StockColors.Primary,
                        unfocusedBorderColor = StockColors.TextMuted,
                        focusedTextColor = StockColors.TextPrimary,
                        unfocusedTextColor = StockColors.TextPrimary
                    )
                )
                val investment = (qty.toDoubleOrNull() ?: 0.0) * (price.toDoubleOrNull() ?: 0.0)
                if (investment > 0) {
                    Text("Total Investment: ₹${String.format("%.2f", investment)}", color = StockColors.Primary, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val q = qty.toDoubleOrNull() ?: return@Button
                    val p = price.toDoubleOrNull() ?: return@Button
                    onAdd(q, p)
                },
                colors = ButtonDefaults.buttonColors(containerColor = StockColors.Gain)
            ) { Text("Add", color = Color.White) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = StockColors.TextSecondary) }
        }
    )
}

@Composable
fun SetPriceAlertDialog(stock: Stock, onDismiss: () -> Unit, onSetAlert: (Double, AlertType) -> Unit) {
    var targetPrice by remember { mutableStateOf(String.format("%.2f", stock.currentPrice)) }
    var alertType by remember { mutableStateOf(AlertType.ABOVE) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StockColors.SurfaceVariant,
        title = { Text("Set Price Alert", color = StockColors.TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("${stock.symbol} • Current: ₹${String.format("%.2f", stock.currentPrice)}", color = StockColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AlertType.values().take(2).forEach { type ->
                        FilterChip(
                            selected = alertType == type,
                            onClick = { alertType = type },
                            label = { Text(type.name) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StockColors.Primary.copy(0.2f),
                                selectedLabelColor = StockColors.Primary
                            )
                        )
                    }
                }
                OutlinedTextField(
                    value = targetPrice,
                    onValueChange = { targetPrice = it },
                    label = { Text("Target Price (₹)") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StockColors.Primary,
                        unfocusedBorderColor = StockColors.TextMuted,
                        focusedTextColor = StockColors.TextPrimary,
                        unfocusedTextColor = StockColors.TextPrimary
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val p = targetPrice.toDoubleOrNull() ?: return@Button
                    onSetAlert(p, alertType)
                },
                colors = ButtonDefaults.buttonColors(containerColor = StockColors.Primary)
            ) { Text("Set Alert", color = Color.Black) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = StockColors.TextSecondary) }
        }
    )
}

// ===========================
// HELPERS
// ===========================
fun formatMarketCap(cap: Long): String = when {
    cap >= 1_00_000_00_00_000L -> "₹${String.format("%.2f", cap / 1_00_000_00_00_000.0)}L Cr"
    cap >= 1_00_00_00_000L -> "₹${String.format("%.2f", cap / 1_00_00_00_000.0)}K Cr"
    cap >= 1_00_00_000L -> "₹${String.format("%.2f", cap / 1_00_00_000.0)} Cr"
    else -> "₹${cap}"
}

fun formatVolume(vol: Long): String = when {
    vol >= 1_00_00_000L -> "${String.format("%.2f", vol / 1_00_00_000.0)} Cr"
    vol >= 1_00_000L -> "${String.format("%.2f", vol / 1_00_000.0)} L"
    else -> vol.toString()
}

fun formatTimeAgo(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    return when {
        diff < 3600000 -> "${diff / 60000}m ago"
        diff < 86400000 -> "${diff / 3600000}h ago"
        else -> "${diff / 86400000}d ago"
    }
}
