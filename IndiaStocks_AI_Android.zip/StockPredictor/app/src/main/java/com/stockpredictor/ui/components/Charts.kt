package com.stockpredictor.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import com.stockpredictor.data.models.CandleData
import com.stockpredictor.ui.theme.StockColors
import kotlin.math.*

@Composable
fun CandlestickChart(candles: List<CandleData>, modifier: Modifier = Modifier) {
    if (candles.isEmpty()) return
    val visibleCandles = candles.takeLast(60)
    val maxHigh = visibleCandles.maxOf { it.high }
    val minLow = visibleCandles.minOf { it.low }
    val range = maxHigh - minLow
    val padding = range * 0.05

    Canvas(modifier = modifier.background(StockColors.Background)) {
        val w = size.width
        val h = size.height
        val candleW = (w / visibleCandles.size) * 0.7f
        val spacing = w / visibleCandles.size

        repeat(5) { i ->
            val y = h * i / 4f
            drawLine(StockColors.GridLine, Offset(0f, y), Offset(w, y), strokeWidth = 0.5f)
        }

        visibleCandles.forEachIndexed { idx, candle ->
            val x = spacing * idx + spacing / 2
            val priceToY = { price: Double -> h * (1 - (price - minLow + padding) / (range + padding * 2)) }
            val openY = priceToY(candle.open).toFloat()
            val closeY = priceToY(candle.close).toFloat()
            val highY = priceToY(candle.high).toFloat()
            val lowY = priceToY(candle.low).toFloat()
            val color = if (candle.isGreen) StockColors.ChartGreen else StockColors.ChartRed
            drawLine(color, Offset(x, highY), Offset(x, lowY), strokeWidth = 1f)
            val top = minOf(openY, closeY)
            val bodyH = maxOf(abs(openY - closeY), 1f)
            drawRect(color, Offset(x - candleW / 2, top), Size(candleW, bodyH))
        }
    }
}

@Composable
fun LineChart(data: List<Double>, modifier: Modifier = Modifier, color: Color = StockColors.Primary, fillGradient: Boolean = true) {
    if (data.size < 2) return
    val maxVal = data.max()
    val minVal = data.min()
    val range = maxVal - minVal

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val step = w / (data.size - 1)
        val toY = { v: Double -> (h * (1 - (v - minVal) / range.coerceAtLeast(0.01))).toFloat() }
        val toX = { i: Int -> i * step }
        val path = Path()
        path.moveTo(toX(0), toY(data[0]))
        for (i in 1 until data.size) path.lineTo(toX(i), toY(data[i]))
        drawPath(path, color, style = Stroke(width = 2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        if (fillGradient) {
            val fillPath = Path()
            fillPath.addPath(path)
            fillPath.lineTo(toX(data.size - 1), h)
            fillPath.lineTo(0f, h)
            fillPath.close()
            drawPath(fillPath, Brush.verticalGradient(listOf(color.copy(0.3f), Color.Transparent)))
        }
    }
}
