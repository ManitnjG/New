package com.stockpredictor.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import com.stockpredictor.ui.navigation.Routes
import com.stockpredictor.ui.theme.StockColors

@Composable
fun BottomNavBar(currentRoute: String, onNavigate: (String) -> Unit) {
    val items = listOf(
        Triple(Routes.HOME, Icons.Default.Home, "Home"),
        Triple(Routes.MARKET, Icons.Default.BarChart, "Market"),
        Triple(Routes.PORTFOLIO, Icons.Default.AccountBalance, "Portfolio"),
        Triple(Routes.WATCHLIST, Icons.Default.Star, "Watchlist"),
        Triple(Routes.SETTINGS, Icons.Default.Menu, "More")
    )
    NavigationBar(containerColor = StockColors.Surface) {
        items.forEach { (route, icon, label) ->
            NavigationBarItem(
                selected = currentRoute == route,
                onClick = { onNavigate(route) },
                icon = { Icon(icon, label) },
                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = StockColors.Primary,
                    selectedTextColor = StockColors.Primary,
                    unselectedIconColor = StockColors.TextSecondary,
                    unselectedTextColor = StockColors.TextSecondary,
                    indicatorColor = StockColors.Primary.copy(0.15f)
                )
            )
        }
    }
}
