package com.stockpredictor.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.hilt.navigation.compose.hiltViewModel
import com.stockpredictor.ui.navigation.StockNavGraph
import com.stockpredictor.ui.theme.StockColors
import com.stockpredictor.ui.theme.StockPredictorTheme
import com.stockpredictor.viewmodel.StockViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        setContent {
            StockPredictorTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = StockColors.Background
                ) {
                    val viewModel: StockViewModel = hiltViewModel()
                    StockNavGraph(viewModel = viewModel)
                }
            }
        }
    }
}
