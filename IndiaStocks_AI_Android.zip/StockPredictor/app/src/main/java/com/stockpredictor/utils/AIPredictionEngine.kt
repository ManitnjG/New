package com.stockpredictor.utils

import com.stockpredictor.data.models.*
import kotlin.math.*

/**
 * AI Prediction Engine
 * Combines multiple technical indicators + sentiment analysis + pattern recognition
 * to generate stock predictions and signals
 */
object AIPredictionEngine {

    // ===========================
    // MAIN PREDICTION FUNCTION
    // ===========================
    fun generatePrediction(
        symbol: String,
        candles: List<CandleData>,
        currentPrice: Double,
        newsItems: List<StockNews> = emptyList(),
        fundamentals: StockFundamentals? = null
    ): StockPrediction {
        if (candles.size < 50) {
            return createDefaultPrediction(symbol, currentPrice)
        }

        val closes = candles.map { it.close }
        val highs = candles.map { it.high }
        val lows = candles.map { it.low }
        val volumes = candles.map { it.volume.toDouble() }

        // Calculate all indicators
        val rsi = calculateRSI(closes, 14)
        val (macd, macdSignal, macdHistogram) = calculateMACD(closes)
        val (bbUpper, bbMid, bbLower) = calculateBollingerBands(closes, 20, 2.0)
        val ema9 = calculateEMA(closes, 9)
        val ema21 = calculateEMA(closes, 21)
        val ema50 = calculateEMA(closes, 50)
        val sma200 = calculateSMA(closes, minOf(200, closes.size))
        val atr = calculateATR(highs, lows, closes, 14)
        val obv = calculateOBV(closes, volumes)
        val stochK = calculateStochastic(highs, lows, closes, 14)
        val vwap = calculateVWAP(candles)
        val adx = calculateADX(highs, lows, closes, 14)

        // Pattern Recognition
        val patterns = detectCandlePatterns(candles.takeLast(10))

        // Sentiment from news
        val sentimentScore = calculateNewsSentiment(newsItems)

        // Support & Resistance
        val (support, resistance) = findSupportResistance(highs, lows, closes)

        // Generate Signal
        val signal = generateSignal(
            rsi = rsi,
            macd = macd,
            macdSignal = macdSignal,
            currentPrice = currentPrice,
            ema9 = ema9,
            ema21 = ema21,
            ema50 = ema50,
            sma200 = sma200,
            bbUpper = bbUpper,
            bbLower = bbLower,
            stochK = stochK,
            adx = adx,
            patterns = patterns,
            sentimentScore = sentimentScore,
            obv = obv,
            previousOBV = if (obv.size > 1) obv[obv.size - 2] else obv.last()
        )

        // Price Prediction using Linear Regression + Momentum
        val prediction1D = predictPrice(closes, 1, signal, atr)
        val prediction1W = predictPrice(closes, 7, signal, atr)
        val prediction1M = predictPrice(closes, 30, signal, atr)
        val prediction3M = predictPrice(closes, 90, signal, atr)

        // Confidence Score
        val confidence = calculateConfidence(
            rsi, macd, macdSignal, adx, patterns, sentimentScore
        )

        // Risk Level
        val riskLevel = assessRisk(
            atr = atr.last(),
            beta = calculateBeta(closes),
            adx = adx.last(),
            volatility = calculateVolatility(closes)
        )

        // Target & Stop Loss
        val targetPrice = calculateTarget(currentPrice, signal, resistance, atr.last())
        val stopLoss = calculateStopLoss(currentPrice, signal, support, atr.last())

        // AI Analysis Text
        val aiAnalysis = generateAnalysisText(
            symbol, currentPrice, signal, rsi.last(), macd.last(),
            patterns, sentimentScore, riskLevel, fundamentals
        )

        val keyFactors = generateKeyFactors(
            rsi.last(), macd.last(), macdSignal.last(),
            currentPrice, ema50.last(), sma200,
            patterns, sentimentScore, signal
        )

        val sentiment = when {
            sentimentScore > 0.5 -> MarketSentiment.VERY_BULLISH
            sentimentScore > 0.2 -> MarketSentiment.BULLISH
            sentimentScore < -0.5 -> MarketSentiment.VERY_BEARISH
            sentimentScore < -0.2 -> MarketSentiment.BEARISH
            else -> MarketSentiment.NEUTRAL
        }

        return StockPrediction(
            symbol = symbol,
            currentPrice = currentPrice,
            predictedPrice1D = prediction1D,
            predictedPrice1W = prediction1W,
            predictedPrice1M = prediction1M,
            predictedPrice3M = prediction3M,
            confidence = confidence,
            signal = signal,
            supportLevel = support,
            resistanceLevel = resistance,
            rsi = rsi.last(),
            macd = macd.last(),
            macdSignal = macdSignal.last(),
            bollingerUpper = bbUpper.last(),
            bollingerLower = bbLower.last(),
            bollingerMid = bbMid.last(),
            sentiment = sentiment,
            aiAnalysis = aiAnalysis,
            keyFactors = keyFactors,
            riskLevel = riskLevel,
            targetPrice = targetPrice,
            stopLoss = stopLoss
        )
    }

    // ===========================
    // TECHNICAL INDICATORS
    // ===========================

    fun calculateRSI(prices: List<Double>, period: Int = 14): List<Double> {
        if (prices.size < period + 1) return prices.map { 50.0 }
        val gains = mutableListOf<Double>()
        val losses = mutableListOf<Double>()

        for (i in 1 until prices.size) {
            val change = prices[i] - prices[i - 1]
            gains.add(if (change > 0) change else 0.0)
            losses.add(if (change < 0) -change else 0.0)
        }

        val result = mutableListOf<Double>()
        var avgGain = gains.take(period).average()
        var avgLoss = losses.take(period).average()

        if (avgLoss == 0.0) {
            result.add(100.0)
        } else {
            result.add(100 - (100 / (1 + avgGain / avgLoss)))
        }

        for (i in period until gains.size) {
            avgGain = (avgGain * (period - 1) + gains[i]) / period
            avgLoss = (avgLoss * (period - 1) + losses[i]) / period
            val rsi = if (avgLoss == 0.0) 100.0 else 100 - (100 / (1 + avgGain / avgLoss))
            result.add(rsi)
        }

        return result
    }

    fun calculateMACD(
        prices: List<Double>,
        fast: Int = 12,
        slow: Int = 26,
        signal: Int = 9
    ): Triple<List<Double>, List<Double>, List<Double>> {
        val ema12 = calculateEMAList(prices, fast)
        val ema26 = calculateEMAList(prices, slow)

        val macdLine = mutableListOf<Double>()
        val minSize = minOf(ema12.size, ema26.size)
        for (i in 0 until minSize) {
            macdLine.add(ema12[i] - ema26[i])
        }

        val signalLine = calculateEMAList(macdLine, signal)
        val histogram = mutableListOf<Double>()
        val minSize2 = minOf(macdLine.size, signalLine.size)
        for (i in 0 until minSize2) {
            histogram.add(macdLine[i] - signalLine[i])
        }

        return Triple(macdLine, signalLine, histogram)
    }

    fun calculateBollingerBands(
        prices: List<Double>,
        period: Int = 20,
        multiplier: Double = 2.0
    ): Triple<List<Double>, List<Double>, List<Double>> {
        val upper = mutableListOf<Double>()
        val mid = mutableListOf<Double>()
        val lower = mutableListOf<Double>()

        for (i in period - 1 until prices.size) {
            val slice = prices.subList(i - period + 1, i + 1)
            val sma = slice.average()
            val std = sqrt(slice.map { (it - sma).pow(2) }.average())
            upper.add(sma + multiplier * std)
            mid.add(sma)
            lower.add(sma - multiplier * std)
        }

        return Triple(upper, mid, lower)
    }

    fun calculateEMA(prices: List<Double>, period: Int): List<Double> {
        return calculateEMAList(prices, period)
    }

    private fun calculateEMAList(prices: List<Double>, period: Int): List<Double> {
        if (prices.isEmpty() || period > prices.size) return prices
        val multiplier = 2.0 / (period + 1)
        val result = mutableListOf<Double>()
        var ema = prices.take(period).average()
        result.add(ema)

        for (i in period until prices.size) {
            ema = (prices[i] - ema) * multiplier + ema
            result.add(ema)
        }
        return result
    }

    fun calculateSMA(prices: List<Double>, period: Int): Double {
        if (prices.size < period) return prices.average()
        return prices.takeLast(period).average()
    }

    fun calculateATR(
        highs: List<Double>,
        lows: List<Double>,
        closes: List<Double>,
        period: Int = 14
    ): List<Double> {
        val trueRanges = mutableListOf<Double>()
        for (i in 1 until highs.size) {
            val tr = maxOf(
                highs[i] - lows[i],
                abs(highs[i] - closes[i - 1]),
                abs(lows[i] - closes[i - 1])
            )
            trueRanges.add(tr)
        }

        val result = mutableListOf<Double>()
        var atr = trueRanges.take(period).average()
        result.add(atr)

        for (i in period until trueRanges.size) {
            atr = (atr * (period - 1) + trueRanges[i]) / period
            result.add(atr)
        }
        return result
    }

    fun calculateOBV(closes: List<Double>, volumes: List<Double>): List<Double> {
        val obv = mutableListOf(0.0)
        for (i in 1 until closes.size) {
            val lastObv = obv.last()
            obv.add(
                when {
                    closes[i] > closes[i - 1] -> lastObv + volumes[i]
                    closes[i] < closes[i - 1] -> lastObv - volumes[i]
                    else -> lastObv
                }
            )
        }
        return obv
    }

    fun calculateStochastic(
        highs: List<Double>,
        lows: List<Double>,
        closes: List<Double>,
        period: Int = 14
    ): List<Double> {
        val result = mutableListOf<Double>()
        for (i in period - 1 until closes.size) {
            val highMax = highs.subList(i - period + 1, i + 1).max()
            val lowMin = lows.subList(i - period + 1, i + 1).min()
            val k = if (highMax - lowMin != 0.0) {
                ((closes[i] - lowMin) / (highMax - lowMin)) * 100
            } else 50.0
            result.add(k)
        }
        return result
    }

    fun calculateVWAP(candles: List<CandleData>): Double {
        var cumulativeTPV = 0.0
        var cumulativeVolume = 0.0
        candles.forEach { c ->
            val typicalPrice = (c.high + c.low + c.close) / 3
            cumulativeTPV += typicalPrice * c.volume
            cumulativeVolume += c.volume
        }
        return if (cumulativeVolume > 0) cumulativeTPV / cumulativeVolume else 0.0
    }

    fun calculateADX(
        highs: List<Double>,
        lows: List<Double>,
        closes: List<Double>,
        period: Int = 14
    ): List<Double> {
        // Simplified ADX calculation
        val result = mutableListOf<Double>()
        if (highs.size < period * 2) {
            return List(closes.size) { 25.0 }
        }

        for (i in period until closes.size) {
            var plusDM = 0.0
            var minusDM = 0.0
            var tr = 0.0

            for (j in i - period + 1..i) {
                val upMove = highs[j] - highs[j - 1]
                val downMove = lows[j - 1] - lows[j]
                if (upMove > downMove && upMove > 0) plusDM += upMove
                if (downMove > upMove && downMove > 0) minusDM += downMove
                tr += maxOf(
                    highs[j] - lows[j],
                    abs(highs[j] - closes[j - 1]),
                    abs(lows[j] - closes[j - 1])
                )
            }

            if (tr == 0.0) {
                result.add(25.0)
                continue
            }

            val plusDI = (plusDM / tr) * 100
            val minusDI = (minusDM / tr) * 100
            val dx = if (plusDI + minusDI > 0) {
                (abs(plusDI - minusDI) / (plusDI + minusDI)) * 100
            } else 0.0
            result.add(dx)
        }

        return if (result.isEmpty()) List(closes.size) { 25.0 } else result
    }

    // ===========================
    // PATTERN RECOGNITION
    // ===========================
    fun detectCandlePatterns(candles: List<CandleData>): List<String> {
        val patterns = mutableListOf<String>()
        if (candles.size < 3) return patterns

        val last = candles.last()
        val prev = candles[candles.size - 2]
        val prev2 = candles[candles.size - 3]

        // Doji
        val dojiThreshold = (last.high - last.low) * 0.1
        if (abs(last.close - last.open) <= dojiThreshold) {
            patterns.add("Doji")
        }

        // Hammer
        val lowerWick = minOf(last.open, last.close) - last.low
        val body = abs(last.close - last.open)
        val upperWick = last.high - maxOf(last.open, last.close)
        if (lowerWick > body * 2 && upperWick < body * 0.5) {
            patterns.add(if (last.close > last.open) "Hammer (Bullish)" else "Hanging Man")
        }

        // Engulfing
        if (prev.close < prev.open && last.close > last.open &&
            last.open < prev.close && last.close > prev.open
        ) {
            patterns.add("Bullish Engulfing")
        }
        if (prev.close > prev.open && last.close < last.open &&
            last.open > prev.close && last.close < prev.open
        ) {
            patterns.add("Bearish Engulfing")
        }

        // Morning Star
        val midBody = abs(prev.close - prev.open)
        if (prev2.close < prev2.open &&
            midBody < (prev2.open - prev2.close) * 0.3 &&
            last.close > last.open && last.close > (prev2.open + prev2.close) / 2
        ) {
            patterns.add("Morning Star (Bullish)")
        }

        // Three White Soldiers
        if (prev2.close > prev2.open && prev.close > prev.open && last.close > last.open &&
            prev.open > prev2.open && last.open > prev.open &&
            prev.close > prev2.close && last.close > prev.close
        ) {
            patterns.add("Three White Soldiers (Bullish)")
        }

        // Shooting Star
        if (upperWick > body * 2 && lowerWick < body * 0.5 && last.close < last.open) {
            patterns.add("Shooting Star (Bearish)")
        }

        return patterns
    }

    // ===========================
    // SUPPORT & RESISTANCE
    // ===========================
    fun findSupportResistance(
        highs: List<Double>,
        lows: List<Double>,
        closes: List<Double>
    ): Pair<Double, Double> {
        val recent = closes.takeLast(50)
        val recentHighs = highs.takeLast(50)
        val recentLows = lows.takeLast(50)

        val support = recentLows.sorted().take(5).average()
        val resistance = recentHighs.sorted().takeLast(5).average()

        return Pair(support, resistance)
    }

    // ===========================
    // SIGNAL GENERATION
    // ===========================
    private fun generateSignal(
        rsi: List<Double>,
        macd: List<Double>,
        macdSignal: List<Double>,
        currentPrice: Double,
        ema9: List<Double>,
        ema21: List<Double>,
        ema50: List<Double>,
        sma200: Double,
        bbUpper: List<Double>,
        bbLower: List<Double>,
        stochK: List<Double>,
        adx: List<Double>,
        patterns: List<String>,
        sentimentScore: Double,
        obv: List<Double>,
        previousOBV: Double
    ): PredictionSignal {
        var score = 0

        val lastRSI = rsi.lastOrNull() ?: 50.0
        val lastMACD = macd.lastOrNull() ?: 0.0
        val lastMACDSignal = macdSignal.lastOrNull() ?: 0.0
        val lastEMA9 = ema9.lastOrNull() ?: currentPrice
        val lastEMA21 = ema21.lastOrNull() ?: currentPrice
        val lastEMA50 = ema50.lastOrNull() ?: currentPrice
        val lastBBUpper = bbUpper.lastOrNull() ?: currentPrice * 1.02
        val lastBBLower = bbLower.lastOrNull() ?: currentPrice * 0.98
        val lastStoch = stochK.lastOrNull() ?: 50.0
        val lastADX = adx.lastOrNull() ?: 25.0
        val lastOBV = obv.lastOrNull() ?: 0.0

        // RSI signals
        if (lastRSI < 30) score += 3
        else if (lastRSI < 45) score += 1
        else if (lastRSI > 70) score -= 3
        else if (lastRSI > 55) score -= 1

        // MACD signals
        if (lastMACD > lastMACDSignal) score += 2
        else score -= 2

        // EMA Crossovers
        if (lastEMA9 > lastEMA21 && lastEMA21 > lastEMA50) score += 2
        else if (lastEMA9 < lastEMA21 && lastEMA21 < lastEMA50) score -= 2

        // Price vs SMA200 (trend)
        if (currentPrice > sma200) score += 1
        else score -= 1

        // Bollinger Bands
        if (currentPrice < lastBBLower) score += 2
        else if (currentPrice > lastBBUpper) score -= 2

        // Stochastic
        if (lastStoch < 20) score += 2
        else if (lastStoch > 80) score -= 2

        // ADX (trend strength)
        if (lastADX > 25) score += if (score > 0) 1 else -1

        // OBV (volume confirmation)
        if (lastOBV > previousOBV) score += 1
        else score -= 1

        // Patterns
        patterns.forEach { pattern ->
            when {
                pattern.contains("Bullish") || pattern.contains("Hammer") -> score += 2
                pattern.contains("Bearish") || pattern.contains("Shooting") -> score -= 2
                pattern.contains("Doji") -> { /* neutral */ }
            }
        }

        // Sentiment
        score += (sentimentScore * 2).toInt()

        return when {
            score >= 8 -> PredictionSignal.STRONG_BUY
            score >= 3 -> PredictionSignal.BUY
            score <= -8 -> PredictionSignal.STRONG_SELL
            score <= -3 -> PredictionSignal.SELL
            else -> PredictionSignal.HOLD
        }
    }

    // ===========================
    // PRICE PREDICTION
    // ===========================
    private fun predictPrice(
        closes: List<Double>,
        days: Int,
        signal: PredictionSignal,
        atr: List<Double>
    ): Double {
        val recent = closes.takeLast(30)
        val currentPrice = recent.last()
        val avgATR = atr.takeLast(14).average()

        // Linear regression momentum
        val n = recent.size
        val xMean = (n - 1) / 2.0
        val yMean = recent.average()
        var numerator = 0.0
        var denominator = 0.0
        for (i in recent.indices) {
            numerator += (i - xMean) * (recent[i] - yMean)
            denominator += (i - xMean).pow(2)
        }
        val slope = if (denominator != 0.0) numerator / denominator else 0.0

        val signalMultiplier = when (signal) {
            PredictionSignal.STRONG_BUY -> 1.5
            PredictionSignal.BUY -> 1.2
            PredictionSignal.HOLD -> 1.0
            PredictionSignal.SELL -> 0.8
            PredictionSignal.STRONG_SELL -> 0.5
        }

        val momentum = slope * days * signalMultiplier
        val volatilityFactor = avgATR * sqrt(days.toDouble()) * 0.1

        return maxOf(0.01, currentPrice + momentum + volatilityFactor * (signalMultiplier - 1))
    }

    // ===========================
    // SUPPORTING CALCULATIONS
    // ===========================
    private fun calculateNewsSentiment(news: List<StockNews>): Double {
        if (news.isEmpty()) return 0.0
        val scores = news.map { n ->
            when (n.sentiment) {
                NewsSentiment.POSITIVE -> 1.0
                NewsSentiment.NEUTRAL -> 0.0
                NewsSentiment.NEGATIVE -> -1.0
            }
        }
        return scores.average()
    }

    private fun calculateConfidence(
        rsi: List<Double>,
        macd: List<Double>,
        macdSignal: List<Double>,
        adx: List<Double>,
        patterns: List<String>,
        sentimentScore: Double
    ): Double {
        var confidence = 50.0
        val lastRSI = rsi.lastOrNull() ?: 50.0
        val lastADX = adx.lastOrNull() ?: 25.0
        val macdDivergence = abs((macd.lastOrNull() ?: 0.0) - (macdSignal.lastOrNull() ?: 0.0))

        // Strong RSI readings increase confidence
        if (lastRSI < 25 || lastRSI > 75) confidence += 15
        else if (lastRSI < 35 || lastRSI > 65) confidence += 8

        // ADX shows trend strength
        confidence += (lastADX - 25).coerceIn(-20.0, 25.0)

        // Pattern confirmation
        confidence += patterns.size * 5.0

        // Sentiment alignment
        confidence += abs(sentimentScore) * 10

        return confidence.coerceIn(30.0, 95.0)
    }

    private fun assessRisk(
        atr: Double,
        beta: Double,
        adx: Double,
        volatility: Double
    ): RiskLevel {
        val riskScore = (beta * 2 + volatility / 10 + atr / 50) / 3
        return when {
            riskScore < 0.5 -> RiskLevel.VERY_LOW
            riskScore < 1.0 -> RiskLevel.LOW
            riskScore < 1.5 -> RiskLevel.MEDIUM
            riskScore < 2.0 -> RiskLevel.HIGH
            else -> RiskLevel.VERY_HIGH
        }
    }

    private fun calculateBeta(closes: List<Double>): Double {
        // Simplified beta using volatility relative to average
        val returns = closes.zipWithNext { a, b -> (b - a) / a }
        val volatility = calculateVolatility(closes)
        val marketVol = 0.015 // Approximate market volatility
        return (volatility / marketVol).coerceIn(0.1, 3.0)
    }

    private fun calculateVolatility(prices: List<Double>): Double {
        val returns = prices.zipWithNext { a, b -> (b - a) / a }
        val mean = returns.average()
        val variance = returns.map { (it - mean).pow(2) }.average()
        return sqrt(variance)
    }

    private fun calculateTarget(
        currentPrice: Double,
        signal: PredictionSignal,
        resistance: Double,
        atr: Double
    ): Double {
        return when (signal) {
            PredictionSignal.STRONG_BUY -> maxOf(resistance, currentPrice + atr * 3)
            PredictionSignal.BUY -> maxOf(resistance, currentPrice + atr * 2)
            PredictionSignal.HOLD -> currentPrice * 1.03
            PredictionSignal.SELL -> currentPrice * 0.97
            PredictionSignal.STRONG_SELL -> currentPrice * 0.93
        }
    }

    private fun calculateStopLoss(
        currentPrice: Double,
        signal: PredictionSignal,
        support: Double,
        atr: Double
    ): Double {
        return when (signal) {
            PredictionSignal.STRONG_BUY -> minOf(support, currentPrice - atr * 2)
            PredictionSignal.BUY -> minOf(support, currentPrice - atr * 1.5)
            else -> currentPrice - atr * 2
        }
    }

    private fun generateAnalysisText(
        symbol: String,
        currentPrice: Double,
        signal: PredictionSignal,
        rsi: Double,
        macd: Double,
        patterns: List<String>,
        sentimentScore: Double,
        riskLevel: RiskLevel,
        fundamentals: StockFundamentals?
    ): String {
        val signalText = when (signal) {
            PredictionSignal.STRONG_BUY -> "Strong Buy"
            PredictionSignal.BUY -> "Buy"
            PredictionSignal.HOLD -> "Hold"
            PredictionSignal.SELL -> "Sell"
            PredictionSignal.STRONG_SELL -> "Strong Sell"
        }

        val rsiAnalysis = when {
            rsi < 30 -> "RSI at ${"%.1f".format(rsi)} indicates oversold conditions, potential reversal ahead."
            rsi > 70 -> "RSI at ${"%.1f".format(rsi)} indicates overbought conditions, caution advised."
            else -> "RSI at ${"%.1f".format(rsi)} is in neutral territory."
        }

        val sentimentText = when {
            sentimentScore > 0.5 -> "Market sentiment is strongly positive."
            sentimentScore > 0 -> "Market sentiment leans positive."
            sentimentScore < -0.5 -> "Market sentiment is strongly negative."
            sentimentScore < 0 -> "Market sentiment leans negative."
            else -> "Market sentiment is neutral."
        }

        val patternText = if (patterns.isEmpty()) "" else
            "Technical patterns detected: ${patterns.joinToString(", ")}. "

        return """
            $symbol is trading at ₹${"%.2f".format(currentPrice)}. Our AI model generates a **$signalText** signal based on comprehensive multi-factor analysis.

            $rsiAnalysis MACD ${if (macd > 0) "shows bullish momentum" else "indicates bearish pressure"} at ${"%.3f".format(macd)}.

            ${patternText}$sentimentText

            Risk assessment: ${riskLevel.name.replace("_", " ")}. Always use proper position sizing and stop-losses. This is AI analysis, not financial advice.
        """.trimIndent()
    }

    private fun generateKeyFactors(
        rsi: Double, macd: Double, macdSignal: Double,
        price: Double, ema50: Double, sma200: Double,
        patterns: List<String>, sentimentScore: Double,
        signal: PredictionSignal
    ): List<String> {
        val factors = mutableListOf<String>()

        if (rsi < 30) factors.add("RSI oversold (${"%.1f".format(rsi)}) — bounce potential")
        else if (rsi > 70) factors.add("RSI overbought (${"%.1f".format(rsi)}) — pullback risk")

        if (macd > macdSignal) factors.add("MACD bullish crossover — upward momentum")
        else factors.add("MACD bearish — downward pressure")

        if (price > ema50) factors.add("Price above 50 EMA — bullish trend")
        else factors.add("Price below 50 EMA — bearish trend")

        if (price > sma200) factors.add("Above 200 SMA — long-term uptrend")
        else factors.add("Below 200 SMA — long-term downtrend")

        patterns.forEach { factors.add("Pattern: $it") }

        if (sentimentScore > 0.3) factors.add("Positive news sentiment")
        else if (sentimentScore < -0.3) factors.add("Negative news sentiment")

        return factors.take(6)
    }

    private fun createDefaultPrediction(symbol: String, price: Double) = StockPrediction(
        symbol = symbol, currentPrice = price,
        predictedPrice1D = price, predictedPrice1W = price,
        predictedPrice1M = price, predictedPrice3M = price,
        confidence = 0.0, signal = PredictionSignal.HOLD,
        supportLevel = price * 0.95, resistanceLevel = price * 1.05,
        rsi = 50.0, macd = 0.0, macdSignal = 0.0,
        bollingerUpper = price * 1.02, bollingerLower = price * 0.98, bollingerMid = price,
        sentiment = MarketSentiment.NEUTRAL,
        aiAnalysis = "Insufficient data for analysis.",
        keyFactors = listOf("Insufficient data"),
        riskLevel = RiskLevel.MEDIUM, targetPrice = price, stopLoss = price * 0.95
    )
}

data class StockFundamentals(
    val pe: Double, val pb: Double, val eps: Double,
    val revenueGrowth: Double, val roe: Double, val debtToEquity: Double
)
