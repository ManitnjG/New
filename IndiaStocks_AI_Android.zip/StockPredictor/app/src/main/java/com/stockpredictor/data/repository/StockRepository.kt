package com.stockpredictor.data.repository

import com.stockpredictor.data.api.NseApiService
import com.stockpredictor.data.api.AlphaVantageApiService
import com.stockpredictor.data.models.*
import com.stockpredictor.utils.AIPredictionEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StockRepository @Inject constructor(
    private val nseApi: NseApiService,
    private val alphaVantageApi: AlphaVantageApiService,
    private val stockDao: StockDao,
    private val portfolioDao: PortfolioDao,
    private val alertDao: AlertDao
) {

    // ===========================
    // MARKET INDICES
    // ===========================
    fun getMarketIndices(): Flow<Resource<List<MarketIndex>>> = flow {
        emit(Resource.Loading())
        try {
            val indices = listOf(
                MarketIndex("NIFTY 50", 19800.0, 120.0, 0.61, 19700.0, 19850.0, 19680.0, 19680.0),
                MarketIndex("SENSEX", 65800.0, 380.0, 0.58, 65500.0, 65900.0, 65400.0, 65420.0),
                MarketIndex("NIFTY BANK", 44200.0, -180.0, -0.41, 44400.0, 44500.0, 44100.0, 44380.0),
                MarketIndex("NIFTY IT", 32500.0, 250.0, 0.77, 32300.0, 32600.0, 32200.0, 32250.0),
                MarketIndex("NIFTY MIDCAP 100", 38200.0, 95.0, 0.25, 38100.0, 38300.0, 38000.0, 38105.0),
                MarketIndex("NIFTY AUTO", 16800.0, 140.0, 0.84, 16700.0, 16850.0, 16650.0, 16660.0)
            )
            emit(Resource.Success(indices))
        } catch (e: Exception) {
            emit(Resource.Error("Failed to load indices: ${e.message}"))
        }
    }

    // ===========================
    // TOP STOCKS (NSE)
    // ===========================
    fun getTopStocks(exchange: String = "NSE"): Flow<Resource<List<Stock>>> = flow {
        emit(Resource.Loading())
        try {
            val cached = stockDao.getAllStocks()
            val mockStocks = generateMockStocks(exchange)
            stockDao.insertStocks(mockStocks)
            emit(Resource.Success(mockStocks))
        } catch (e: Exception) {
            emit(Resource.Error("Failed to load stocks: ${e.message}"))
        }
    }

    // ===========================
    // STOCK DETAIL
    // ===========================
    suspend fun getStockDetail(symbol: String): Resource<Stock> {
        return try {
            val stock = stockDao.getStockBySymbol(symbol)
                ?: generateMockStocks("NSE").find { it.symbol == symbol }
                ?: return Resource.Error("Stock not found")
            Resource.Success(stock)
        } catch (e: Exception) {
            Resource.Error("Failed to load stock: ${e.message}")
        }
    }

    // ===========================
    // HISTORICAL CANDLES
    // ===========================
    suspend fun getHistoricalData(symbol: String, timeframe: TimeFrame): Resource<List<CandleData>> {
        return try {
            val candles = generateMockCandles(symbol, timeframe.days.coerceAtLeast(30))
            Resource.Success(candles)
        } catch (e: Exception) {
            Resource.Error("Failed to load historical data: ${e.message}")
        }
    }

    // ===========================
    // AI PREDICTION
    // ===========================
    suspend fun getStockPrediction(symbol: String): Resource<StockPrediction> {
        return try {
            val candles = generateMockCandles(symbol, 200)
            val currentPrice = candles.last().close
            val news = generateMockNews(symbol)
            val prediction = AIPredictionEngine.generatePrediction(
                symbol, candles, currentPrice, news
            )
            Resource.Success(prediction)
        } catch (e: Exception) {
            Resource.Error("Failed to generate prediction: ${e.message}")
        }
    }

    // ===========================
    // WATCHLIST
    // ===========================
    fun getWatchlist(): Flow<List<Stock>> = stockDao.getWatchlist()

    suspend fun toggleWatchlist(symbol: String, isInWatchlist: Boolean) {
        stockDao.updateWatchlistStatus(symbol, isInWatchlist)
    }

    // ===========================
    // PORTFOLIO
    // ===========================
    fun getPortfolioHoldings(): Flow<List<PortfolioHolding>> = portfolioDao.getAllHoldings()

    suspend fun addToPortfolio(holding: PortfolioHolding) = portfolioDao.insertHolding(holding)
    suspend fun updateHolding(holding: PortfolioHolding) = portfolioDao.updateHolding(holding)
    suspend fun deleteHolding(id: Long) = portfolioDao.deleteHoldingById(id)

    // ===========================
    // PRICE ALERTS
    // ===========================
    fun getAllAlerts(): Flow<List<PriceAlert>> = alertDao.getAllAlerts()
    fun getAlertsForSymbol(symbol: String): Flow<List<PriceAlert>> = alertDao.getAlertsForSymbol(symbol)
    suspend fun addAlert(alert: PriceAlert) = alertDao.insertAlert(alert)
    suspend fun deleteAlert(alert: PriceAlert) = alertDao.deleteAlert(alert)

    // ===========================
    // SEARCH
    // ===========================
    suspend fun searchStocks(query: String): List<Stock> {
        val local = stockDao.searchStocks("%$query%")
        return if (local.isEmpty()) generateMockStocks("NSE").filter {
            it.symbol.contains(query, true) || it.companyName.contains(query, true)
        } else local
    }

    // ===========================
    // NEWS
    // ===========================
    suspend fun getStockNews(symbol: String): Resource<List<StockNews>> {
        return try {
            Resource.Success(generateMockNews(symbol))
        } catch (e: Exception) {
            Resource.Error("Failed to load news")
        }
    }

    // ===========================
    // TOP GAINERS / LOSERS
    // ===========================
    suspend fun getTopGainers(): Resource<List<Stock>> {
        return try {
            val stocks = generateMockStocks("NSE").sortedByDescending { it.changePercent }.take(10)
            Resource.Success(stocks)
        } catch (e: Exception) {
            Resource.Error("Failed to load gainers")
        }
    }

    suspend fun getTopLosers(): Resource<List<Stock>> {
        return try {
            val stocks = generateMockStocks("NSE").sortedBy { it.changePercent }.take(10)
            Resource.Success(stocks)
        } catch (e: Exception) {
            Resource.Error("Failed to load losers")
        }
    }

    // ===========================
    // IPO DATA
    // ===========================
    suspend fun getIPOData(): Resource<List<IPO>> {
        return try {
            Resource.Success(generateMockIPOs())
        } catch (e: Exception) {
            Resource.Error("Failed to load IPO data")
        }
    }

    // ===========================
    // MOCK DATA GENERATORS
    // ===========================
    private fun generateMockStocks(exchange: String): List<Stock> {
        val stockData = listOf(
            Triple("RELIANCE", "Reliance Industries Ltd", "Energy"),
            Triple("TCS", "Tata Consultancy Services", "IT"),
            Triple("INFY", "Infosys Limited", "IT"),
            Triple("HDFCBANK", "HDFC Bank Limited", "Banking"),
            Triple("ICICIBANK", "ICICI Bank Limited", "Banking"),
            Triple("HINDUNILVR", "Hindustan Unilever Ltd", "FMCG"),
            Triple("BAJFINANCE", "Bajaj Finance Limited", "Finance"),
            Triple("KOTAKBANK", "Kotak Mahindra Bank", "Banking"),
            Triple("SBIN", "State Bank of India", "Banking"),
            Triple("BHARTIARTL", "Bharti Airtel Limited", "Telecom"),
            Triple("WIPRO", "Wipro Limited", "IT"),
            Triple("MARUTI", "Maruti Suzuki India Ltd", "Auto"),
            Triple("TATAMOTORS", "Tata Motors Limited", "Auto"),
            Triple("M&M", "Mahindra & Mahindra Ltd", "Auto"),
            Triple("SUNPHARMA", "Sun Pharmaceutical", "Pharma"),
            Triple("DRREDDY", "Dr Reddy's Laboratories", "Pharma"),
            Triple("CIPLA", "Cipla Limited", "Pharma"),
            Triple("ONGC", "Oil & Natural Gas Corp", "Energy"),
            Triple("NTPC", "NTPC Limited", "Power"),
            Triple("ADANIENT", "Adani Enterprises Ltd", "Conglomerate"),
            Triple("LT", "Larsen & Toubro Limited", "Infrastructure"),
            Triple("TITAN", "Titan Company Limited", "Retail"),
            Triple("AXISBANK", "Axis Bank Limited", "Banking"),
            Triple("NESTLEIND", "Nestle India Limited", "FMCG"),
            Triple("POWERGRID", "Power Grid Corporation", "Power")
        )

        return stockData.mapIndexed { idx, (symbol, name, sector) ->
            val basePrice = (500..5000).random().toDouble()
            val change = (-5..8).random().toDouble() + (-9..9).random() / 10.0
            val changePercent = change / basePrice * 100
            Stock(
                symbol = symbol,
                companyName = name,
                exchange = exchange,
                sector = sector,
                industry = sector,
                currentPrice = basePrice,
                previousClose = basePrice - change,
                change = change,
                changePercent = changePercent,
                open = basePrice * 0.99,
                high = basePrice * 1.02,
                low = basePrice * 0.97,
                volume = (1_000_000L..50_000_000L).random(),
                avgVolume = (5_000_000L..30_000_000L).random(),
                marketCap = (basePrice * 1_000_000_000).toLong(),
                pe = (15..40).random().toDouble(),
                eps = (basePrice / (15..40).random()).toDouble(),
                week52High = basePrice * 1.3,
                week52Low = basePrice * 0.7,
                dividendYield = (0..3).random().toDouble() + (0..9).random() / 10.0,
                beta = 0.5 + (0..15).random() / 10.0,
                isInWatchlist = idx < 5
            )
        }
    }

    private fun generateMockCandles(symbol: String, days: Int): List<CandleData> {
        val candles = mutableListOf<CandleData>()
        var price = (500..2000).random().toDouble()
        val now = System.currentTimeMillis()
        val dayMs = 86_400_000L

        repeat(days) { i ->
            val change = price * (-0.03..0.03).random()
            val open = price
            price = (price + change).coerceAtLeast(10.0)
            val high = maxOf(open, price) * (1 + (0..2).random() / 100.0)
            val low = minOf(open, price) * (1 - (0..2).random() / 100.0)
            candles.add(
                CandleData(
                    timestamp = now - (days - i) * dayMs,
                    open = open,
                    high = high,
                    low = low,
                    close = price,
                    volume = (500_000L..10_000_000L).random()
                )
            )
        }
        return candles
    }

    private fun ClosedFloatingPointRange<Double>.random(): Double {
        return start + Math.random() * (endInclusive - start)
    }

    private fun IntRange.random(): Int = (Math.random() * (last - first + 1) + first).toInt()
    private fun LongRange.random(): Long = (Math.random() * (last - first + 1) + first).toLong()

    private fun generateMockNews(symbol: String): List<StockNews> {
        return listOf(
            StockNews(
                id = "1", title = "$symbol Q3 Results Beat Estimates",
                summary = "Company reports strong quarterly performance with revenue growth of 18% YoY",
                source = "Economic Times", url = "https://economictimes.com",
                imageUrl = null, publishedAt = System.currentTimeMillis() - 3600000,
                sentiment = NewsSentiment.POSITIVE, relatedSymbols = listOf(symbol),
                category = "Earnings"
            ),
            StockNews(
                id = "2", title = "Market Outlook: Nifty to test new highs",
                summary = "Analysts remain bullish on Indian markets amid strong FII inflows",
                source = "Moneycontrol", url = "https://moneycontrol.com",
                imageUrl = null, publishedAt = System.currentTimeMillis() - 7200000,
                sentiment = NewsSentiment.POSITIVE, relatedSymbols = listOf(symbol),
                category = "Market"
            ),
            StockNews(
                id = "3", title = "RBI Policy: Rate hold expected",
                summary = "Monetary policy committee likely to keep repo rate unchanged at 6.5%",
                source = "Business Standard", url = "https://business-standard.com",
                imageUrl = null, publishedAt = System.currentTimeMillis() - 14400000,
                sentiment = NewsSentiment.NEUTRAL, relatedSymbols = emptyList(),
                category = "Economy"
            )
        )
    }

    private fun generateMockIPOs(): List<IPO> = listOf(
        IPO(
            companyName = "Swiggy Limited",
            symbol = "SWIGGY",
            issuePrice = 371.0..390.0,
            lotSize = 38,
            totalIssueSize = 11_327_00_000L,
            openDate = System.currentTimeMillis() - 5 * 86_400_000L,
            closeDate = System.currentTimeMillis() - 3 * 86_400_000L,
            listingDate = System.currentTimeMillis() + 2 * 86_400_000L,
            gmpPrice = 420.0,
            subscriptionStatus = SubscriptionStatus.CLOSED,
            category = "Food Delivery",
            registrar = "KFintech",
            sector = "Consumer Tech",
            minInvestment = 14820.0
        ),
        IPO(
            companyName = "NTPC Green Energy",
            symbol = "NTPCGREEN",
            issuePrice = 102.0..108.0,
            lotSize = 138,
            totalIssueSize = 10_000_00_000L,
            openDate = System.currentTimeMillis() + 2 * 86_400_000L,
            closeDate = System.currentTimeMillis() + 4 * 86_400_000L,
            listingDate = System.currentTimeMillis() + 8 * 86_400_000L,
            gmpPrice = 125.0,
            subscriptionStatus = SubscriptionStatus.UPCOMING,
            category = "Renewable Energy",
            registrar = "Link Intime",
            sector = "Power",
            minInvestment = 14904.0
        )
    )
}
