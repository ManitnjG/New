package com.stockpredictor.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stockpredictor.data.models.*
import com.stockpredictor.data.repository.StockRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class StockViewModel @Inject constructor(
    private val repository: StockRepository
) : ViewModel() {

    // ===========================
    // STATE
    // ===========================
    private val _uiState = MutableStateFlow(StockUiState())
    val uiState: StateFlow<StockUiState> = _uiState.asStateFlow()

    private val _selectedStock = MutableStateFlow<Stock?>(null)
    val selectedStock: StateFlow<Stock?> = _selectedStock.asStateFlow()

    private val _prediction = MutableStateFlow<StockPrediction?>(null)
    val prediction: StateFlow<StockPrediction?> = _prediction.asStateFlow()

    private val _historicalData = MutableStateFlow<List<CandleData>>(emptyList())
    val historicalData: StateFlow<List<CandleData>> = _historicalData.asStateFlow()

    private val _selectedTimeframe = MutableStateFlow(TimeFrame.ONE_MONTH)
    val selectedTimeframe: StateFlow<TimeFrame> = _selectedTimeframe.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Stock>>(emptyList())
    val searchResults: StateFlow<List<Stock>> = _searchResults.asStateFlow()

    private val _newsItems = MutableStateFlow<List<StockNews>>(emptyList())
    val newsItems: StateFlow<List<StockNews>> = _newsItems.asStateFlow()

    private val _topGainers = MutableStateFlow<List<Stock>>(emptyList())
    val topGainers: StateFlow<List<Stock>> = _topGainers.asStateFlow()

    private val _topLosers = MutableStateFlow<List<Stock>>(emptyList())
    val topLosers: StateFlow<List<Stock>> = _topLosers.asStateFlow()

    private val _ipoData = MutableStateFlow<List<IPO>>(emptyList())
    val ipoData: StateFlow<List<IPO>> = _ipoData.asStateFlow()

    // ===========================
    // PORTFOLIO
    // ===========================
    val portfolioHoldings = repository.getPortfolioHoldings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchlist = repository.getWatchlist()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val priceAlerts = repository.getAllAlerts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ===========================
    // INIT
    // ===========================
    init {
        loadMarketData()
        loadTopGainersLosers()
        loadIPOData()
    }

    // ===========================
    // MARKET DATA
    // ===========================
    private fun loadMarketData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingMarket = true) }

            repository.getMarketIndices().collect { result ->
                when (result) {
                    is Resource.Success -> _uiState.update {
                        it.copy(marketIndices = result.data, isLoadingMarket = false)
                    }
                    is Resource.Error -> _uiState.update {
                        it.copy(error = result.message, isLoadingMarket = false)
                    }
                    is Resource.Loading -> {}
                }
            }
        }

        viewModelScope.launch {
            repository.getTopStocks().collect { result ->
                when (result) {
                    is Resource.Success -> _uiState.update {
                        it.copy(allStocks = result.data)
                    }
                    else -> {}
                }
            }
        }
    }

    private fun loadTopGainersLosers() {
        viewModelScope.launch {
            when (val result = repository.getTopGainers()) {
                is Resource.Success -> _topGainers.value = result.data
                else -> {}
            }
        }
        viewModelScope.launch {
            when (val result = repository.getTopLosers()) {
                is Resource.Success -> _topLosers.value = result.data
                else -> {}
            }
        }
    }

    private fun loadIPOData() {
        viewModelScope.launch {
            when (val result = repository.getIPOData()) {
                is Resource.Success -> _ipoData.value = result.data
                else -> {}
            }
        }
    }

    // ===========================
    // STOCK SELECTION
    // ===========================
    fun selectStock(stock: Stock) {
        _selectedStock.value = stock
        loadHistoricalData(stock.symbol)
        loadPrediction(stock.symbol)
        loadStockNews(stock.symbol)
    }

    // ===========================
    // HISTORICAL DATA
    // ===========================
    fun loadHistoricalData(symbol: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingChart = true) }
            when (val result = repository.getHistoricalData(symbol, _selectedTimeframe.value)) {
                is Resource.Success -> {
                    _historicalData.value = result.data
                    _uiState.update { it.copy(isLoadingChart = false) }
                }
                is Resource.Error -> _uiState.update {
                    it.copy(error = result.message, isLoadingChart = false)
                }
                else -> {}
            }
        }
    }

    fun setTimeframe(timeframe: TimeFrame) {
        _selectedTimeframe.value = timeframe
        _selectedStock.value?.let { loadHistoricalData(it.symbol) }
    }

    // ===========================
    // AI PREDICTION
    // ===========================
    fun loadPrediction(symbol: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingPrediction = true) }
            when (val result = repository.getStockPrediction(symbol)) {
                is Resource.Success -> {
                    _prediction.value = result.data
                    _uiState.update { it.copy(isLoadingPrediction = false) }
                }
                is Resource.Error -> _uiState.update {
                    it.copy(error = result.message, isLoadingPrediction = false)
                }
                else -> {}
            }
        }
    }

    // ===========================
    // NEWS
    // ===========================
    fun loadStockNews(symbol: String) {
        viewModelScope.launch {
            when (val result = repository.getStockNews(symbol)) {
                is Resource.Success -> _newsItems.value = result.data
                else -> {}
            }
        }
    }

    // ===========================
    // SEARCH
    // ===========================
    fun searchStocks(query: String) {
        if (query.length < 2) {
            _searchResults.value = emptyList()
            return
        }
        viewModelScope.launch {
            _searchResults.value = repository.searchStocks(query)
        }
    }

    // ===========================
    // WATCHLIST
    // ===========================
    fun toggleWatchlist(symbol: String, currentStatus: Boolean) {
        viewModelScope.launch {
            repository.toggleWatchlist(symbol, !currentStatus)
        }
    }

    // ===========================
    // PORTFOLIO OPERATIONS
    // ===========================
    fun addToPortfolio(symbol: String, name: String, qty: Double, price: Double, exchange: String, sector: String) {
        viewModelScope.launch {
            repository.addToPortfolio(
                PortfolioHolding(
                    symbol = symbol,
                    companyName = name,
                    exchange = exchange,
                    quantity = qty,
                    avgBuyPrice = price,
                    sector = sector
                )
            )
        }
    }

    fun deleteHolding(id: Long) {
        viewModelScope.launch { repository.deleteHolding(id) }
    }

    // ===========================
    // ALERTS
    // ===========================
    fun addPriceAlert(symbol: String, name: String, targetPrice: Double, type: AlertType) {
        viewModelScope.launch {
            repository.addAlert(
                PriceAlert(
                    symbol = symbol,
                    companyName = name,
                    targetPrice = targetPrice,
                    alertType = type
                )
            )
        }
    }

    fun deleteAlert(alert: PriceAlert) {
        viewModelScope.launch { repository.deleteAlert(alert) }
    }

    // ===========================
    // PORTFOLIO SUMMARY
    // ===========================
    fun getPortfolioSummary(holdings: List<PortfolioHolding>): PortfolioSummary {
        val totalInvested = holdings.sumOf { it.totalInvested }
        val currentValue = holdings.sumOf { it.currentValue }
        val pl = currentValue - totalInvested
        val plPercent = if (totalInvested > 0) (pl / totalInvested) * 100 else 0.0
        val sectorAlloc = holdings.groupBy { it.sector }
            .mapValues { (_, v) -> v.sumOf { it.currentValue } / currentValue * 100 }
        return PortfolioSummary(
            totalInvested = totalInvested,
            currentValue = currentValue,
            totalProfitLoss = pl,
            totalProfitLossPercent = plPercent,
            dayGain = holdings.sumOf { it.currentValue * 0.005 },
            dayGainPercent = 0.5,
            holdings = holdings,
            sectorAllocation = sectorAlloc,
            topGainer = holdings.maxByOrNull { it.profitLossPercent },
            topLoser = holdings.minByOrNull { it.profitLossPercent }
        )
    }

    fun refreshMarket() = loadMarketData()
}

data class StockUiState(
    val marketIndices: List<MarketIndex> = emptyList(),
    val allStocks: List<Stock> = emptyList(),
    val isLoadingMarket: Boolean = false,
    val isLoadingChart: Boolean = false,
    val isLoadingPrediction: Boolean = false,
    val error: String? = null
)
