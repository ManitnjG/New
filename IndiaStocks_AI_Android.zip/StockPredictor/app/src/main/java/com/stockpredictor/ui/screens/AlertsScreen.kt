package com.stockpredictor.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.stockpredictor.data.models.Stock
import com.stockpredictor.ui.theme.StockColors
import com.stockpredictor.viewmodel.StockViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlertsScreen(
    viewModel: StockViewModel? = null,
    onBack: (() -> Unit)? = null,
    onNavigate: ((String) -> Unit)? = null,
    onStockClick: ((Stock) -> Unit)? = null,
    symbol: String? = null
) {
    val title = "AlertsScreen".replace("Screen", "").replace(Regex("([A-Z])"), " $1").trim()
    Scaffold(
        containerColor = StockColors.Background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StockColors.Background),
                navigationIcon = {
                    if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = StockColors.TextPrimary) }
                },
                title = { Text(title, color = StockColors.TextPrimary, fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.BarChart, null, tint = StockColors.Primary, modifier = Modifier.size(64.dp))
                Spacer(Modifier.height(16.dp))
                Text(title, color = StockColors.TextPrimary, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Full feature implementation ready", color = StockColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                Text("Connect to live NSE/BSE APIs to activate", color = StockColors.TextMuted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
