package com.stockpredictor.data.repository

import androidx.room.*
import com.stockpredictor.data.models.*
import kotlinx.coroutines.flow.Flow

// ===========================
// DAOs
// ===========================

@Dao
interface StockDao {
    @Query("SELECT * FROM stocks ORDER BY changePercent DESC")
    fun getAllStocks(): Flow<List<Stock>>

    @Query("SELECT * FROM stocks WHERE isInWatchlist = 1")
    fun getWatchlist(): Flow<List<Stock>>

    @Query("SELECT * FROM stocks WHERE symbol = :symbol")
    suspend fun getStockBySymbol(symbol: String): Stock?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStock(stock: Stock)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStocks(stocks: List<Stock>)

    @Update
    suspend fun updateStock(stock: Stock)

    @Query("UPDATE stocks SET isInWatchlist = :isInWatchlist WHERE symbol = :symbol")
    suspend fun updateWatchlistStatus(symbol: String, isInWatchlist: Boolean)

    @Query("SELECT * FROM stocks WHERE sector = :sector")
    fun getStocksBySector(sector: String): Flow<List<Stock>>

    @Query("SELECT * FROM stocks WHERE symbol LIKE :query OR companyName LIKE :query")
    suspend fun searchStocks(query: String): List<Stock>
}

@Dao
interface PortfolioDao {
    @Query("SELECT * FROM portfolio")
    fun getAllHoldings(): Flow<List<PortfolioHolding>>

    @Query("SELECT * FROM portfolio WHERE symbol = :symbol")
    suspend fun getHoldingBySymbol(symbol: String): PortfolioHolding?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHolding(holding: PortfolioHolding)

    @Update
    suspend fun updateHolding(holding: PortfolioHolding)

    @Delete
    suspend fun deleteHolding(holding: PortfolioHolding)

    @Query("DELETE FROM portfolio WHERE id = :id")
    suspend fun deleteHoldingById(id: Long)

    @Query("SELECT SUM(totalInvested) FROM portfolio")
    fun getTotalInvested(): Flow<Double?>

    @Query("SELECT SUM(currentValue) FROM portfolio")
    fun getTotalCurrentValue(): Flow<Double?>
}

@Dao
interface AlertDao {
    @Query("SELECT * FROM price_alerts ORDER BY createdAt DESC")
    fun getAllAlerts(): Flow<List<PriceAlert>>

    @Query("SELECT * FROM price_alerts WHERE isActive = 1 AND isTriggered = 0")
    suspend fun getActiveAlerts(): List<PriceAlert>

    @Query("SELECT * FROM price_alerts WHERE symbol = :symbol")
    fun getAlertsForSymbol(symbol: String): Flow<List<PriceAlert>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: PriceAlert)

    @Update
    suspend fun updateAlert(alert: PriceAlert)

    @Delete
    suspend fun deleteAlert(alert: PriceAlert)

    @Query("UPDATE price_alerts SET isTriggered = 1, triggeredAt = :time WHERE id = :id")
    suspend fun markAlertTriggered(id: Long, time: Long = System.currentTimeMillis())
}

// ===========================
// DATABASE
// ===========================
@Database(
    entities = [Stock::class, PortfolioHolding::class, PriceAlert::class],
    version = 1,
    exportSchema = false
)
abstract class StockDatabase : RoomDatabase() {
    abstract fun stockDao(): StockDao
    abstract fun portfolioDao(): PortfolioDao
    abstract fun alertDao(): AlertDao
}
