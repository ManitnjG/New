# 🇮🇳 IndiaStocks AI - Premium Indian Stock Market Predictor

## Features
- **AI-Powered Predictions** — RSI, MACD, Bollinger Bands, EMA, ADX, OBV + pattern recognition
- **Live NSE & BSE Data** — Real-time quotes, indices, F&O
- **Candlestick Charts** — Full-screen interactive charts with 9 timeframes
- **Portfolio Tracker** — P&L, sector allocation, performance analytics
- **Price Alerts** — Real-time notifications when stocks hit targets
- **Stock Screener** — Filter by PE, market cap, sector, signals, RSI
- **IPO Centre** — GMP, subscription status, upcoming IPOs
- **Market Heatmap** — Sector-wise visual performance
- **Options Chain** — F&O data with Greeks (Delta, Gamma, Theta, Vega)
- **AI Signals Dashboard** — Buy/Sell signals across all stocks
- **News & Sentiment** — News sentiment analysis per stock
- **Watchlist** — Unlimited stocks with real-time tracking
- **Biometric Login** — Fingerprint/Face authentication
- **Dark/AMOLED Themes** — Eye-friendly dark UI

## Setup

### 1. Clone & Open in Android Studio
```
Open Android Studio → File → Open → select StockPredictor/
```

### 2. API Keys
Edit `app/build.gradle`:
```
buildConfigField "String", "ALPHA_VANTAGE_KEY", '"YOUR_KEY_HERE"'
```
Get free key: https://www.alphavantage.co/support/#api-key

### 3. Firebase (for push notifications)
- Create project at https://console.firebase.google.com
- Download `google-services.json` → place in `app/`

### 4. Build
```bash
./gradlew assembleDebug
```
APK at: `app/build/outputs/apk/debug/app-debug.apk`

## Tech Stack
| Layer | Technology |
|-------|-----------|
| Language | Kotlin |
| UI | Jetpack Compose + Material 3 |
| Architecture | MVVM + Clean Architecture |
| DI | Hilt |
| Network | Retrofit + OkHttp |
| Database | Room |
| Charts | Custom Canvas + MPAndroidChart |
| ML | TensorFlow Lite |
| Background | WorkManager |
| Auth | BiometricPrompt |
| Push | Firebase Cloud Messaging |
| IAP | Google Play Billing |

## AI Prediction Engine
The prediction engine (`AIPredictionEngine.kt`) calculates:
- **RSI** (Relative Strength Index) — 14-period
- **MACD** — 12/26/9 configuration
- **Bollinger Bands** — 20-period, 2σ
- **EMA** — 9, 21, 50 periods
- **SMA** — 200-period
- **ATR** — Average True Range for volatility
- **OBV** — On-Balance Volume
- **Stochastic** — %K 14-period
- **VWAP** — Volume Weighted Average Price
- **ADX** — Average Directional Index
- **Pattern Recognition** — Doji, Hammer, Engulfing, Morning Star, etc.
- **News Sentiment** — Positive/Negative news scoring
- **Signal Generation** — Weighted multi-factor scoring

## Disclaimer
This app is for educational purposes. Not financial advice.
Always do your own research before investing.
