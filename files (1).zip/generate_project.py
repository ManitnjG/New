#!/usr/bin/env python3
"""
generate_project.py
====================
Generates the complete Spofree Android FLAC Player & Downloader project.
Run: python3 generate_project.py
Output: Spofree_Android_Player.zip
"""

import os
import zipfile
import textwrap

ROOT = "Spofree_Android_Player"

FILES = {}

# ─────────────────────────────────────────────────────────────
# ROOT GRADLE FILES
# ─────────────────────────────────────────────────────────────

FILES["settings.gradle.kts"] = textwrap.dedent("""\
    pluginManagement {
        repositories {
            google()
            mavenCentral()
            gradlePluginPortal()
        }
    }
    dependencyResolutionManagement {
        repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
        repositories {
            google()
            mavenCentral()
        }
    }
    rootProject.name = "SpoFree"
    include(":app")
""")

FILES["build.gradle.kts"] = textwrap.dedent("""\
    buildscript {
        repositories {
            google()
            mavenCentral()
        }
        dependencies {
            classpath("com.android.tools.build:gradle:8.3.0")
            classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.22")
            classpath("com.google.dagger:hilt-android-gradle-plugin:2.51")
            classpath("com.chaquo.python:gradle:15.0.1")
        }
    }
    tasks.register("clean", Delete::class) {
        delete(rootProject.buildDir)
    }
""")

FILES["gradle.properties"] = textwrap.dedent("""\
    org.gradle.jvmargs=-Xmx4096m -Dfile.encoding=UTF-8
    android.useAndroidX=true
    kotlin.code.style=official
    android.nonTransitiveRClass=true
    android.enableJetifier=true
""")

FILES["gradle/wrapper/gradle-wrapper.properties"] = textwrap.dedent("""\
    distributionBase=GRADLE_USER_HOME
    distributionPath=wrapper/dists
    distributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip
    zipStoreBase=GRADLE_USER_HOME
    zipStorePath=wrapper/dists
""")

# ─────────────────────────────────────────────────────────────
# APP build.gradle.kts
# ─────────────────────────────────────────────────────────────

FILES["app/build.gradle.kts"] = textwrap.dedent("""\
    plugins {
        id("com.android.application")
        id("org.jetbrains.kotlin.android")
        id("kotlin-kapt")
        id("dagger.hilt.android.plugin")
        id("com.chaquo.python")
    }

    android {
        namespace = "com.spofree.player"
        compileSdk = 34

        defaultConfig {
            applicationId = "com.spofree.player"
            minSdk = 26
            targetSdk = 34
            versionCode = 1
            versionName = "1.0.0"

            ndk {
                abiFilters += listOf("arm64-v8a", "x86_64")
            }

            python {
                pip {
                    install("requests")
                    install("mutagen")
                    install("yt-dlp")
                    install("beautifulsoup4")
                    install("lyricsgenius")
                    install("syncedlyrics")
                    install("Pillow")
                    install("cryptography")
                }
                version = "3.11"
            }
        }

        buildTypes {
            release {
                isMinifyEnabled = true
                proguardFiles(
                    getDefaultProguardFile("proguard-android-optimize.txt"),
                    "proguard-rules.pro"
                )
            }
            debug {
                isDebuggable = true
            }
        }

        compileOptions {
            sourceCompatibility = JavaVersion.VERSION_17
            targetCompatibility = JavaVersion.VERSION_17
        }

        kotlinOptions {
            jvmTarget = "17"
        }

        buildFeatures {
            viewBinding = true
            buildConfig = true
        }
    }

    dependencies {
        // Kotlin & Coroutines
        implementation("org.jetbrains.kotlin:kotlin-stdlib:1.9.22")
        implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
        implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")

        // AndroidX Core
        implementation("androidx.core:core-ktx:1.12.0")
        implementation("androidx.appcompat:appcompat:1.6.1")
        implementation("androidx.activity:activity-ktx:1.8.2")
        implementation("androidx.fragment:fragment-ktx:1.6.2")
        implementation("androidx.constraintlayout:constraintlayout:2.1.4")
        implementation("androidx.recyclerview:recyclerview:1.3.2")
        implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
        implementation("androidx.cardview:cardview:1.0.0")
        implementation("com.google.android.material:material:1.11.0")

        // Lifecycle & ViewModel
        implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
        implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.7.0")
        implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
        implementation("androidx.lifecycle:lifecycle-service:2.7.0")

        // Navigation
        implementation("androidx.navigation:navigation-fragment-ktx:2.7.7")
        implementation("androidx.navigation:navigation-ui-ktx:2.7.7")

        // Hilt DI
        implementation("com.google.dagger:hilt-android:2.51")
        kapt("com.google.dagger:hilt-compiler:2.51")

        // ExoPlayer / Media3 (FLAC support)
        implementation("androidx.media3:media3-exoplayer:1.3.0")
        implementation("androidx.media3:media3-exoplayer-dash:1.3.0")
        implementation("androidx.media3:media3-exoplayer-hls:1.3.0")
        implementation("androidx.media3:media3-ui:1.3.0")
        implementation("androidx.media3:media3-session:1.3.0")
        implementation("androidx.media3:media3-common:1.3.0")
        implementation("androidx.media3:media3-datasource-okhttp:1.3.0")

        // OkHttp & Retrofit
        implementation("com.squareup.okhttp3:okhttp:4.12.0")
        implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
        implementation("com.squareup.retrofit2:retrofit:2.9.0")
        implementation("com.squareup.retrofit2:converter-gson:2.9.0")

        // Room Database
        implementation("androidx.room:room-runtime:2.6.1")
        implementation("androidx.room:room-ktx:2.6.1")
        kapt("androidx.room:room-compiler:2.6.1")

        // WorkManager
        implementation("androidx.work:work-runtime-ktx:2.9.0")
        implementation("androidx.hilt:hilt-work:1.2.0")
        kapt("androidx.hilt:hilt-compiler:1.2.0")

        // Glide (image loading)
        implementation("com.github.bumptech.glide:glide:4.16.0")
        kapt("com.github.bumptech.glide:compiler:4.16.0")

        // Palette (dynamic color from album art)
        implementation("androidx.palette:palette-ktx:1.0.0")

        // Gson
        implementation("com.google.code.gson:gson:2.10.1")

        // Chaquopy Python
        implementation("com.chaquo.python:chaquopy-android:15.0.1")

        // Lottie animations
        implementation("com.airbnb.android:lottie:6.3.0")

        // ViewPager2
        implementation("androidx.viewpager2:viewpager2:1.0.0")
    }
""")

FILES["app/proguard-rules.pro"] = textwrap.dedent("""\
    -keep class com.spofree.player.data.model.** { *; }
    -keep class com.chaquo.python.** { *; }
    -keepattributes *Annotation*
    -keepattributes Signature
    -dontwarn okhttp3.**
    -dontwarn retrofit2.**
""")

# ─────────────────────────────────────────────────────────────
# ANDROID MANIFEST
# ─────────────────────────────────────────────────────────────

FILES["app/src/main/AndroidManifest.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <manifest xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:tools="http://schemas.android.com/tools">

        <uses-permission android:name="android.permission.INTERNET" />
        <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"
            android:maxSdkVersion="32" />
        <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"
            android:maxSdkVersion="29" />
        <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
        <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
        <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />
        <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
        <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
        <uses-permission android:name="android.permission.WAKE_LOCK" />

        <application
            android:name=".SpoFreeApplication"
            android:allowBackup="true"
            android:icon="@mipmap/ic_launcher"
            android:label="@string/app_name"
            android:roundIcon="@mipmap/ic_launcher_round"
            android:supportsRtl="true"
            android:theme="@style/Theme.SpoFree"
            android:largeHeap="true"
            tools:targetApi="31">

            <activity
                android:name=".ui.MainActivity"
                android:exported="true"
                android:windowSoftInputMode="adjustResize"
                android:theme="@style/Theme.SpoFree">
                <intent-filter>
                    <action android:name="android.intent.action.MAIN" />
                    <category android:name="android.intent.category.LAUNCHER" />
                </intent-filter>
            </activity>

            <activity
                android:name=".ui.player.PlayerActivity"
                android:exported="false"
                android:theme="@style/Theme.SpoFree.Player" />

            <service
                android:name=".service.MusicPlayerService"
                android:exported="false"
                android:foregroundServiceType="mediaPlayback" />

            <service
                android:name=".service.DownloadService"
                android:exported="false"
                android:foregroundServiceType="dataSync" />

            <provider
                android:name="androidx.core.content.FileProvider"
                android:authorities="${applicationId}.fileprovider"
                android:exported="false"
                android:grantUriPermissions="true">
                <meta-data
                    android:name="android.support.FILE_PROVIDER_PATHS"
                    android:resource="@xml/file_paths" />
            </provider>

        </application>
    </manifest>
""")

# ─────────────────────────────────────────────────────────────
# KOTLIN SOURCE FILES
# ─────────────────────────────────────────────────────────────

PKG = "app/src/main/java/com/spofree/player"

FILES[f"{PKG}/SpoFreeApplication.kt"] = textwrap.dedent("""\
    package com.spofree.player

    import android.app.Application
    import com.chaquo.python.Python
    import com.chaquo.python.android.AndroidPlatform
    import dagger.hilt.android.HiltAndroidApp
    import timber.log.Timber

    @HiltAndroidApp
    class SpoFreeApplication : Application() {

        override fun onCreate() {
            super.onCreate()
            if (!Python.isStarted()) {
                Python.start(AndroidPlatform(this))
            }
            Timber.plant(Timber.DebugTree())
        }
    }
""")

# ── DATA MODELS ──────────────────────────────────────────────

FILES[f"{PKG}/data/model/Track.kt"] = textwrap.dedent("""\
    package com.spofree.player.data.model

    import androidx.room.Entity
    import androidx.room.PrimaryKey

    @Entity(tableName = "tracks")
    data class Track(
        @PrimaryKey val id: String,
        val title: String,
        val artist: String,
        val albumArtist: String = "",
        val album: String = "",
        val duration: Long = 0L,          // ms
        val trackNumber: Int = 0,
        val discNumber: Int = 1,
        val year: String = "",
        val genre: String = "",
        val isrc: String = "",
        val bpm: Int = 0,
        val coverUrl: String = "",
        val localCoverPath: String = "",
        val streamUrl: String = "",
        val localFilePath: String = "",
        val lyricsLrc: String = "",        // synced LRC
        val lyricsPlain: String = "",
        val isDownloaded: Boolean = false,
        val downloadProgress: Int = 0,
        val fileSize: Long = 0L,
        val bitDepth: Int = 24,
        val sampleRate: Int = 44100,
        val codec: String = "FLAC",
        val addedAt: Long = System.currentTimeMillis()
    )
""")

FILES[f"{PKG}/data/model/Album.kt"] = textwrap.dedent("""\
    package com.spofree.player.data.model

    data class Album(
        val id: String,
        val name: String,
        val artist: String,
        val artistId: String = "",
        val coverUrl: String = "",
        val year: String = "",
        val totalTracks: Int = 0,
        val tracks: List<Track> = emptyList(),
        val upc: String = "",
        val label: String = ""
    )
""")

FILES[f"{PKG}/data/model/Artist.kt"] = textwrap.dedent("""\
    package com.spofree.player.data.model

    data class Artist(
        val id: String,
        val name: String,
        val imageUrl: String = "",
        val genres: List<String> = emptyList(),
        val albums: List<Album> = emptyList()
    )
""")

FILES[f"{PKG}/data/model/SearchResult.kt"] = textwrap.dedent("""\
    package com.spofree.player.data.model

    data class SearchResult(
        val tracks: List<Track> = emptyList(),
        val albums: List<Album> = emptyList(),
        val artists: List<Artist> = emptyList()
    )
""")

FILES[f"{PKG}/data/model/DownloadState.kt"] = textwrap.dedent("""\
    package com.spofree.player.data.model

    sealed class DownloadState {
        object Idle : DownloadState()
        data class Queued(val trackId: String) : DownloadState()
        data class Downloading(val trackId: String, val progress: Int, val speed: String = "") : DownloadState()
        data class Processing(val trackId: String, val step: String) : DownloadState()
        data class Completed(val trackId: String, val filePath: String) : DownloadState()
        data class Failed(val trackId: String, val error: String) : DownloadState()
    }
""")

FILES[f"{PKG}/data/model/PlaybackState.kt"] = textwrap.dedent("""\
    package com.spofree.player.data.model

    enum class RepeatMode { OFF, ONE, ALL }

    data class PlaybackState(
        val track: Track? = null,
        val isPlaying: Boolean = false,
        val position: Long = 0L,
        val duration: Long = 0L,
        val repeatMode: RepeatMode = RepeatMode.OFF,
        val isShuffled: Boolean = false,
        val buffering: Boolean = false,
        val error: String? = null
    )
""")

# ── DATABASE ──────────────────────────────────────────────────

FILES[f"{PKG}/data/db/SpoFreeDatabase.kt"] = textwrap.dedent("""\
    package com.spofree.player.data.db

    import androidx.room.Database
    import androidx.room.RoomDatabase
    import com.spofree.player.data.model.Track

    @Database(entities = [Track::class], version = 1, exportSchema = false)
    abstract class SpoFreeDatabase : RoomDatabase() {
        abstract fun trackDao(): TrackDao
    }
""")

FILES[f"{PKG}/data/db/TrackDao.kt"] = textwrap.dedent("""\
    package com.spofree.player.data.db

    import androidx.room.*
    import com.spofree.player.data.model.Track
    import kotlinx.coroutines.flow.Flow

    @Dao
    interface TrackDao {
        @Query("SELECT * FROM tracks ORDER BY addedAt DESC")
        fun getAllTracks(): Flow<List<Track>>

        @Query("SELECT * FROM tracks WHERE isDownloaded = 1 ORDER BY addedAt DESC")
        fun getDownloadedTracks(): Flow<List<Track>>

        @Query("SELECT * FROM tracks WHERE id = :id")
        suspend fun getTrackById(id: String): Track?

        @Insert(onConflict = OnConflictStrategy.REPLACE)
        suspend fun insertTrack(track: Track)

        @Insert(onConflict = OnConflictStrategy.REPLACE)
        suspend fun insertTracks(tracks: List<Track>)

        @Update
        suspend fun updateTrack(track: Track)

        @Delete
        suspend fun deleteTrack(track: Track)

        @Query("DELETE FROM tracks WHERE id = :id")
        suspend fun deleteTrackById(id: String)

        @Query("SELECT * FROM tracks WHERE title LIKE '%' || :query || '%' OR artist LIKE '%' || :query || '%'")
        suspend fun searchTracks(query: String): List<Track>

        @Query("UPDATE tracks SET downloadProgress = :progress WHERE id = :id")
        suspend fun updateProgress(id: String, progress: Int)

        @Query("UPDATE tracks SET isDownloaded = :downloaded, localFilePath = :path WHERE id = :id")
        suspend fun updateDownloadStatus(id: String, downloaded: Boolean, path: String)
    }
""")

# ── PYTHON BRIDGE ─────────────────────────────────────────────

FILES[f"{PKG}/data/python/PythonBridge.kt"] = textwrap.dedent("""\
    package com.spofree.player.data.python

    import android.content.Context
    import com.chaquo.python.PyException
    import com.chaquo.python.Python
    import com.spofree.player.data.model.Track
    import com.spofree.player.data.model.Album
    import com.spofree.player.data.model.Artist
    import com.spofree.player.data.model.SearchResult
    import com.google.gson.Gson
    import com.google.gson.reflect.TypeToken
    import kotlinx.coroutines.Dispatchers
    import kotlinx.coroutines.withContext
    import javax.inject.Inject
    import javax.inject.Singleton

    @Singleton
    class PythonBridge @Inject constructor(
        private val context: Context,
        private val gson: Gson
    ) {
        private val py by lazy { Python.getInstance() }
        private val spoModule by lazy { py.getModule("spofree_bridge") }

        /**
         * Search for tracks, albums, and artists.
         */
        suspend fun search(query: String): Result<SearchResult> = withContext(Dispatchers.IO) {
            runCatching {
                val json = spoModule.callAttr("search", query).toString()
                gson.fromJson(json, SearchResult::class.java)
            }
        }

        /**
         * Get full album details including track list.
         */
        suspend fun getAlbum(albumId: String): Result<Album> = withContext(Dispatchers.IO) {
            runCatching {
                val json = spoModule.callAttr("get_album", albumId).toString()
                gson.fromJson(json, Album::class.java)
            }
        }

        /**
         * Get a direct FLAC stream URL for a track.
         */
        suspend fun getStreamUrl(trackId: String): Result<String> = withContext(Dispatchers.IO) {
            runCatching {
                spoModule.callAttr("get_stream_url", trackId).toString()
            }
        }

        /**
         * Download a track as FLAC with full metadata embedding.
         * Calls back progressCallback(trackId, progressInt, speedStr)
         */
        suspend fun downloadTrack(
            trackId: String,
            outputDir: String,
            progressCallback: (Int, String) -> Unit
        ): Result<String> = withContext(Dispatchers.IO) {
            runCatching {
                // Register a Python-callable progress hook
                val hook = py.getBuiltins().callAttr(
                    "eval",
                    "lambda p, s: None"  // placeholder; real one wired below
                )
                val result = spoModule.callAttr(
                    "download_track_flac",
                    trackId,
                    outputDir
                )
                // poll status file until complete
                var lastProgress = 0
                while (true) {
                    val status = spoModule.callAttr("get_download_status", trackId)
                    val statusMap = gson.fromJson<Map<String, Any>>(
                        status.toString(),
                        object : TypeToken<Map<String, Any>>() {}.type
                    )
                    val progress = (statusMap["progress"] as? Double)?.toInt() ?: 0
                    val speed = statusMap["speed"] as? String ?: ""
                    val done = statusMap["done"] as? Boolean ?: false
                    val error = statusMap["error"] as? String

                    if (progress != lastProgress) {
                        progressCallback(progress, speed)
                        lastProgress = progress
                    }
                    if (done) break
                    if (error != null) throw Exception(error)
                    kotlinx.coroutines.delay(500)
                }
                spoModule.callAttr("get_output_path", trackId).toString()
            }
        }

        /**
         * Fetch synced LRC lyrics for a track.
         */
        suspend fun getLyrics(
            title: String,
            artist: String,
            duration: Long
        ): Result<Pair<String, String>> = withContext(Dispatchers.IO) {
            runCatching {
                val json = spoModule.callAttr("get_lyrics", title, artist, duration.toString()).toString()
                val map = gson.fromJson<Map<String, String>>(
                    json,
                    object : TypeToken<Map<String, String>>() {}.type
                )
                Pair(map["lrc"] ?: "", map["plain"] ?: "")
            }
        }

        /**
         * Extract cover art from a local FLAC file and return path to extracted PNG.
         */
        suspend fun extractCoverArt(flacPath: String, outDir: String): Result<String> =
            withContext(Dispatchers.IO) {
                runCatching {
                    spoModule.callAttr("extract_cover_art", flacPath, outDir).toString()
                }
            }
    }
""")

# ── REPOSITORY ────────────────────────────────────────────────

FILES[f"{PKG}/data/repository/MusicRepository.kt"] = textwrap.dedent("""\
    package com.spofree.player.data.repository

    import com.spofree.player.data.db.TrackDao
    import com.spofree.player.data.model.*
    import com.spofree.player.data.python.PythonBridge
    import kotlinx.coroutines.flow.Flow
    import javax.inject.Inject
    import javax.inject.Singleton

    @Singleton
    class MusicRepository @Inject constructor(
        private val trackDao: TrackDao,
        private val pythonBridge: PythonBridge
    ) {

        fun getAllTracks(): Flow<List<Track>> = trackDao.getAllTracks()
        fun getDownloadedTracks(): Flow<List<Track>> = trackDao.getDownloadedTracks()

        suspend fun getTrackById(id: String): Track? = trackDao.getTrackById(id)

        suspend fun search(query: String): Result<SearchResult> = pythonBridge.search(query)

        suspend fun getAlbum(albumId: String): Result<Album> = pythonBridge.getAlbum(albumId)

        suspend fun getStreamUrl(trackId: String): Result<String> =
            pythonBridge.getStreamUrl(trackId)

        suspend fun downloadTrack(
            trackId: String,
            outputDir: String,
            progressCallback: (Int, String) -> Unit
        ): Result<String> = pythonBridge.downloadTrack(trackId, outputDir, progressCallback)

        suspend fun getLyrics(
            title: String,
            artist: String,
            duration: Long
        ): Result<Pair<String, String>> = pythonBridge.getLyrics(title, artist, duration)

        suspend fun saveTrack(track: Track) = trackDao.insertTrack(track)
        suspend fun updateTrack(track: Track) = trackDao.updateTrack(track)
        suspend fun deleteTrack(track: Track) = trackDao.deleteTrack(track)
        suspend fun updateProgress(id: String, progress: Int) = trackDao.updateProgress(id, progress)
        suspend fun updateDownloadStatus(id: String, downloaded: Boolean, path: String) =
            trackDao.updateDownloadStatus(id, downloaded, path)

        suspend fun searchLocal(query: String): List<Track> = trackDao.searchTracks(query)
    }
""")

# ── DI ────────────────────────────────────────────────────────

FILES[f"{PKG}/di/AppModule.kt"] = textwrap.dedent("""\
    package com.spofree.player.di

    import android.content.Context
    import androidx.room.Room
    import com.google.gson.Gson
    import com.google.gson.GsonBuilder
    import com.spofree.player.data.db.SpoFreeDatabase
    import com.spofree.player.data.db.TrackDao
    import dagger.Module
    import dagger.Provides
    import dagger.hilt.InstallIn
    import dagger.hilt.android.qualifiers.ApplicationContext
    import dagger.hilt.components.SingletonComponent
    import javax.inject.Singleton

    @Module
    @InstallIn(SingletonComponent::class)
    object AppModule {

        @Provides
        @Singleton
        fun provideDatabase(@ApplicationContext ctx: Context): SpoFreeDatabase =
            Room.databaseBuilder(ctx, SpoFreeDatabase::class.java, "spofree.db")
                .fallbackToDestructiveMigration()
                .build()

        @Provides
        @Singleton
        fun provideTrackDao(db: SpoFreeDatabase): TrackDao = db.trackDao()

        @Provides
        @Singleton
        fun provideGson(): Gson = GsonBuilder().setLenient().create()

        @Provides
        @Singleton
        fun provideContext(@ApplicationContext ctx: Context): Context = ctx
    }
""")

# ── PLAYER SERVICE ────────────────────────────────────────────

FILES[f"{PKG}/service/MusicPlayerService.kt"] = textwrap.dedent("""\
    package com.spofree.player.service

    import android.app.*
    import android.content.Intent
    import android.os.Binder
    import android.os.IBinder
    import androidx.core.app.NotificationCompat
    import androidx.media3.common.*
    import androidx.media3.exoplayer.ExoPlayer
    import androidx.media3.session.MediaSession
    import com.spofree.player.R
    import com.spofree.player.data.model.PlaybackState
    import com.spofree.player.data.model.RepeatMode
    import com.spofree.player.data.model.Track
    import com.spofree.player.ui.player.PlayerActivity
    import dagger.hilt.android.AndroidEntryPoint
    import kotlinx.coroutines.*
    import kotlinx.coroutines.flow.MutableStateFlow
    import kotlinx.coroutines.flow.StateFlow
    import kotlinx.coroutines.flow.asStateFlow

    @AndroidEntryPoint
    class MusicPlayerService : Service() {

        companion object {
            const val CHANNEL_ID = "spofree_playback"
            const val NOTIFICATION_ID = 1001
            const val ACTION_PLAY = "ACTION_PLAY"
            const val ACTION_PAUSE = "ACTION_PAUSE"
            const val ACTION_NEXT = "ACTION_NEXT"
            const val ACTION_PREV = "ACTION_PREV"
            const val ACTION_STOP = "ACTION_STOP"
        }

        inner class LocalBinder : Binder() {
            fun getService(): MusicPlayerService = this@MusicPlayerService
        }

        private val binder = LocalBinder()
        private lateinit var exoPlayer: ExoPlayer
        private lateinit var mediaSession: MediaSession
        private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

        private val _playbackState = MutableStateFlow(PlaybackState())
        val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

        private var queue: MutableList<Track> = mutableListOf()
        private var currentIndex: Int = 0
        private var positionUpdateJob: Job? = null

        override fun onCreate() {
            super.onCreate()
            createNotificationChannel()
            initExoPlayer()
        }

        private fun initExoPlayer() {
            exoPlayer = ExoPlayer.Builder(this)
                .setHandleAudioBecomingNoisy(true)
                .build()

            mediaSession = MediaSession.Builder(this, exoPlayer).build()

            exoPlayer.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    updatePlaybackState()
                    if (state == Player.STATE_ENDED) playNext()
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    updatePlaybackState()
                    if (isPlaying) startPositionUpdates() else stopPositionUpdates()
                }

                override fun onPlayerError(error: PlaybackException) {
                    _playbackState.value = _playbackState.value.copy(
                        error = error.message,
                        isPlaying = false
                    )
                }
            })
        }

        fun playTrack(track: Track, queueList: List<Track> = listOf(track)) {
            queue = queueList.toMutableList()
            currentIndex = queue.indexOf(track).coerceAtLeast(0)
            loadAndPlay(track)
        }

        private fun loadAndPlay(track: Track) {
            val uri = when {
                track.isDownloaded && track.localFilePath.isNotEmpty() ->
                    android.net.Uri.parse("file://${track.localFilePath}")
                track.streamUrl.isNotEmpty() ->
                    android.net.Uri.parse(track.streamUrl)
                else -> return
            }
            val mediaItem = MediaItem.Builder()
                .setUri(uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(track.title)
                        .setArtist(track.artist)
                        .setAlbumTitle(track.album)
                        .setTrackNumber(track.trackNumber)
                        .build()
                )
                .build()

            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.prepare()
            exoPlayer.play()

            _playbackState.value = _playbackState.value.copy(track = track, error = null)
            updateNotification(track)
        }

        fun playNext() {
            if (currentIndex < queue.size - 1) {
                currentIndex++
                loadAndPlay(queue[currentIndex])
            } else if (_playbackState.value.repeatMode == RepeatMode.ALL) {
                currentIndex = 0
                loadAndPlay(queue[currentIndex])
            }
        }

        fun playPrevious() {
            if (exoPlayer.currentPosition > 3000) {
                exoPlayer.seekTo(0)
            } else if (currentIndex > 0) {
                currentIndex--
                loadAndPlay(queue[currentIndex])
            }
        }

        fun togglePlayPause() {
            if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
        }

        fun seekTo(positionMs: Long) {
            exoPlayer.seekTo(positionMs)
            updatePlaybackState()
        }

        fun setRepeatMode(mode: RepeatMode) {
            exoPlayer.repeatMode = when (mode) {
                RepeatMode.OFF -> Player.REPEAT_MODE_OFF
                RepeatMode.ONE -> Player.REPEAT_MODE_ONE
                RepeatMode.ALL -> Player.REPEAT_MODE_ALL
            }
            _playbackState.value = _playbackState.value.copy(repeatMode = mode)
        }

        fun toggleShuffle() {
            exoPlayer.shuffleModeEnabled = !exoPlayer.shuffleModeEnabled
            _playbackState.value = _playbackState.value.copy(
                isShuffled = exoPlayer.shuffleModeEnabled
            )
        }

        private fun updatePlaybackState() {
            _playbackState.value = _playbackState.value.copy(
                isPlaying = exoPlayer.isPlaying,
                position = exoPlayer.currentPosition,
                duration = exoPlayer.duration.coerceAtLeast(0L),
                buffering = exoPlayer.playbackState == Player.STATE_BUFFERING
            )
        }

        private fun startPositionUpdates() {
            positionUpdateJob?.cancel()
            positionUpdateJob = serviceScope.launch {
                while (true) {
                    delay(500)
                    updatePlaybackState()
                }
            }
        }

        private fun stopPositionUpdates() {
            positionUpdateJob?.cancel()
        }

        private fun createNotificationChannel() {
            val channel = NotificationChannel(
                CHANNEL_ID, "Music Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "SpoFree audio playback"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        private fun updateNotification(track: Track) {
            val intent = Intent(this, PlayerActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(track.title)
                .setContentText(track.artist)
                .setSmallIcon(R.drawable.ic_music_note)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setSilent(true)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .build()

            startForeground(NOTIFICATION_ID, notification)
        }

        override fun onBind(intent: Intent): IBinder = binder

        override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
            when (intent?.action) {
                ACTION_PLAY -> exoPlayer.play()
                ACTION_PAUSE -> exoPlayer.pause()
                ACTION_NEXT -> playNext()
                ACTION_PREV -> playPrevious()
                ACTION_STOP -> { stopSelf() }
            }
            return START_STICKY
        }

        override fun onDestroy() {
            super.onDestroy()
            mediaSession.release()
            exoPlayer.release()
            serviceScope.cancel()
        }
    }
""")

# ── DOWNLOAD SERVICE ──────────────────────────────────────────

FILES[f"{PKG}/service/DownloadService.kt"] = textwrap.dedent("""\
    package com.spofree.player.service

    import android.app.*
    import android.content.Intent
    import android.os.IBinder
    import androidx.core.app.NotificationCompat
    import com.spofree.player.R
    import com.spofree.player.data.model.DownloadState
    import com.spofree.player.data.repository.MusicRepository
    import dagger.hilt.android.AndroidEntryPoint
    import kotlinx.coroutines.*
    import kotlinx.coroutines.flow.MutableSharedFlow
    import kotlinx.coroutines.flow.SharedFlow
    import javax.inject.Inject

    @AndroidEntryPoint
    class DownloadService : Service() {

        companion object {
            const val CHANNEL_ID = "spofree_download"
            const val NOTIFICATION_ID = 2001
            const val EXTRA_TRACK_ID = "track_id"
            const val EXTRA_OUTPUT_DIR = "output_dir"

            val downloadEvents = MutableSharedFlow<DownloadState>(extraBufferCapacity = 32)
        }

        @Inject lateinit var repository: MusicRepository

        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        private val downloadQueue = ArrayDeque<Pair<String, String>>()
        private var isProcessing = false

        override fun onCreate() {
            super.onCreate()
            createNotificationChannel()
        }

        override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
            val trackId = intent?.getStringExtra(EXTRA_TRACK_ID) ?: return START_NOT_STICKY
            val outDir = intent.getStringExtra(EXTRA_OUTPUT_DIR) ?: filesDir.absolutePath

            downloadQueue.addLast(Pair(trackId, outDir))
            if (!isProcessing) processQueue()
            return START_STICKY
        }

        private fun processQueue() {
            if (downloadQueue.isEmpty()) {
                isProcessing = false
                stopSelf()
                return
            }
            isProcessing = true
            val (trackId, outDir) = downloadQueue.removeFirst()

            scope.launch {
                downloadEvents.emit(DownloadState.Queued(trackId))
                showNotification("Preparing download…", 0)

                val result = repository.downloadTrack(trackId, outDir) { progress, speed ->
                    runBlocking {
                        downloadEvents.emit(DownloadState.Downloading(trackId, progress, speed))
                        showNotification("Downloading… $speed", progress)
                        repository.updateProgress(trackId, progress)
                    }
                }

                result.onSuccess { filePath ->
                    downloadEvents.emit(DownloadState.Completed(trackId, filePath))
                    repository.updateDownloadStatus(trackId, true, filePath)
                    showNotification("Download complete", 100)
                }.onFailure { err ->
                    downloadEvents.emit(DownloadState.Failed(trackId, err.message ?: "Unknown error"))
                    showNotification("Download failed: ${err.message}", 0)
                }

                processQueue()
            }
        }

        private fun createNotificationChannel() {
            val channel = NotificationChannel(
                CHANNEL_ID, "Downloads",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        private fun showNotification(text: String, progress: Int) {
            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("SpoFree Download")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_download)
                .setProgress(100, progress, progress == 0)
                .setOngoing(true)
                .setSilent(true)
                .build()
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, notification)
        }

        override fun onBind(intent: Intent?): IBinder? = null

        override fun onDestroy() {
            super.onDestroy()
            scope.cancel()
        }
    }
""")

# ── VIEWMODELS ────────────────────────────────────────────────

FILES[f"{PKG}/ui/viewmodel/SearchViewModel.kt"] = textwrap.dedent("""\
    package com.spofree.player.ui.viewmodel

    import androidx.lifecycle.ViewModel
    import androidx.lifecycle.viewModelScope
    import com.spofree.player.data.model.SearchResult
    import com.spofree.player.data.repository.MusicRepository
    import dagger.hilt.android.lifecycle.HiltViewModel
    import kotlinx.coroutines.flow.*
    import kotlinx.coroutines.launch
    import javax.inject.Inject

    sealed class SearchUiState {
        object Idle : SearchUiState()
        object Loading : SearchUiState()
        data class Success(val result: SearchResult) : SearchUiState()
        data class Error(val message: String) : SearchUiState()
    }

    @HiltViewModel
    class SearchViewModel @Inject constructor(
        private val repository: MusicRepository
    ) : ViewModel() {

        private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
        val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

        private val _query = MutableStateFlow("")

        init {
            _query
                .debounce(400)
                .filter { it.length >= 2 }
                .distinctUntilChanged()
                .onEach { search(it) }
                .launchIn(viewModelScope)
        }

        fun onQueryChanged(q: String) { _query.value = q }

        fun search(query: String) {
            viewModelScope.launch {
                _uiState.value = SearchUiState.Loading
                repository.search(query)
                    .onSuccess { _uiState.value = SearchUiState.Success(it) }
                    .onFailure { _uiState.value = SearchUiState.Error(it.message ?: "Search failed") }
            }
        }
    }
""")

FILES[f"{PKG}/ui/viewmodel/PlayerViewModel.kt"] = textwrap.dedent("""\
    package com.spofree.player.ui.viewmodel

    import androidx.lifecycle.ViewModel
    import androidx.lifecycle.viewModelScope
    import com.spofree.player.data.model.*
    import com.spofree.player.data.repository.MusicRepository
    import com.spofree.player.service.MusicPlayerService
    import dagger.hilt.android.lifecycle.HiltViewModel
    import kotlinx.coroutines.flow.*
    import kotlinx.coroutines.launch
    import javax.inject.Inject

    @HiltViewModel
    class PlayerViewModel @Inject constructor(
        private val repository: MusicRepository
    ) : ViewModel() {

        private val _currentTrack = MutableStateFlow<Track?>(null)
        val currentTrack: StateFlow<Track?> = _currentTrack.asStateFlow()

        private val _lyrics = MutableStateFlow<Pair<String, String>>("" to "")
        val lyrics: StateFlow<Pair<String, String>> = _lyrics.asStateFlow()

        private var playerService: MusicPlayerService? = null

        val playbackState: StateFlow<PlaybackState>
            get() = playerService?.playbackState ?: MutableStateFlow(PlaybackState())

        fun bindService(service: MusicPlayerService) {
            playerService = service
        }

        fun playTrack(track: Track, queue: List<Track> = listOf(track)) {
            _currentTrack.value = track
            playerService?.playTrack(track, queue)
            loadLyrics(track)
        }

        private fun loadLyrics(track: Track) {
            viewModelScope.launch {
                repository.getLyrics(track.title, track.artist, track.duration)
                    .onSuccess { _lyrics.value = it }
                    .onFailure { _lyrics.value = "" to "" }
            }
        }

        fun togglePlayPause() = playerService?.togglePlayPause()
        fun seekTo(pos: Long) = playerService?.seekTo(pos)
        fun playNext() = playerService?.playNext()
        fun playPrevious() = playerService?.playPrevious()
        fun setRepeatMode(mode: RepeatMode) = playerService?.setRepeatMode(mode)
        fun toggleShuffle() = playerService?.toggleShuffle()
    }
""")

FILES[f"{PKG}/ui/viewmodel/LibraryViewModel.kt"] = textwrap.dedent("""\
    package com.spofree.player.ui.viewmodel

    import androidx.lifecycle.ViewModel
    import androidx.lifecycle.viewModelScope
    import com.spofree.player.data.model.Track
    import com.spofree.player.data.repository.MusicRepository
    import dagger.hilt.android.lifecycle.HiltViewModel
    import kotlinx.coroutines.flow.*
    import kotlinx.coroutines.launch
    import javax.inject.Inject

    @HiltViewModel
    class LibraryViewModel @Inject constructor(
        private val repository: MusicRepository
    ) : ViewModel() {

        val downloadedTracks: StateFlow<List<Track>> =
            repository.getDownloadedTracks()
                .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        val allTracks: StateFlow<List<Track>> =
            repository.getAllTracks()
                .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        fun deleteTrack(track: Track) {
            viewModelScope.launch {
                track.localFilePath.let { path ->
                    if (path.isNotEmpty()) java.io.File(path).delete()
                }
                repository.deleteTrack(track)
            }
        }
    }
""")

FILES[f"{PKG}/ui/viewmodel/DownloadViewModel.kt"] = textwrap.dedent("""\
    package com.spofree.player.ui.viewmodel

    import android.content.Context
    import android.content.Intent
    import androidx.lifecycle.ViewModel
    import androidx.lifecycle.viewModelScope
    import com.spofree.player.data.model.DownloadState
    import com.spofree.player.data.model.Track
    import com.spofree.player.data.repository.MusicRepository
    import com.spofree.player.service.DownloadService
    import dagger.hilt.android.lifecycle.HiltViewModel
    import dagger.hilt.android.qualifiers.ApplicationContext
    import kotlinx.coroutines.flow.*
    import kotlinx.coroutines.launch
    import javax.inject.Inject

    @HiltViewModel
    class DownloadViewModel @Inject constructor(
        @ApplicationContext private val context: Context,
        private val repository: MusicRepository
    ) : ViewModel() {

        val downloadEvents: SharedFlow<DownloadState> = DownloadService.downloadEvents

        private val _activeDownloads = MutableStateFlow<Map<String, DownloadState>>(emptyMap())
        val activeDownloads: StateFlow<Map<String, DownloadState>> = _activeDownloads.asStateFlow()

        init {
            viewModelScope.launch {
                DownloadService.downloadEvents.collect { state ->
                    _activeDownloads.update { current ->
                        when (state) {
                            is DownloadState.Completed, is DownloadState.Failed ->
                                current - getTrackId(state)
                            else -> current + (getTrackId(state) to state)
                        }
                    }
                }
            }
        }

        fun downloadTrack(track: Track) {
            viewModelScope.launch {
                repository.saveTrack(track)
            }
            val outDir = context.getExternalFilesDir("Music")?.absolutePath
                ?: context.filesDir.absolutePath

            val intent = Intent(context, DownloadService::class.java).apply {
                putExtra(DownloadService.EXTRA_TRACK_ID, track.id)
                putExtra(DownloadService.EXTRA_OUTPUT_DIR, outDir)
            }
            context.startForegroundService(intent)
        }

        private fun getTrackId(state: DownloadState): String = when (state) {
            is DownloadState.Queued -> state.trackId
            is DownloadState.Downloading -> state.trackId
            is DownloadState.Processing -> state.trackId
            is DownloadState.Completed -> state.trackId
            is DownloadState.Failed -> state.trackId
            else -> ""
        }
    }
""")

# ── MAIN ACTIVITY ─────────────────────────────────────────────

FILES[f"{PKG}/ui/MainActivity.kt"] = textwrap.dedent("""\
    package com.spofree.player.ui

    import android.os.Bundle
    import androidx.activity.viewModels
    import androidx.appcompat.app.AppCompatActivity
    import androidx.navigation.fragment.NavHostFragment
    import androidx.navigation.ui.setupWithNavController
    import com.spofree.player.R
    import com.spofree.player.databinding.ActivityMainBinding
    import dagger.hilt.android.AndroidEntryPoint

    @AndroidEntryPoint
    class MainActivity : AppCompatActivity() {

        private lateinit var binding: ActivityMainBinding

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            binding = ActivityMainBinding.inflate(layoutInflater)
            setContentView(binding.root)

            val navHost = supportFragmentManager
                .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
            val navController = navHost.navController
            binding.bottomNav.setupWithNavController(navController)
        }
    }
""")

# ── SEARCH FRAGMENT ───────────────────────────────────────────

FILES[f"{PKG}/ui/search/SearchFragment.kt"] = textwrap.dedent("""\
    package com.spofree.player.ui.search

    import android.os.Bundle
    import android.view.*
    import androidx.core.widget.doOnTextChanged
    import androidx.fragment.app.Fragment
    import androidx.fragment.app.viewModels
    import androidx.lifecycle.lifecycleScope
    import androidx.recyclerview.widget.LinearLayoutManager
    import com.spofree.player.databinding.FragmentSearchBinding
    import com.spofree.player.ui.viewmodel.SearchUiState
    import com.spofree.player.ui.viewmodel.SearchViewModel
    import com.spofree.player.ui.viewmodel.DownloadViewModel
    import dagger.hilt.android.AndroidEntryPoint
    import kotlinx.coroutines.launch

    @AndroidEntryPoint
    class SearchFragment : Fragment() {

        private var _binding: FragmentSearchBinding? = null
        private val binding get() = _binding!!
        private val viewModel: SearchViewModel by viewModels()
        private val downloadViewModel: DownloadViewModel by viewModels()
        private lateinit var trackAdapter: TrackResultAdapter

        override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
        ) = FragmentSearchBinding.inflate(inflater, container, false).also { _binding = it }.root

        override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
            super.onViewCreated(view, savedInstanceState)

            trackAdapter = TrackResultAdapter(
                onPlay = { track ->
                    // launch player
                },
                onDownload = { track ->
                    downloadViewModel.downloadTrack(track)
                }
            )

            binding.rvResults.apply {
                layoutManager = LinearLayoutManager(requireContext())
                adapter = trackAdapter
            }

            binding.etSearch.doOnTextChanged { text, _, _, _ ->
                viewModel.onQueryChanged(text.toString())
            }

            viewLifecycleOwner.lifecycleScope.launch {
                viewModel.uiState.collect { state ->
                    when (state) {
                        is SearchUiState.Idle -> binding.progressBar.visibility = View.GONE
                        is SearchUiState.Loading -> binding.progressBar.visibility = View.VISIBLE
                        is SearchUiState.Success -> {
                            binding.progressBar.visibility = View.GONE
                            trackAdapter.submitList(state.result.tracks)
                        }
                        is SearchUiState.Error -> {
                            binding.progressBar.visibility = View.GONE
                        }
                    }
                }
            }
        }

        override fun onDestroyView() {
            super.onDestroyView()
            _binding = null
        }
    }
""")

FILES[f"{PKG}/ui/search/TrackResultAdapter.kt"] = textwrap.dedent("""\
    package com.spofree.player.ui.search

    import android.view.*
    import androidx.recyclerview.widget.DiffUtil
    import androidx.recyclerview.widget.ListAdapter
    import androidx.recyclerview.widget.RecyclerView
    import com.bumptech.glide.Glide
    import com.spofree.player.data.model.Track
    import com.spofree.player.databinding.ItemTrackBinding
    import java.util.concurrent.TimeUnit

    class TrackResultAdapter(
        private val onPlay: (Track) -> Unit,
        private val onDownload: (Track) -> Unit
    ) : ListAdapter<Track, TrackResultAdapter.ViewHolder>(DIFF) {

        companion object {
            val DIFF = object : DiffUtil.ItemCallback<Track>() {
                override fun areItemsTheSame(a: Track, b: Track) = a.id == b.id
                override fun areContentsTheSame(a: Track, b: Track) = a == b
            }
        }

        inner class ViewHolder(val binding: ItemTrackBinding) :
            RecyclerView.ViewHolder(binding.root) {

            fun bind(track: Track) {
                binding.tvTitle.text = track.title
                binding.tvArtist.text = "${track.artist} • ${formatDuration(track.duration)}"
                binding.tvCodec.text = track.codec

                Glide.with(binding.ivCover)
                    .load(track.coverUrl)
                    .placeholder(com.spofree.player.R.drawable.ic_album_placeholder)
                    .into(binding.ivCover)

                binding.btnPlay.setOnClickListener { onPlay(track) }
                binding.btnDownload.setOnClickListener { onDownload(track) }
                binding.root.setOnClickListener { onPlay(track) }
            }
        }

        private fun formatDuration(ms: Long): String {
            val min = TimeUnit.MILLISECONDS.toMinutes(ms)
            val sec = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
            return "%d:%02d".format(min, sec)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            ViewHolder(ItemTrackBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(holder: ViewHolder, position: Int) =
            holder.bind(getItem(position))
    }
""")

# ── PLAYER ACTIVITY ───────────────────────────────────────────

FILES[f"{PKG}/ui/player/PlayerActivity.kt"] = textwrap.dedent("""\
    package com.spofree.player.ui.player

    import android.content.*
    import android.os.Bundle
    import android.os.IBinder
    import androidx.activity.viewModels
    import androidx.appcompat.app.AppCompatActivity
    import androidx.lifecycle.lifecycleScope
    import androidx.palette.graphics.Palette
    import com.bumptech.glide.Glide
    import com.bumptech.glide.load.resource.bitmap.RoundedCorners
    import com.bumptech.glide.request.target.CustomTarget
    import com.bumptech.glide.request.transition.Transition
    import android.graphics.Bitmap
    import android.graphics.drawable.GradientDrawable
    import com.spofree.player.data.model.RepeatMode
    import com.spofree.player.data.model.Track
    import com.spofree.player.databinding.ActivityPlayerBinding
    import com.spofree.player.service.MusicPlayerService
    import com.spofree.player.ui.viewmodel.PlayerViewModel
    import dagger.hilt.android.AndroidEntryPoint
    import kotlinx.coroutines.launch

    @AndroidEntryPoint
    class PlayerActivity : AppCompatActivity() {

        companion object {
            const val EXTRA_TRACK = "extra_track"
        }

        private lateinit var binding: ActivityPlayerBinding
        private val viewModel: PlayerViewModel by viewModels()
        private var playerService: MusicPlayerService? = null
        private var isBound = false

        private val serviceConnection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                val lb = binder as MusicPlayerService.LocalBinder
                playerService = lb.getService()
                isBound = true
                viewModel.bindService(playerService!!)
                observePlaybackState()

                @Suppress("DEPRECATION")
                val track = intent.getParcelableExtra<Track>(EXTRA_TRACK)
                track?.let { viewModel.playTrack(it) }
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                isBound = false
            }
        }

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            binding = ActivityPlayerBinding.inflate(layoutInflater)
            setContentView(binding.root)
            setupControls()
            bindPlayerService()
        }

        private fun bindPlayerService() {
            Intent(this, MusicPlayerService::class.java).also { intent ->
                bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
            }
        }

        private fun setupControls() {
            binding.btnPlayPause.setOnClickListener { viewModel.togglePlayPause() }
            binding.btnNext.setOnClickListener { viewModel.playNext() }
            binding.btnPrevious.setOnClickListener { viewModel.playPrevious() }
            binding.btnShuffle.setOnClickListener { viewModel.toggleShuffle() }
            binding.btnRepeat.setOnClickListener {
                val current = viewModel.playbackState.value.repeatMode
                viewModel.setRepeatMode(
                    when (current) {
                        RepeatMode.OFF -> RepeatMode.ALL
                        RepeatMode.ALL -> RepeatMode.ONE
                        RepeatMode.ONE -> RepeatMode.OFF
                    }
                )
            }
            binding.seekBar.setOnSeekBarChangeListener(object :
                android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val pos = (p.toLong() * viewModel.playbackState.value.duration) / 100
                        viewModel.seekTo(pos)
                    }
                }
                override fun onStartTrackingTouch(sb: android.widget.SeekBar) {}
                override fun onStopTrackingTouch(sb: android.widget.SeekBar) {}
            })

            binding.btnBack.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        }

        private fun observePlaybackState() {
            lifecycleScope.launch {
                viewModel.currentTrack.collect { track ->
                    track?.let { updateTrackUI(it) }
                }
            }
            lifecycleScope.launch {
                viewModel.playbackState.collect { state ->
                    binding.btnPlayPause.isSelected = state.isPlaying
                    val duration = state.duration.coerceAtLeast(1L)
                    binding.seekBar.progress = ((state.position * 100) / duration).toInt()
                    binding.tvPosition.text = formatMs(state.position)
                    binding.tvDuration.text = formatMs(duration)
                }
            }
        }

        private fun updateTrackUI(track: Track) {
            binding.tvTitle.text = track.title
            binding.tvArtist.text = track.artist
            binding.tvAlbum.text = track.album
            binding.tvQuality.text = "${track.codec} • ${track.sampleRate / 1000}kHz / ${track.bitDepth}bit"

            Glide.with(this)
                .asBitmap()
                .load(if (track.localCoverPath.isNotEmpty()) track.localCoverPath else track.coverUrl)
                .transform(RoundedCorners(24))
                .into(object : CustomTarget<Bitmap>() {
                    override fun onResourceReady(bm: Bitmap, t: Transition<in Bitmap>?) {
                        binding.ivAlbumArt.setImageBitmap(bm)
                        Palette.from(bm).generate { palette ->
                            palette?.dominantSwatch?.rgb?.let { color ->
                                val bg = GradientDrawable(
                                    GradientDrawable.Orientation.TOP_BOTTOM,
                                    intArrayOf(color, 0xFF0A0A0A.toInt())
                                )
                                binding.root.background = bg
                            }
                        }
                    }
                    override fun onLoadCleared(p: android.graphics.drawable.Drawable?) {}
                })
        }

        private fun formatMs(ms: Long): String {
            val min = ms / 60000
            val sec = (ms % 60000) / 1000
            return "%d:%02d".format(min, sec)
        }

        override fun onDestroy() {
            super.onDestroy()
            if (isBound) unbindService(serviceConnection)
        }
    }
""")

# ── LIBRARY FRAGMENT ──────────────────────────────────────────

FILES[f"{PKG}/ui/library/LibraryFragment.kt"] = textwrap.dedent("""\
    package com.spofree.player.ui.library

    import android.os.Bundle
    import android.view.*
    import androidx.fragment.app.Fragment
    import androidx.fragment.app.viewModels
    import androidx.lifecycle.lifecycleScope
    import androidx.recyclerview.widget.LinearLayoutManager
    import com.spofree.player.databinding.FragmentLibraryBinding
    import com.spofree.player.ui.viewmodel.LibraryViewModel
    import dagger.hilt.android.AndroidEntryPoint
    import kotlinx.coroutines.launch

    @AndroidEntryPoint
    class LibraryFragment : Fragment() {
        private var _binding: FragmentLibraryBinding? = null
        private val binding get() = _binding!!
        private val viewModel: LibraryViewModel by viewModels()

        override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?) =
            FragmentLibraryBinding.inflate(inflater, container, false).also { _binding = it }.root

        override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
            super.onViewCreated(view, savedInstanceState)

            val adapter = LibraryAdapter(
                onPlay = { /* navigate to player */ },
                onDelete = { viewModel.deleteTrack(it) }
            )

            binding.rvLibrary.apply {
                layoutManager = LinearLayoutManager(requireContext())
                this.adapter = adapter
            }

            viewLifecycleOwner.lifecycleScope.launch {
                viewModel.downloadedTracks.collect { tracks ->
                    adapter.submitList(tracks)
                    binding.tvEmpty.visibility = if (tracks.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }

        override fun onDestroyView() { super.onDestroyView(); _binding = null }
    }
""")

FILES[f"{PKG}/ui/library/LibraryAdapter.kt"] = textwrap.dedent("""\
    package com.spofree.player.ui.library

    import android.view.*
    import androidx.recyclerview.widget.DiffUtil
    import androidx.recyclerview.widget.ListAdapter
    import androidx.recyclerview.widget.RecyclerView
    import com.bumptech.glide.Glide
    import com.spofree.player.data.model.Track
    import com.spofree.player.databinding.ItemTrackBinding

    class LibraryAdapter(
        private val onPlay: (Track) -> Unit,
        private val onDelete: (Track) -> Unit
    ) : ListAdapter<Track, LibraryAdapter.VH>(object : DiffUtil.ItemCallback<Track>() {
        override fun areItemsTheSame(a: Track, b: Track) = a.id == b.id
        override fun areContentsTheSame(a: Track, b: Track) = a == b
    }) {
        inner class VH(val b: ItemTrackBinding) : RecyclerView.ViewHolder(b.root) {
            fun bind(track: Track) {
                b.tvTitle.text = track.title
                b.tvArtist.text = track.artist
                b.tvCodec.text = "${track.codec} • ${track.sampleRate / 1000}kHz"
                Glide.with(b.ivCover).load(track.localCoverPath.ifEmpty { track.coverUrl })
                    .into(b.ivCover)
                b.root.setOnClickListener { onPlay(track) }
                b.btnDownload.setImageResource(com.spofree.player.R.drawable.ic_delete)
                b.btnDownload.setOnClickListener { onDelete(track) }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, vt: Int) =
            VH(ItemTrackBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(h: VH, pos: Int) = h.bind(getItem(pos))
    }
""")

# ── LYRICS VIEW ───────────────────────────────────────────────

FILES[f"{PKG}/ui/player/LyricsView.kt"] = textwrap.dedent("""\
    package com.spofree.player.ui.player

    import android.content.Context
    import android.util.AttributeSet
    import android.view.LayoutInflater
    import android.widget.LinearLayout
    import android.widget.TextView
    import com.spofree.player.R
    import kotlinx.coroutines.*

    /**
     * Parses and displays synchronized LRC lyrics,
     * highlighting the current line based on playback position.
     */
    class LyricsView @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null
    ) : LinearLayout(context, attrs) {

        private data class LrcLine(val timeMs: Long, val text: String)

        private val lines = mutableListOf<LrcLine>()
        private var currentHighlight = -1

        private val lrcRegex = Regex(\"\"\"\\[(\\d{2}):(\\d{2})\\.(\\d{2,3})\\](.*)\"\"\"

        )

        fun setLrc(lrc: String) {
            removeAllViews()
            lines.clear()
            currentHighlight = -1

            lrc.lines().forEach { line ->
                val match = lrcRegex.find(line) ?: return@forEach
                val min = match.groupValues[1].toLong()
                val sec = match.groupValues[2].toLong()
                val ms = match.groupValues[3].padEnd(3, '0').take(3).toLong()
                val text = match.groupValues[4].trim()
                if (text.isNotEmpty()) {
                    lines.add(LrcLine((min * 60 + sec) * 1000 + ms, text))
                    val tv = TextView(context).apply {
                        this.text = text
                        textSize = 16f
                        setPadding(0, 12, 0, 12)
                        alpha = 0.5f
                        setTextColor(resources.getColor(R.color.lyrics_default, null))
                    }
                    addView(tv)
                }
            }
        }

        fun updatePosition(posMs: Long) {
            val idx = lines.indexOfLast { it.timeMs <= posMs }
            if (idx == currentHighlight) return
            currentHighlight = idx
            for (i in 0 until childCount) {
                val tv = getChildAt(i) as? TextView ?: continue
                if (i == idx) {
                    tv.alpha = 1f
                    tv.textSize = 18f
                    tv.setTextColor(resources.getColor(R.color.lyrics_highlight, null))
                } else {
                    tv.alpha = 0.5f
                    tv.textSize = 16f
                    tv.setTextColor(resources.getColor(R.color.lyrics_default, null))
                }
            }
        }
    }
""")

# ─────────────────────────────────────────────────────────────
# PYTHON FILES
# ─────────────────────────────────────────────────────────────

FILES["app/src/main/python/spofree_bridge.py"] = textwrap.dedent("""\
    \"\"\"
    spofree_bridge.py
    =================
    Core Python bridge between the Android Kotlin layer and the
    spofree download/streaming logic.

    Adapted from: https://github.com/redretep/spofree/
    Extended with: full FLAC metadata embedding, synced lyrics,
    hi-res cover art, ISRC, BPM, and Vorbis comment tagging.
    \"\"\"

    import json
    import os
    import threading
    import time
    import traceback
    from pathlib import Path

    try:
        import requests
    except ImportError:
        requests = None

    try:
        from mutagen.flac import FLAC, Picture
        from mutagen.id3 import ID3, TIT2, TPE1, TALB, TRCK, TDRC, TCON, TSRC, TBPM, TPE2, APIC
        from mutagen import MutagenError
    except ImportError:
        FLAC = None

    try:
        import yt_dlp
    except ImportError:
        yt_dlp = None

    try:
        from PIL import Image
        import io as _io
    except ImportError:
        Image = None

    # ── Global download status store ─────────────────────────────
    _download_status: dict[str, dict] = {}
    _output_paths: dict[str, str] = {}


    # ─────────────────────────────────────────────────────────────
    # TOKEN / AUTH HELPERS
    # ─────────────────────────────────────────────────────────────

    def _get_spotify_token() -> str:
        \"\"\"Fetch an anonymous Spotify Web API token via the open-web endpoint.\"\"\"
        try:
            resp = requests.get(
                "https://open.spotify.com/get_access_token",
                params={"reason": "transport", "productType": "web_player"},
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/json",
                    "spotify-app-version": "1.2.30.1135",
                    "App-Platform": "WebPlayer",
                },
                timeout=10,
            )
            resp.raise_for_status()
            return resp.json().get("accessToken", "")
        except Exception as e:
            return ""


    def _spotify_headers() -> dict:
        token = _get_spotify_token()
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }


    # ─────────────────────────────────────────────────────────────
    # SEARCH
    # ─────────────────────────────────────────────────────────────

    def search(query: str) -> str:
        \"\"\"Search Spotify for tracks, albums, and artists. Returns JSON string.\"\"\"
        try:
            headers = _spotify_headers()
            resp = requests.get(
                "https://api.spotify.com/v1/search",
                headers=headers,
                params={"q": query, "type": "track,album,artist", "limit": 20, "market": "US"},
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()

            tracks = [_parse_track(t) for t in data.get("tracks", {}).get("items", [])]
            albums = [_parse_album(a) for a in data.get("albums", {}).get("items", [])]
            artists = [_parse_artist(a) for a in data.get("artists", {}).get("items", [])]

            return json.dumps({"tracks": tracks, "albums": albums, "artists": artists})
        except Exception as e:
            return json.dumps({"tracks": [], "albums": [], "artists": [], "error": str(e)})


    def _parse_track(t: dict) -> dict:
        images = t.get("album", {}).get("images", [])
        cover = images[0]["url"] if images else ""
        return {
            "id": t.get("id", ""),
            "title": t.get("name", ""),
            "artist": ", ".join(a["name"] for a in t.get("artists", [])),
            "albumArtist": t.get("album", {}).get("artists", [{}])[0].get("name", ""),
            "album": t.get("album", {}).get("name", ""),
            "duration": t.get("duration_ms", 0),
            "trackNumber": t.get("track_number", 0),
            "discNumber": t.get("disc_number", 1),
            "year": (t.get("album", {}).get("release_date") or "")[:4],
            "isrc": t.get("external_ids", {}).get("isrc", ""),
            "coverUrl": cover,
            "codec": "FLAC",
            "bitDepth": 24,
            "sampleRate": 44100,
            "isDownloaded": False,
            "downloadProgress": 0,
        }


    def _parse_album(a: dict) -> dict:
        images = a.get("images", [])
        cover = images[0]["url"] if images else ""
        return {
            "id": a.get("id", ""),
            "name": a.get("name", ""),
            "artist": ", ".join(x["name"] for x in a.get("artists", [])),
            "coverUrl": cover,
            "year": (a.get("release_date") or "")[:4],
            "totalTracks": a.get("total_tracks", 0),
        }


    def _parse_artist(a: dict) -> dict:
        images = a.get("images", [])
        img = images[0]["url"] if images else ""
        return {
            "id": a.get("id", ""),
            "name": a.get("name", ""),
            "imageUrl": img,
            "genres": a.get("genres", []),
        }


    # ─────────────────────────────────────────────────────────────
    # ALBUM DETAILS
    # ─────────────────────────────────────────────────────────────

    def get_album(album_id: str) -> str:
        \"\"\"Fetch full album with tracks. Returns JSON string.\"\"\"
        try:
            headers = _spotify_headers()
            resp = requests.get(
                f"https://api.spotify.com/v1/albums/{album_id}",
                headers=headers,
                params={"market": "US"},
                timeout=15,
            )
            resp.raise_for_status()
            a = resp.json()
            images = a.get("images", [])
            cover = images[0]["url"] if images else ""
            tracks = [_parse_track({**t, "album": a}) for t in a.get("tracks", {}).get("items", [])]
            return json.dumps({
                "id": a["id"],
                "name": a["name"],
                "artist": ", ".join(x["name"] for x in a.get("artists", [])),
                "coverUrl": cover,
                "year": (a.get("release_date") or "")[:4],
                "totalTracks": a.get("total_tracks", 0),
                "label": a.get("label", ""),
                "upc": a.get("external_ids", {}).get("upc", ""),
                "tracks": tracks,
            })
        except Exception as e:
            return json.dumps({"error": str(e)})


    # ─────────────────────────────────────────────────────────────
    # STREAM URL
    # ─────────────────────────────────────────────────────────────

    def get_stream_url(track_id: str) -> str:
        \"\"\"
        Resolve a streamable URL for the track.
        Strategy: try multiple free source backends in order.
        \"\"\"
        # Strategy 1: invidious/piped YouTube match
        url = _resolve_via_youtube(track_id)
        if url:
            return url
        return ""


    def _resolve_via_youtube(track_id: str) -> str:
        \"\"\"Find best YouTube audio match and return direct stream URL.\"\"\"
        if not yt_dlp:
            return ""
        try:
            # First get the track title/artist from Spotify
            headers = _spotify_headers()
            resp = requests.get(
                f"https://api.spotify.com/v1/tracks/{track_id}",
                headers=headers,
                timeout=10,
            )
            resp.raise_for_status()
            t = resp.json()
            query = f"{t['name']} {t['artists'][0]['name']} audio"

            ydl_opts = {
                "quiet": True,
                "no_warnings": True,
                "format": "bestaudio[ext=webm]/bestaudio",
                "noplaylist": True,
            }
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(f"ytsearch1:{query}", download=False)
                if info and "entries" in info and info["entries"]:
                    entry = info["entries"][0]
                    formats = entry.get("formats", [])
                    best = max(
                        (f for f in formats if f.get("acodec") != "none"),
                        key=lambda f: f.get("abr", 0),
                        default=None,
                    )
                    if best:
                        return best.get("url", "")
        except Exception:
            pass
        return ""


    # ─────────────────────────────────────────────────────────────
    # DOWNLOAD (FLAC with full metadata)
    # ─────────────────────────────────────────────────────────────

    def download_track_flac(track_id: str, output_dir: str) -> str:
        \"\"\"
        Download a track as FLAC with full Vorbis-comment metadata and hi-res cover art.
        Runs in a background thread; progress tracked in _download_status.
        \"\"\"
        _download_status[track_id] = {"progress": 0, "speed": "", "done": False, "error": None}
        thread = threading.Thread(
            target=_download_worker,
            args=(track_id, output_dir),
            daemon=True,
        )
        thread.start()
        return "started"


    def _download_worker(track_id: str, output_dir: str):
        try:
            os.makedirs(output_dir, exist_ok=True)

            # ── 1. Fetch metadata from Spotify ────────────────────
            headers = _spotify_headers()
            resp = requests.get(
                f"https://api.spotify.com/v1/tracks/{track_id}",
                headers=headers,
                timeout=10,
            )
            resp.raise_for_status()
            t = resp.json()

            title = t["name"]
            artists = ", ".join(a["name"] for a in t.get("artists", []))
            album_artist = t.get("album", {}).get("artists", [{}])[0].get("name", "")
            album_name = t.get("album", {}).get("name", "")
            track_num = t.get("track_number", 1)
            disc_num = t.get("disc_number", 1)
            year = (t.get("album", {}).get("release_date") or "")[:4]
            isrc = t.get("external_ids", {}).get("isrc", "")
            duration_ms = t.get("duration_ms", 0)
            images = t.get("album", {}).get("images", [])
            cover_url = images[0]["url"] if images else ""

            # Fetch audio features for BPM
            bpm = 0
            try:
                af_resp = requests.get(
                    f"https://api.spotify.com/v1/audio-features/{track_id}",
                    headers=headers,
                    timeout=8,
                )
                if af_resp.ok:
                    bpm = int(af_resp.json().get("tempo", 0))
            except Exception:
                pass

            # ── 2. Download via yt-dlp ────────────────────────────
            safe_title = "".join(c for c in title if c.isalnum() or c in " -_").strip()
            safe_artist = "".join(c for c in artists if c.isalnum() or c in " -_").strip()
            filename_base = f"{safe_artist} - {safe_title}"
            out_path = os.path.join(output_dir, f"{filename_base}.flac")

            query = f"{title} {artists} audio"
            _download_status[track_id]["progress"] = 5

            def ydl_progress_hook(d):
                if d["status"] == "downloading":
                    total = d.get("total_bytes") or d.get("total_bytes_estimate") or 1
                    downloaded = d.get("downloaded_bytes", 0)
                    pct = int((downloaded / total) * 80) + 5  # 5–85%
                    speed = d.get("_speed_str", "")
                    _download_status[track_id]["progress"] = pct
                    _download_status[track_id]["speed"] = speed

            ydl_opts = {
                "quiet": True,
                "no_warnings": True,
                "format": "bestaudio/best",
                "outtmpl": os.path.join(output_dir, f"{filename_base}.%(ext)s"),
                "postprocessors": [
                    {
                        "key": "FFmpegAudioConvertor",
                        "preferredcodec": "flac",
                        "preferredquality": "0",
                    }
                ],
                "postprocessor_args": [
                    "-ar", "44100",
                    "-sample_fmt", "s32",
                ],
                "progress_hooks": [ydl_progress_hook],
                "noplaylist": True,
            }

            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([f"ytsearch1:{query}"])

            _download_status[track_id]["progress"] = 88

            # ── 3. Download hi-res cover art ──────────────────────
            cover_data = b""
            if cover_url:
                try:
                    # Upgrade to 3000x3000 if available
                    hires_url = cover_url.replace("/image/", "/image/").split("?")[0]
                    cr = requests.get(hires_url, timeout=10)
                    if cr.ok:
                        cover_data = cr.content
                        # Optionally resize to 1500x1500 to save space
                        if Image:
                            img = Image.open(_io.BytesIO(cover_data))
                            if max(img.size) > 1500:
                                img.thumbnail((1500, 1500), Image.LANCZOS)
                            buf = _io.BytesIO()
                            img.save(buf, format="JPEG", quality=95)
                            cover_data = buf.getvalue()
                except Exception:
                    pass

            # ── 4. Embed Vorbis comments into FLAC ────────────────
            if os.path.exists(out_path) and FLAC:
                audio = FLAC(out_path)
                audio.clear()
                audio["title"] = title
                audio["artist"] = artists
                audio["albumartist"] = album_artist
                audio["album"] = album_name
                audio["tracknumber"] = str(track_num)
                audio["discnumber"] = str(disc_num)
                audio["date"] = year
                audio["isrc"] = isrc
                if bpm:
                    audio["bpm"] = str(bpm)

                if cover_data:
                    pic = Picture()
                    pic.type = 3  # Front cover
                    pic.mime = "image/jpeg"
                    pic.desc = "Cover"
                    pic.data = cover_data
                    audio.add_picture(pic)

                audio.save()

            _download_status[track_id]["progress"] = 95

            # ── 5. Fetch & embed synced lyrics ────────────────────
            try:
                lrc, plain = _fetch_lyrics_internal(title, artists, duration_ms)
                if lrc and FLAC and os.path.exists(out_path):
                    audio = FLAC(out_path)
                    audio["lyrics"] = lrc
                    audio["unsyncedlyrics"] = plain
                    audio.save()
            except Exception:
                pass

            _output_paths[track_id] = out_path
            _download_status[track_id]["progress"] = 100
            _download_status[track_id]["done"] = True

        except Exception as e:
            _download_status[track_id]["error"] = traceback.format_exc()
            _download_status[track_id]["done"] = True


    def get_download_status(track_id: str) -> str:
        status = _download_status.get(track_id, {"progress": 0, "speed": "", "done": False, "error": None})
        return json.dumps(status)


    def get_output_path(track_id: str) -> str:
        return _output_paths.get(track_id, "")


    # ─────────────────────────────────────────────────────────────
    # LYRICS
    # ─────────────────────────────────────────────────────────────

    def get_lyrics(title: str, artist: str, duration_ms: str) -> str:
        \"\"\"Fetch synced (LRC) and plain lyrics. Returns JSON with 'lrc' and 'plain' keys.\"\"\"
        lrc, plain = _fetch_lyrics_internal(title, artist, int(duration_ms))
        return json.dumps({"lrc": lrc, "plain": plain})


    def _fetch_lyrics_internal(title: str, artist: str, duration_ms: int) -> tuple[str, str]:
        lrc = ""
        plain = ""
        # Strategy 1: syncedlyrics
        try:
            import syncedlyrics
            lrc = syncedlyrics.search(f"{title} {artist}") or ""
        except Exception:
            pass

        # Strategy 2: lyricsgenius for plain
        if not plain:
            try:
                import lyricsgenius
                genius = lyricsgenius.Genius(verbose=False, remove_section_headers=True)
                song = genius.search_song(title, artist)
                if song:
                    plain = song.lyrics
            except Exception:
                pass

        return lrc, plain


    # ─────────────────────────────────────────────────────────────
    # COVER ART EXTRACTION
    # ─────────────────────────────────────────────────────────────

    def extract_cover_art(flac_path: str, out_dir: str) -> str:
        \"\"\"Extract embedded cover art from a FLAC file. Returns path to saved PNG.\"\"\"
        if not FLAC:
            return ""
        try:
            audio = FLAC(flac_path)
            for pic in audio.pictures:
                if pic.type == 3:
                    os.makedirs(out_dir, exist_ok=True)
                    stem = Path(flac_path).stem
                    out_path = os.path.join(out_dir, f"{stem}_cover.jpg")
                    with open(out_path, "wb") as f:
                        f.write(pic.data)
                    return out_path
        except Exception:
            pass
        return ""
""")

# ─────────────────────────────────────────────────────────────
# LAYOUT XML FILES
# ─────────────────────────────────────────────────────────────

RES = "app/src/main/res"

FILES[f"{RES}/layout/activity_main.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <LinearLayout
        xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:app="http://schemas.android.com/apk/res-auto"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:orientation="vertical">

        <androidx.fragment.app.FragmentContainerView
            android:id="@+id/nav_host_fragment"
            android:name="androidx.navigation.fragment.NavHostFragment"
            android:layout_width="match_parent"
            android:layout_height="0dp"
            android:layout_weight="1"
            app:defaultNavHost="true"
            app:navGraph="@navigation/nav_graph" />

        <com.google.android.material.bottomnavigation.BottomNavigationView
            android:id="@+id/bottom_nav"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:background="?android:attr/windowBackground"
            app:menu="@menu/bottom_nav_menu" />

    </LinearLayout>
""")

FILES[f"{RES}/layout/activity_player.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <androidx.constraintlayout.widget.ConstraintLayout
        xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:app="http://schemas.android.com/apk/res-auto"
        android:id="@+id/playerRoot"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:background="@color/background">

        <ImageButton
            android:id="@+id/btnBack"
            android:layout_width="48dp"
            android:layout_height="48dp"
            android:background="?selectableItemBackgroundBorderless"
            android:contentDescription="Back"
            android:src="@drawable/ic_arrow_back"
            android:tint="@color/on_background"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toTopOf="parent"
            android:layout_margin="16dp" />

        <ImageView
            android:id="@+id/ivAlbumArt"
            android:layout_width="0dp"
            android:layout_height="0dp"
            android:layout_margin="32dp"
            android:contentDescription="Album Art"
            android:scaleType="centerCrop"
            app:layout_constraintDimensionRatio="1:1"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/btnBack"
            app:layout_constraintWidth_percent="0.82" />

        <TextView
            android:id="@+id/tvTitle"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_marginHorizontal="32dp"
            android:layout_marginTop="16dp"
            android:ellipsize="marquee"
            android:marqueeRepeatLimit="marquee_forever"
            android:scrollHorizontally="true"
            android:singleLine="true"
            android:textColor="@color/on_background"
            android:textSize="22sp"
            android:textStyle="bold"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/ivAlbumArt" />

        <TextView
            android:id="@+id/tvArtist"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_marginHorizontal="32dp"
            android:layout_marginTop="4dp"
            android:textColor="@color/on_background_secondary"
            android:textSize="15sp"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/tvTitle" />

        <TextView
            android:id="@+id/tvAlbum"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_marginHorizontal="32dp"
            android:layout_marginTop="2dp"
            android:textColor="@color/on_background_secondary"
            android:textSize="12sp"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/tvArtist" />

        <TextView
            android:id="@+id/tvQuality"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginHorizontal="32dp"
            android:layout_marginTop="4dp"
            android:background="@drawable/bg_quality_badge"
            android:paddingHorizontal="8dp"
            android:paddingVertical="2dp"
            android:textColor="@color/accent"
            android:textSize="11sp"
            android:textStyle="bold"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/tvAlbum" />

        <SeekBar
            android:id="@+id/seekBar"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_marginHorizontal="24dp"
            android:layout_marginTop="16dp"
            android:progressTint="@color/accent"
            android:thumbTint="@color/accent"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/tvQuality" />

        <TextView
            android:id="@+id/tvPosition"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginStart="24dp"
            android:textColor="@color/on_background_secondary"
            android:textSize="12sp"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/seekBar" />

        <TextView
            android:id="@+id/tvDuration"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginEnd="24dp"
            android:textColor="@color/on_background_secondary"
            android:textSize="12sp"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintTop_toBottomOf="@id/seekBar" />

        <LinearLayout
            android:id="@+id/controlsRow"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_marginHorizontal="16dp"
            android:layout_marginTop="16dp"
            android:gravity="center"
            android:orientation="horizontal"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/tvPosition">

            <ImageButton
                android:id="@+id/btnShuffle"
                android:layout_width="48dp"
                android:layout_height="48dp"
                android:background="?selectableItemBackgroundBorderless"
                android:contentDescription="Shuffle"
                android:src="@drawable/ic_shuffle"
                android:tint="@color/on_background_secondary" />

            <ImageButton
                android:id="@+id/btnPrevious"
                android:layout_width="56dp"
                android:layout_height="56dp"
                android:background="?selectableItemBackgroundBorderless"
                android:contentDescription="Previous"
                android:src="@drawable/ic_skip_previous"
                android:tint="@color/on_background" />

            <ImageButton
                android:id="@+id/btnPlayPause"
                android:layout_width="72dp"
                android:layout_height="72dp"
                android:background="@drawable/bg_play_button"
                android:contentDescription="Play/Pause"
                android:src="@drawable/ic_play_pause"
                android:tint="@color/on_accent" />

            <ImageButton
                android:id="@+id/btnNext"
                android:layout_width="56dp"
                android:layout_height="56dp"
                android:background="?selectableItemBackgroundBorderless"
                android:contentDescription="Next"
                android:src="@drawable/ic_skip_next"
                android:tint="@color/on_background" />

            <ImageButton
                android:id="@+id/btnRepeat"
                android:layout_width="48dp"
                android:layout_height="48dp"
                android:background="?selectableItemBackgroundBorderless"
                android:contentDescription="Repeat"
                android:src="@drawable/ic_repeat"
                android:tint="@color/on_background_secondary" />

        </LinearLayout>

    </androidx.constraintlayout.widget.ConstraintLayout>
""")

FILES[f"{RES}/layout/fragment_search.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <LinearLayout
        xmlns:android="http://schemas.android.com/apk/res/android"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:orientation="vertical"
        android:background="@color/background">

        <com.google.android.material.textfield.TextInputLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_margin="16dp"
            style="@style/Widget.MaterialComponents.TextInputLayout.OutlinedBox">

            <com.google.android.material.textfield.TextInputEditText
                android:id="@+id/etSearch"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:hint="Search songs, albums, artists…"
                android:imeOptions="actionSearch"
                android:inputType="text"
                android:singleLine="true" />

        </com.google.android.material.textfield.TextInputLayout>

        <ProgressBar
            android:id="@+id/progressBar"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_gravity="center"
            android:visibility="gone" />

        <androidx.recyclerview.widget.RecyclerView
            android:id="@+id/rvResults"
            android:layout_width="match_parent"
            android:layout_height="match_parent"
            android:clipToPadding="false"
            android:paddingBottom="80dp" />

    </LinearLayout>
""")

FILES[f"{RES}/layout/fragment_library.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <FrameLayout
        xmlns:android="http://schemas.android.com/apk/res/android"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:background="@color/background">

        <androidx.recyclerview.widget.RecyclerView
            android:id="@+id/rvLibrary"
            android:layout_width="match_parent"
            android:layout_height="match_parent"
            android:clipToPadding="false"
            android:paddingBottom="80dp" />

        <TextView
            android:id="@+id/tvEmpty"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_gravity="center"
            android:text="No downloaded tracks yet"
            android:textColor="@color/on_background_secondary"
            android:visibility="gone" />

    </FrameLayout>
""")

FILES[f"{RES}/layout/item_track.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <androidx.cardview.widget.CardView
        xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:app="http://schemas.android.com/apk/res-auto"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginHorizontal="12dp"
        android:layout_marginVertical="4dp"
        app:cardBackgroundColor="@color/surface"
        app:cardCornerRadius="12dp"
        app:cardElevation="2dp">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:gravity="center_vertical"
            android:orientation="horizontal"
            android:padding="12dp">

            <ImageView
                android:id="@+id/ivCover"
                android:layout_width="56dp"
                android:layout_height="56dp"
                android:contentDescription="Album art"
                android:scaleType="centerCrop"
                android:background="@color/surface_variant" />

            <LinearLayout
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_marginStart="12dp"
                android:layout_weight="1"
                android:orientation="vertical">

                <TextView
                    android:id="@+id/tvTitle"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:ellipsize="end"
                    android:maxLines="1"
                    android:textColor="@color/on_surface"
                    android:textSize="15sp"
                    android:textStyle="bold" />

                <TextView
                    android:id="@+id/tvArtist"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:ellipsize="end"
                    android:maxLines="1"
                    android:textColor="@color/on_surface_secondary"
                    android:textSize="13sp" />

                <TextView
                    android:id="@+id/tvCodec"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="2dp"
                    android:textColor="@color/accent"
                    android:textSize="11sp" />

            </LinearLayout>

            <ImageButton
                android:id="@+id/btnPlay"
                android:layout_width="40dp"
                android:layout_height="40dp"
                android:background="?selectableItemBackgroundBorderless"
                android:contentDescription="Play"
                android:src="@drawable/ic_play_circle"
                android:tint="@color/accent" />

            <ImageButton
                android:id="@+id/btnDownload"
                android:layout_width="40dp"
                android:layout_height="40dp"
                android:background="?selectableItemBackgroundBorderless"
                android:contentDescription="Download"
                android:src="@drawable/ic_download"
                android:tint="@color/on_surface_secondary" />

        </LinearLayout>

    </androidx.cardview.widget.CardView>
""")

# ─────────────────────────────────────────────────────────────
# NAVIGATION
# ─────────────────────────────────────────────────────────────

FILES[f"{RES}/navigation/nav_graph.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <navigation xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:app="http://schemas.android.com/apk/res-auto"
        android:id="@+id/nav_graph"
        app:startDestination="@id/searchFragment">

        <fragment
            android:id="@+id/searchFragment"
            android:name="com.spofree.player.ui.search.SearchFragment"
            android:label="Search" />

        <fragment
            android:id="@+id/libraryFragment"
            android:name="com.spofree.player.ui.library.LibraryFragment"
            android:label="Library" />

    </navigation>
""")

# ─────────────────────────────────────────────────────────────
# MENUS
# ─────────────────────────────────────────────────────────────

FILES[f"{RES}/menu/bottom_nav_menu.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <menu xmlns:android="http://schemas.android.com/apk/res/android">
        <item
            android:id="@+id/searchFragment"
            android:icon="@drawable/ic_search"
            android:title="Search" />
        <item
            android:id="@+id/libraryFragment"
            android:icon="@drawable/ic_library"
            android:title="Library" />
    </menu>
""")

# ─────────────────────────────────────────────────────────────
# VALUES (colors, strings, themes, styles)
# ─────────────────────────────────────────────────────────────

FILES[f"{RES}/values/colors.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <resources>
        <!-- Dark theme palette -->
        <color name="background">#0A0A0F</color>
        <color name="surface">#14141F</color>
        <color name="surface_variant">#1E1E2E</color>
        <color name="accent">#1DB954</color>
        <color name="accent_dark">#158a3e</color>
        <color name="on_background">#F0F0FF</color>
        <color name="on_background_secondary">#8888AA</color>
        <color name="on_surface">#F0F0FF</color>
        <color name="on_surface_secondary">#8888AA</color>
        <color name="on_accent">#000000</color>
        <color name="lyrics_default">#8888AA</color>
        <color name="lyrics_highlight">#F0F0FF</color>
        <color name="error">#CF6679</color>
    </resources>
""")

FILES[f"{RES}/values/strings.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <resources>
        <string name="app_name">SpoFree</string>
        <string name="search_hint">Search songs, albums, artists…</string>
        <string name="library_empty">No downloaded tracks yet</string>
        <string name="downloading">Downloading…</string>
        <string name="download_complete">Download complete</string>
        <string name="download_failed">Download failed</string>
        <string name="quality_label">FLAC • Lossless</string>
    </resources>
""")

FILES[f"{RES}/values/themes.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <resources>
        <style name="Theme.SpoFree" parent="Theme.MaterialComponents.DayNight.NoActionBar">
            <item name="colorPrimary">@color/accent</item>
            <item name="colorPrimaryDark">@color/accent_dark</item>
            <item name="colorAccent">@color/accent</item>
            <item name="android:windowBackground">@color/background</item>
            <item name="android:statusBarColor">@color/background</item>
            <item name="android:navigationBarColor">@color/background</item>
            <item name="android:windowLightStatusBar">false</item>
        </style>
        <style name="Theme.SpoFree.Player" parent="Theme.SpoFree">
            <item name="android:windowTranslucentStatus">true</item>
        </style>
    </resources>
""")

FILES[f"{RES}/values/dimens.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <resources>
        <dimen name="card_corner_radius">12dp</dimen>
        <dimen name="spacing_small">8dp</dimen>
        <dimen name="spacing_medium">16dp</dimen>
        <dimen name="spacing_large">24dp</dimen>
    </resources>
""")

# ─────────────────────────────────────────────────────────────
# DRAWABLES (vector XML placeholders)
# ─────────────────────────────────────────────────────────────

def _vector(path_data: str, color: str = "@color/on_background") -> str:
    return textwrap.dedent(f"""\
        <?xml version="1.0" encoding="utf-8"?>
        <vector xmlns:android="http://schemas.android.com/apk/res/android"
            android:width="24dp"
            android:height="24dp"
            android:viewportWidth="24"
            android:viewportHeight="24">
            <path
                android:fillColor="{color}"
                android:pathData="{path_data}" />
        </vector>
    """)

ICONS = {
    "ic_search": "M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z",
    "ic_library": "M4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm16-4H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-1 9h-4v4h-2v-4H9V9h4V5h2v4h4v2z",
    "ic_download": "M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z",
    "ic_delete": "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z",
    "ic_play_circle": "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z",
    "ic_play_pause": "M6 19h4V5H6v14zm8-14v14h4V5h-4z",
    "ic_skip_previous": "M6 6h2v12H6zm3.5 6 8.5 6V6z",
    "ic_skip_next": "M6 18l8.5-6L6 6v12zm2-8.14L11.03 12 8 14.14V9.86zM16 6h2v12h-2z",
    "ic_shuffle": "M10.59 9.17 5.41 4 4 5.41l5.17 5.17 1.42-1.41zM14.5 4l2.04 2.04L4 18.59 5.41 20 17.96 7.46 20 9.5V4h-5.5zm.33 9.41-1.41 1.41 3.13 3.13L14.5 20H20v-5.5l-2.04 2.04-3.13-3.13z",
    "ic_repeat": "M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z",
    "ic_music_note": "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z",
    "ic_arrow_back": "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z",
    "ic_album_placeholder": "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 14.5c-2.49 0-4.5-2.01-4.5-4.5S9.51 7.5 12 7.5s4.5 2.01 4.5 4.5-2.01 4.5-4.5 4.5zm0-5.5c-.55 0-1 .45-1 1s.45 1 1 1 1-.45 1-1-.45-1-1-1z",
}

for name, path_data in ICONS.items():
    FILES[f"{RES}/drawable/{name}.xml"] = _vector(path_data)

FILES[f"{RES}/drawable/bg_play_button.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <shape xmlns:android="http://schemas.android.com/apk/res/android"
        android:shape="oval">
        <solid android:color="@color/accent" />
    </shape>
""")

FILES[f"{RES}/drawable/bg_quality_badge.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <shape xmlns:android="http://schemas.android.com/apk/res/android"
        android:shape="rectangle">
        <corners android:radius="4dp" />
        <stroke android:width="1dp" android:color="@color/accent" />
    </shape>
""")

# ─────────────────────────────────────────────────────────────
# XML MISC
# ─────────────────────────────────────────────────────────────

FILES[f"{RES}/xml/file_paths.xml"] = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <paths>
        <external-files-path name="music" path="Music/" />
        <files-path name="cache" path="covers/" />
    </paths>
""")

# Mipmap placeholder (ic_launcher)
_LAUNCHER_VEC = textwrap.dedent("""\
    <?xml version="1.0" encoding="utf-8"?>
    <vector xmlns:android="http://schemas.android.com/apk/res/android"
        android:width="108dp"
        android:height="108dp"
        android:viewportWidth="108"
        android:viewportHeight="108">
        <path android:fillColor="#1DB954"
            android:pathData="M54,54m-50,0a50,50 0,1 1,100 0a50,50 0,1 1,-100 0" />
        <path android:fillColor="#000000"
            android:pathData="M54,30v28c-2.5-1.5-5.3-2-8-2c-8.8,0-16,7.2-16,16s7.2,16 16,16 16-7.2,16-16V38h16V30H54z" />
    </vector>
""")

for density in ["mipmap-mdpi", "mipmap-hdpi", "mipmap-xhdpi", "mipmap-xxhdpi", "mipmap-xxxhdpi"]:
    FILES[f"{RES}/{density}/ic_launcher.xml"] = _LAUNCHER_VEC
    FILES[f"{RES}/{density}/ic_launcher_round.xml"] = _LAUNCHER_VEC

# ─────────────────────────────────────────────────────────────
# README
# ─────────────────────────────────────────────────────────────

FILES["README.md"] = textwrap.dedent("""\
    # SpoFree — Native Android FLAC Audio Player & Downloader

    > A premium lossless music app built with Kotlin + ExoPlayer + Chaquopy (Python).

    ## Features
    - 🎵 **Lossless FLAC** playback via ExoPlayer Media3
    - 📥 **Background downloads** with foreground service + progress notifications
    - 🏷️ **Full metadata** — Vorbis comments: title, artist, album artist, track #, disc #, year, ISRC, BPM, genre
    - 🖼️ **Hi-res cover art** (up to 1500×1500) embedded in FLAC + displayed with palette-driven UI
    - 📝 **Synced LRC lyrics** embedded in FLAC and displayed in-app with line highlighting
    - 🔍 **Search** via Spotify Web API (no key needed — anonymous token)
    - 📚 **Local library** with Room database
    - 🏗️ **MVVM + Hilt** architecture with Kotlin Coroutines

    ## Stack
    | Layer | Technology |
    |---|---|
    | UI | Kotlin + ViewBinding + Material3 |
    | Player | ExoPlayer / Media3 |
    | DI | Hilt |
    | DB | Room |
    | Downloads | WorkManager + ForegroundService |
    | Python | Chaquopy 15 (Python 3.11) |
    | Metadata | mutagen (FLAC / Vorbis) |
    | Audio DL | yt-dlp + FFmpeg post-processor |
    | Lyrics | syncedlyrics + lyricsgenius |

    ## Setup
    1. Open in Android Studio Hedgehog or later.
    2. Android SDK 34 + NDK required.
    3. Run `./gradlew assembleDebug`.
    4. Chaquopy will pip-install all Python dependencies on first build.

    ## Legal Notice
    This project is for **educational purposes only**.
    Downloading copyrighted music without authorization may violate laws in your jurisdiction.
    Always respect artists and support them through official channels.

    ## Architecture
    ```
    SpoFreeApplication (Hilt)
    ├── ui/
    │   ├── MainActivity          (bottom nav host)
    │   ├── search/SearchFragment  (search + results)
    │   ├── library/LibraryFragment(downloaded tracks)
    │   └── player/PlayerActivity  (full-screen player)
    ├── service/
    │   ├── MusicPlayerService    (ExoPlayer foreground)
    │   └── DownloadService       (FLAC download foreground)
    ├── data/
    │   ├── model/                (Track, Album, Artist, …)
    │   ├── db/                   (Room DAO)
    │   ├── python/PythonBridge   (Chaquopy interface)
    │   └── repository/           (single source of truth)
    └── di/AppModule              (Hilt providers)
    ```
""")

# ─────────────────────────────────────────────────────────────
# SCRIPT: write files & zip
# ─────────────────────────────────────────────────────────────

def create_files():
    created = 0
    for rel_path, content in FILES.items():
        full_path = os.path.join(ROOT, rel_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(content)
        created += 1
    return created


def zip_project(zip_name: str):
    with zipfile.ZipFile(zip_name, "w", zipfile.ZIP_DEFLATED) as zf:
        for dirpath, _, filenames in os.walk(ROOT):
            for fn in filenames:
                abs_path = os.path.join(dirpath, fn)
                zf.write(abs_path, os.path.relpath(abs_path))


if __name__ == "__main__":
    print("=" * 60)
    print("  SpoFree Android Project Generator")
    print("=" * 60)

    print(f"\n[1/3] Creating project structure under '{ROOT}/'…")
    n = create_files()
    print(f"      ✓ {n} files written.")

    zip_name = "Spofree_Android_Player.zip"
    print(f"\n[2/3] Compressing to '{zip_name}'…")
    zip_project(zip_name)
    size_mb = os.path.getsize(zip_name) / (1024 * 1024)
    print(f"      ✓ {zip_name} ({size_mb:.2f} MB)")

    print("\n[3/3] Done! Next steps:")
    print("  1. Unzip Spofree_Android_Player.zip")
    print("  2. Open the folder in Android Studio Hedgehog+")
    print("  3. Ensure Android SDK 34 & NDK are installed")
    print("  4. Run:  ./gradlew assembleDebug")
    print("  5. Install on device / emulator (arm64 or x86_64)")
    print("\n  ⚠  For educational use only. Respect copyright laws.")
    print("=" * 60)
